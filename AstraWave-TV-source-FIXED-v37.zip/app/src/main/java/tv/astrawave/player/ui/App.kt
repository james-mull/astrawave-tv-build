package tv.astrawave.player.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.ui.TrackSelectionDialogBuilder
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import tv.astrawave.player.BuildConfig
import tv.astrawave.player.MainViewModel
import tv.astrawave.player.data.SecureStore
import tv.astrawave.player.data.PlaybackStore
import tv.astrawave.player.data.PlaybackPreferences
import tv.astrawave.player.data.BufferMode
import tv.astrawave.player.data.DeviceMode
import tv.astrawave.player.data.DeviceModeStore
import tv.astrawave.player.data.ParentalControlStore
import tv.astrawave.player.debrid.HttpDebridResolver
import tv.astrawave.player.extensions.CloudStreamRepositoryClient
import tv.astrawave.player.extensions.ExtensionKind
import tv.astrawave.player.extensions.ExtensionStore
import tv.astrawave.player.extensions.InstalledExtension
import tv.astrawave.player.extensions.StremioAddonClient
import tv.astrawave.player.model.*
import tv.astrawave.player.trakt.TraktClient
import tv.astrawave.player.trakt.TraktDeviceCode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Destination(val label: String) { HOME("Home"), SEARCH("Search"), LIVE("Live TV"), GUIDE("Guide"), EVENTS("Live Events"), MOVIES("Movies"), SERIES("Series"), GAMES("Games"), TRAKT("Trakt"), EXTENSIONS("Extensions"), DEBRID("Debrid"), SETTINGS("Settings") }

@Composable fun AstraWaveApp(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val deviceStore = remember { DeviceModeStore(context) }
    var deviceMode by remember { mutableStateOf(deviceStore.selected()) }
    val parentalStore = remember { ParentalControlStore(context) }
    var parentalUnlocked by remember { mutableStateOf(false) }
    var parentalRevision by remember { mutableIntStateOf(0) }
    if (deviceMode == null) {
        DeviceSetupScreen(deviceStore.recommended()) { selected -> deviceStore.save(selected); deviceMode = selected }
        return
    }
    LaunchedEffect(deviceMode) { (context as? Activity)?.requestedOrientation = if (deviceMode == DeviceMode.TV) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    val state by vm.state.collectAsState()
    val parentalEnabled = parentalRevision.let { parentalStore.enabled }
    val visibleChannels = if (parentalEnabled && !parentalUnlocked) state.channels.filterNot(parentalStore::isBlocked) else state.channels
    var destination by remember { mutableStateOf(Destination.HOME) }
    var selectedContent by remember { mutableStateOf<Channel?>(null) }
    val openContent: (Channel) -> Unit = { item -> if (item.kind == MediaKind.LIVE) vm.play(item) else { if (item.kind == MediaKind.SERIES) vm.loadSeriesEpisodes(item); selectedContent = item } }
    if (state.playing != null) {
        PlayerScreen(state.playing!!, visibleChannels, vm::play, onBack = { vm.play(null) })
        return
    }
    val content: @Composable BoxScope.() -> Unit = {
            when {
                state.profile == null -> LoginScreen(vm::connect)
                selectedContent != null -> ContentDetailsScreen(selectedContent!!, visibleChannels, state.episodesBySeries[selectedContent!!.id].orEmpty(), state.seriesLoadingId == selectedContent!!.id, { selectedContent = null }, { if (it.kind == MediaKind.SERIES) vm.loadSeriesEpisodes(it); selectedContent = it }, vm::play, vm::toggleFavorite, state.favorites)
                destination == Destination.HOME -> HomeScreen(visibleChannels, openContent)
                destination == Destination.SEARCH -> UniversalSearchScreen(visibleChannels, openContent)
                destination == Destination.LIVE -> ChannelBrowser(visibleChannels, state.favorites, vm::toggleFavorite, openContent)
                destination == Destination.GUIDE -> GuideScreen(visibleChannels, state.programs, state.favorites, vm::toggleFavorite, vm::play, vm::playCatchup)
                destination == Destination.EVENTS -> EventsScreen(vm, visibleChannels)
                destination == Destination.MOVIES -> PosterShelf("Movies", visibleChannels.filter { it.kind == MediaKind.MOVIE }, openContent)
                destination == Destination.SERIES -> PosterShelf("Series", visibleChannels.filter { it.kind == MediaKind.SERIES }, openContent)
                destination == Destination.GAMES -> GamesScreen()
                destination == Destination.TRAKT -> TraktScreen(visibleChannels.filter { it.kind != MediaKind.LIVE }, openContent)
                destination == Destination.EXTENSIONS -> ExtensionsScreen()
                destination == Destination.DEBRID -> DebridScreen(vm::play)
                else -> SettingsScreen(state.profile!!, vm::connect, deviceMode!!, { mode -> deviceStore.save(mode); deviceMode = mode }, parentalStore, parentalUnlocked, { parentalUnlocked = it }, { parentalRevision++ })
            }
            if (state.loading) CircularProgressIndicator(Modifier.align(Alignment.Center))
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.align(Alignment.BottomCenter)) }
    }
    if (deviceMode == DeviceMode.PHONE) {
        Column(Modifier.fillMaxSize().background(Ink)) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(16.dp), content = content)
            LazyRow(Modifier.fillMaxWidth().height(72.dp).background(Color(0xFF050505)), horizontalArrangement = Arrangement.spacedBy(2.dp), contentPadding = PaddingValues(horizontal = 8.dp)) {
                items(Destination.entries.toList(), key = { it.name }) { item -> NavigationBarItem(selected = destination == item, onClick = { destination = item; selectedContent = null }, icon = { Icon(icon(item), null) }, label = { Text(item.label, fontSize = 10.sp) }) }
            }
        }
    } else {
        Row(Modifier.fillMaxSize().background(Ink)) {
            NavigationRail(containerColor = Color(0xFF050505), modifier = Modifier.width(if (deviceMode == DeviceMode.TABLET) 160.dp else 190.dp).verticalScroll(rememberScrollState())) {
                Spacer(Modifier.height(24.dp)); Text("ASTRAWAVE", color = Mint, fontWeight = FontWeight.Black, letterSpacing = 3.sp, modifier = Modifier.padding(12.dp))
                Destination.entries.forEach { item -> NavigationRailItem(selected = destination == item, onClick = { destination = item; selectedContent = null }, icon = { Icon(icon(item), null) }, label = { Text(item.label) }, alwaysShowLabel = true) }
            }
            Box(Modifier.fillMaxSize().padding(if (deviceMode == DeviceMode.TABLET) 20.dp else 28.dp), content = content)
        }
    }
}

@Composable private fun DeviceSetupScreen(recommended: DeviceMode, select: (DeviceMode) -> Unit) {
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF250507), Ink))).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("ASTRAWAVE", color = Mint, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
        Spacer(Modifier.height(18.dp)); Text("How are you watching?", fontSize = 34.sp, fontWeight = FontWeight.Black); Text("Choose a layout. You can change this later in Settings.", color = Muted)
        Spacer(Modifier.height(28.dp)); LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(DeviceMode.entries) { mode -> FocusCard(Modifier.width(210.dp).height(150.dp), onClick = { select(mode) }) { Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Icon(if (mode == DeviceMode.TV) Icons.Default.Tv else if (mode == DeviceMode.TABLET) Icons.Default.Tablet else Icons.Default.PhoneAndroid, null, tint = if (mode == recommended) Mint else Color.White, modifier = Modifier.size(40.dp)); Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 20.sp, fontWeight = FontWeight.Bold); if (mode == recommended) Text("Recommended", color = Mint, fontSize = 12.sp) } } } }
    }
}

private fun icon(d: Destination) = when(d) {
    Destination.HOME -> Icons.Default.Home; Destination.SEARCH -> Icons.Default.Search; Destination.LIVE -> Icons.Default.LiveTv
    Destination.GUIDE -> Icons.Default.ViewTimeline; Destination.EVENTS -> Icons.Default.SportsFootball
    Destination.MOVIES -> Icons.Default.Movie; Destination.SERIES -> Icons.Default.Tv
    Destination.GAMES -> Icons.Default.SportsEsports
    Destination.TRAKT -> Icons.Default.Sync
    Destination.EXTENSIONS -> Icons.Default.Extension; Destination.DEBRID -> Icons.Default.Link; Destination.SETTINGS -> Icons.Default.Settings
}

private data class EmulatorOption(val name: String, val systems: String, val packageName: String, val officialUrl: String)

@Composable private fun GamesScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("astrawave_games", android.content.Context.MODE_PRIVATE) }
    var games by remember { mutableStateOf(prefs.getStringSet("uris", emptySet()).orEmpty().toSet()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { runCatching { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }; games = games + it.toString(); prefs.edit().putStringSet("uris", games).apply() }
    }
    val emulators = remember { listOf(
        EmulatorOption("RetroArch", "Multi-system retro frontend", "com.retroarch.aarch64", "https://www.retroarch.com/?page=platforms"),
        EmulatorOption("PPSSPP", "PSP", "org.ppsspp.ppsspp", "https://www.ppsspp.org/download/"),
        EmulatorOption("Dolphin", "GameCube and Wii", "org.dolphinemu.dolphinemu", "https://dolphin-emu.org/download/"),
        EmulatorOption("DuckStation", "PlayStation 1", "com.github.stenzek.duckstation", "https://github.com/stenzek/duckstation/releases")
    ) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Games & Emulators", fontSize = 34.sp, fontWeight = FontWeight.Black) }
        item { Text("Launch installed emulators or visit their official download pages. Use only games and firmware you legally own or free homebrew.", color = Muted) }
        item { Text("Emulators", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        items(emulators, key = { it.packageName }) { emulator ->
            val launchIntent = context.packageManager.getLaunchIntentForPackage(emulator.packageName)
            FocusCard(Modifier.fillMaxWidth().height(82.dp), onClick = { if (launchIntent != null) context.startActivity(launchIntent) else context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(emulator.officialUrl))) }) {
                Row(Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.SportsEsports, null, tint = Mint); Column(Modifier.padding(horizontal = 14.dp).weight(1f)) { Text(emulator.name, fontWeight = FontWeight.Bold); Text(emulator.systems, color = Muted) }; Text(if (launchIntent != null) "OPEN" else "OFFICIAL DOWNLOAD", color = if (launchIntent != null) Color(0xFF46D369) else Mint, fontWeight = FontWeight.Bold) }
            }
        }
        item { HorizontalDivider(); Row(verticalAlignment = Alignment.CenterVertically) { Text("My legal game files", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Button(onClick = { picker.launch(arrayOf("application/octet-stream", "application/zip", "application/x-iso9660-image")) }) { Icon(Icons.Default.Add, null); Text(" Add file") } } }
        if (games.isEmpty()) item { Text("No game files added. AstraWave does not include or download ROMs or BIOS files.", color = Muted) }
        items(games.toList(), key = { it }) { value ->
            val uri = Uri.parse(value)
            FocusCard(Modifier.fillMaxWidth().height(72.dp), onClick = { context.startActivity(Intent(Intent.ACTION_VIEW).setData(uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }) {
                Row(Modifier.fillMaxSize().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.FolderOpen, null, tint = Mint); Text(uri.lastPathSegment ?: "Game file", Modifier.padding(horizontal = 12.dp).weight(1f), maxLines = 1); TextButton(onClick = { games = games - value; prefs.edit().putStringSet("uris", games).apply() }) { Text("Remove") } }
            }
        }
    }
}

@Composable private fun TraktScreen(content: List<Channel>, open: (Channel) -> Unit) {
    val context = LocalContext.current
    val store = remember { SecureStore(context) }
    val scope = rememberCoroutineScope()
    var connected by remember { mutableStateOf(store.traktAccessToken() != null) }
    var deviceCode by remember { mutableStateOf<TraktDeviceCode?>(null) }
    var connecting by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item { Text("Trakt", fontSize = 34.sp, fontWeight = FontWeight.Black) }
        item { Text("Sync watch history, progress and lists across supported devices.", color = Muted) }
        item {
            FocusCard(Modifier.fillMaxWidth().heightIn(min = 116.dp), onClick = {}) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(if (connected) "✓ TRAKT CONNECTED" else "TRAKT ACCOUNT", color = if (connected) Color(0xFF46D369) else Mint, fontWeight = FontWeight.Black)
                    when {
                        BuildConfig.TRAKT_CLIENT_ID.isBlank() -> Text("Add TRAKT_CLIENT_ID to Gradle properties before building to enable connection.", color = Muted)
                        deviceCode != null -> { Text("Go to ${deviceCode!!.verification_url}", color = Muted); Text(deviceCode!!.user_code, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp) }
                        else -> Text(if (connected) "Tokens are encrypted on this device." else "Connect using Trakt's secure TV device code.", color = Muted)
                    }
                    if (!connected) Button(enabled = !connecting && BuildConfig.TRAKT_CLIENT_ID.isNotBlank(), onClick = {
                        connecting = true; error = null
                        scope.launch {
                            runCatching { val client = TraktClient(BuildConfig.TRAKT_CLIENT_ID); val code = client.requestDeviceCode(); deviceCode = code; client.waitForAuthorization(code) }
                                .onSuccess { token -> store.saveTraktTokens(token.access_token, token.refresh_token); connected = true; connecting = false; deviceCode = null }
                                .onFailure { error = it.message; connecting = false }
                        }
                    }) { if (connecting) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.Link, null); Text(if (deviceCode == null) " Connect Trakt" else " Waiting for approval") }
                    else OutlinedButton(onClick = { store.clearTrakt(); connected = false }) { Text("Disconnect") }
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }
        }
        if (connected) {
            item { CinematicRail("Trakt Watchlist", content.take(12), open) }
            item { CinematicRail("Continue Watching", content.drop(3).take(12), open, showProgress = true) }
            item { CinematicRail("Recently Watched", content.reversed().take(12), open) }
        }
    }
}

@Composable private fun UniversalSearchScreen(content: List<Channel>, open: (Channel) -> Unit) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf<MediaKind?>(null) }
    val results = content.filter { item ->
        (filter == null || item.kind == filter) && (query.isBlank() || item.name.contains(query, true) || item.group.contains(query, true) || item.epgId.orEmpty().contains(query, true))
    }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Search everything", fontSize = 34.sp, fontWeight = FontWeight.Black)
        TvField(query, { query = it }, "Channels, movies, series and programs")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(filter == null, { filter = null }, { Text("All") })
            FilterChip(filter == MediaKind.LIVE, { filter = MediaKind.LIVE }, { Text("Live TV") })
            FilterChip(filter == MediaKind.MOVIE, { filter = MediaKind.MOVIE }, { Text("Movies") })
            FilterChip(filter == MediaKind.SERIES, { filter = MediaKind.SERIES }, { Text("Series") })
        }
        Text(if (query.isBlank()) "Browse all content" else "${results.size} results", color = Muted)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(results.take(50), key = { "search-${it.id}" }) { PosterCard(it, open, landscape = it.kind == MediaKind.LIVE) } }
    }
}

@Composable private fun ContentDetailsScreen(item: Channel, allContent: List<Channel>, episodes: List<Episode>, episodesLoading: Boolean, onBack: () -> Unit, open: (Channel) -> Unit, play: (Channel) -> Unit, toggleFavorite: (String) -> Unit, favorites: Set<String>) {
    val playbackStore = remember { PlaybackStore(LocalContext.current) }
    val itemProgress = playbackStore.progress(item.id)
    val related = allContent.filter { it.id != item.id && it.kind == item.kind && it.group == item.group }.take(12)
    val collectionName = item.group.takeIf { it.isNotBlank() && !it.equals("Other", true) }
    val seasons = episodes.map { it.season }.distinct().sorted()
    var selectedSeason by remember(item.id, seasons) { mutableStateOf(seasons.firstOrNull() ?: 1) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(22.dp)) {
        item {
            Box(Modifier.fillMaxWidth().height(330.dp).background(Panel, RoundedCornerShape(12.dp))) {
                AsyncImage(model = item.backdrop ?: item.logo, contentDescription = item.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black.copy(alpha = .98f), Color.Black.copy(alpha = .72f), Color.Transparent))))
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Ink.copy(alpha = .94f)))))
                Column(Modifier.align(Alignment.BottomStart).widthIn(max = 720.dp).padding(32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(item.name, fontSize = 38.sp, fontWeight = FontWeight.Black)
                    Text(listOf(item.year, item.group, if (item.kind == MediaKind.MOVIE) "Movie" else "Series", item.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty(), "HD").filter { it.isNotBlank() }.joinToString("  •  "), color = Color.White.copy(alpha = .8f))
                    collectionName?.let { Text("PART OF THE ${it.uppercase()} COLLECTION", color = Mint, fontWeight = FontWeight.Bold) }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { if (item.streamUrl.isNotBlank()) play(item) }, enabled = item.streamUrl.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Icon(Icons.Default.PlayArrow, null); Text(if (item.kind == MediaKind.SERIES) " Choose episode" else if (itemProgress.positionMs > 30_000 && !itemProgress.watched) " Resume" else " Play", fontWeight = FontWeight.Bold) }
                        OutlinedButton(onClick = { toggleFavorite(item.id) }) { Icon(if (item.id in favorites) Icons.Default.Check else Icons.Default.Add, null); Text(if (item.id in favorites) " My List" else " Add to My List") }
                        OutlinedButton(onClick = {}) { Icon(Icons.Default.SmartDisplay, null); Text(" Trailer") }
                    }
                }
                IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(14.dp).background(Color.Black.copy(alpha = .55f), RoundedCornerShape(50))) { Icon(Icons.Default.ArrowBack, "Back") }
            }
        }
        item { Text(item.plot.ifBlank { "Available from your connected provider. Playback source and metadata remain tied to the service you authorized." }, color = Muted, fontSize = 16.sp) }
        if (item.kind == MediaKind.SERIES) {
            if (episodesLoading) item { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp); Text("  Loading seasons and episodes…", color = Muted) } }
            else if (episodes.isEmpty()) item { Text("No episodes were returned by the provider.", color = Muted) }
            else {
                item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(seasons) { season -> FilterChip(selectedSeason == season, { selectedSeason = season }, { Text("Season $season") }) } } }
                items(episodes.filter { it.season == selectedSeason }, key = { "episode-${it.id}" }) { episode ->
                    val episodeProgress = playbackStore.progress("episode-${episode.id}")
                    FocusCard(Modifier.fillMaxWidth().height(112.dp), onClick = { play(Channel("episode-${episode.id}", episode.title, episode.streamUrl, episode.artwork, "Season ${episode.season}", kind = MediaKind.SERIES, providerId = episode.id, plot = episode.plot, rating = episode.rating)) }) {
                        Row(Modifier.fillMaxSize().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(model = episode.artwork ?: item.logo, contentDescription = episode.title, contentScale = ContentScale.Crop, modifier = Modifier.width(150.dp).fillMaxHeight().background(Panel, RoundedCornerShape(6.dp)))
                            Column(Modifier.padding(horizontal = 14.dp).weight(1f)) { Text("${episode.number}. ${episode.title}", fontWeight = FontWeight.Bold, maxLines = 1); Text(listOf(episode.duration, episode.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty()).filter { it.isNotBlank() }.joinToString(" • "), color = Muted, fontSize = 12.sp); Text(episode.plot, color = Muted, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                            if (episodeProgress.watched) Icon(Icons.Default.CheckCircle, "Watched", tint = Color(0xFF46D369)) else Icon(Icons.Default.PlayArrow, "Play episode")
                        }
                        if (episodeProgress.fraction > 0f && !episodeProgress.watched) LinearProgressIndicator(progress = { episodeProgress.fraction }, color = Mint, trackColor = Color.White.copy(alpha = .2f), modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(4.dp))
                    }
                }
            }
        }
        if (collectionName != null && related.isNotEmpty()) item { CinematicRail("${collectionName} Collection", related, open) }
        if (related.isNotEmpty()) item { CinematicRail("More Like This", related.reversed(), open) }
    }
}

@Composable private fun LoginScreen(connect: (Profile) -> Unit) {
    val store = remember { SecureStore(LocalContext.current) }
    var savedProfiles by remember { mutableStateOf(store.profiles()) }
    var mode by remember { mutableStateOf(SourceType.XTREAM) }
    var name by remember { mutableStateOf("My TV") }
    var server by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var epgUrl by remember { mutableStateOf("") }
    Column(Modifier.widthIn(max = 720.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Bring your own TV", fontSize = 36.sp, fontWeight = FontWeight.Bold)
        Text("AstraWave provides no channels. Connect a service or playlist you are authorized to use.", color = Muted)
        if (savedProfiles.isNotEmpty()) {
            Text("Saved profiles", fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) { items(savedProfiles, key = { it.id }) { profile -> AssistChip(onClick = { connect(profile) }, label = { Text(profile.name) }, leadingIcon = { Icon(if (profile.type == SourceType.XTREAM) Icons.Default.Dns else Icons.Default.PlaylistPlay, null) }) } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(mode == SourceType.XTREAM, { mode = SourceType.XTREAM }, { Text("Xtream Codes") })
            FilterChip(mode == SourceType.M3U, { mode = SourceType.M3U }, { Text("M3U URL") })
        }
        TvField(name, { name = it }, "Profile name")
        TvField(server, { server = it }, if (mode == SourceType.XTREAM) "Server URL" else "M3U playlist URL")
        if (mode == SourceType.XTREAM) {
            TvField(username, { username = it }, "Username")
            TvField(password, { password = it }, "Password")
        }
        if (mode == SourceType.M3U) TvField(epgUrl, { epgUrl = it }, "XMLTV guide URL (optional)")
        Button(onClick = { val profile = Profile("profile-${("$server|$username").lowercase().hashCode()}", name, mode, server, username, password, epgUrl); store.saveProfile(profile); savedProfiles = store.profiles(); connect(profile) }, enabled = server.startsWith("http")) {
            Text("Connect securely")
        }
    }
}

@Composable private fun TvField(value: String, onChange: (String) -> Unit, label: String) {
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
}

@Composable private fun HomeScreen(channels: List<Channel>, play: (Channel) -> Unit) {
    val playbackStore = remember { PlaybackStore(LocalContext.current) }
    val movies = channels.filter { it.kind == MediaKind.MOVIE }
    val series = channels.filter { it.kind == MediaKind.SERIES }
    val live = channels.filter { it.kind == MediaKind.LIVE }
    val continuing = channels.filter { it.kind != MediaKind.LIVE && playbackStore.progress(it.id).fraction in .01f..0.89f }.take(14)
    LazyColumn(verticalArrangement = Arrangement.spacedBy(22.dp)) {
        item { HeroCard((movies + series + live).firstOrNull(), play) }
        if (channels.isEmpty()) item { Text("Connect your provider to fill these personalized rows.", color = Muted) }
        if (continuing.isNotEmpty()) item { CinematicRail("Continue Watching", continuing, play, showProgress = true) }
        item { CinematicRail("Trending Now", movies.ifEmpty { channels }.take(14), play) }
        item { CinematicRail("Popular Series", series.ifEmpty { channels }.take(14), play) }
        item { CinematicRail("Live Now", live.take(14), play, landscape = true) }
    }
}

@Composable private fun HeroCard(channel: Channel?, play: (Channel) -> Unit) {
    Box(Modifier.fillMaxWidth().height(300.dp).background(Panel, RoundedCornerShape(12.dp))) {
        (channel?.backdrop ?: channel?.logo)?.let { artwork -> AsyncImage(model = artwork, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black.copy(alpha = .96f), Color.Black.copy(alpha = .68f), Color.Transparent))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Ink.copy(alpha = .92f)))))
        Column(Modifier.align(Alignment.CenterStart).widthIn(max = 600.dp).padding(36.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("ASTRAWAVE FEATURED", color = Mint, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text(channel?.name ?: "Your entertainment. All in one place.", fontSize = 36.sp, fontWeight = FontWeight.Black, maxLines = 2)
            Text(channel?.group ?: "Live TV, movies, series and a beautiful guide built around your authorized services.", color = Color.White.copy(alpha = .82f), fontSize = 17.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                channel?.let { Button(onClick = { play(it) }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Icon(Icons.Default.PlayArrow, null); Text(" Play", fontWeight = FontWeight.Bold) } }
                OutlinedButton(onClick = {}) { Icon(Icons.Default.Info, null); Text(" More info") }
            }
        }
    }
}

@Composable private fun CinematicRail(title: String, content: List<Channel>, play: (Channel) -> Unit, showProgress: Boolean = false, landscape: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (content.isEmpty()) Text("Nothing here yet", color = Muted)
        else LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(content, key = { "${title}-${it.id}" }) { item -> PosterCard(item, play, showProgress, landscape) } }
    }
}

@Composable private fun PosterCard(channel: Channel, play: (Channel) -> Unit, showProgress: Boolean = false, landscape: Boolean = false) {
    val playback = PlaybackStore(LocalContext.current).progress(channel.id)
    val width = if (landscape) 240.dp else 150.dp
    val height = if (landscape) 135.dp else 222.dp
    FocusCard(Modifier.width(width).height(height), onClick = { play(channel) }) {
        AsyncImage(model = channel.logo, contentDescription = channel.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, Color.Black.copy(alpha = .94f)))))
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(10.dp)) {
            Text(channel.name, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(channel.group, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (showProgress && playback.fraction > 0f) { Spacer(Modifier.height(6.dp)); LinearProgressIndicator(progress = { playback.fraction }, color = Mint, trackColor = Color.White.copy(alpha = .25f), modifier = Modifier.fillMaxWidth().height(3.dp)) }
        }
    }
}

@Composable private fun ChannelBrowser(channels: List<Channel>, favorites: Set<String>, toggleFavorite: (String) -> Unit, play: (Channel) -> Unit) {
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf<String?>(null) }
    val groups = channels.map { it.group }.distinct().take(12)
    val shown = channels.filter { (group == null || group == "__favorites" || it.group == group) && (query.isBlank() || it.name.contains(query, true) || it.group.contains(query, true)) }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Live TV", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        TvField(query, { query = it }, "Search channels")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(group == null, { group = null }, { Text("All") }) }
            item { FilterChip(group == "__favorites", { group = "__favorites" }, { Text("Favorites") }) }
            items(groups) { item -> FilterChip(group == item, { group = item }, { Text(item) }) }
        }
        val filtered = if (group == "__favorites") shown.filter { it.id in favorites } else shown
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(filtered, key = { it.id }) { ChannelRow(it, it.id in favorites, toggleFavorite, play) } }
    }
}

@Composable private fun ChannelRow(channel: Channel, favorite: Boolean, toggleFavorite: (String) -> Unit, play: (Channel) -> Unit) {
    FocusCard(Modifier.fillMaxWidth().height(68.dp), onClick = { play(channel) }) {
        Row(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.LiveTv, null, tint = Mint)
            Column(Modifier.padding(start = 14.dp).weight(1f)) { Text(channel.name, fontWeight = FontWeight.SemiBold); Text(channel.group, color = Muted, fontSize = 12.sp) }
            IconButton(onClick = { toggleFavorite(channel.id) }) { Icon(if (favorite) Icons.Default.Star else Icons.Default.StarBorder, "Favorite", tint = if (favorite) Mint else Muted) }
            Icon(Icons.Default.PlayArrow, null)
        }
    }
}

@Composable private fun ChannelCard(channel: Channel, play: (Channel) -> Unit) {
    PosterCard(channel, play, landscape = channel.kind == MediaKind.LIVE)
}

@Composable private fun GuideScreen(channels: List<Channel>, programs: List<Program>, favorites: Set<String>, toggleFavorite: (String) -> Unit, play: (Channel) -> Unit, playCatchup: (Channel, Program) -> Unit) {
    var query by remember { mutableStateOf("") }
    var favoritesOnly by remember { mutableStateOf(false) }
    var catchupOnly by remember { mutableStateOf(false) }
    val nowMillis = System.currentTimeMillis()
    val timeFormat = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    val shown = channels.filter { (!favoritesOnly || it.id in favorites) && (!catchupOnly || it.catchupDays > 0) && (query.isBlank() || it.name.contains(query, true) || programs.any { p -> (p.channelId == it.epgId || p.channelId == it.id) && p.title.contains(query, true) }) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("TV Guide", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { TvField(query, { query = it }, "Search channels and programs") }; FilterChip(favoritesOnly, { favoritesOnly = !favoritesOnly }, { Text("★ Favorites") }); FilterChip(catchupOnly, { catchupOnly = !catchupOnly }, { Text("↶ Catch-up") }) }
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) { Text("CHANNEL", color = Muted, modifier = Modifier.width(250.dp)); Text(if (catchupOnly) "LATEST REPLAY" else "NOW", color = Mint, modifier = Modifier.weight(1f)); Text(if (catchupOnly) "EARLIER" else "NEXT", color = Muted, modifier = Modifier.weight(.65f)) }
        LazyColumn { items(shown, key = { it.id }) { channel ->
            val schedule = programs.filter { it.channelId == channel.epgId || it.channelId == channel.id }
            val now = schedule.firstOrNull { nowMillis in it.startMillis until it.endMillis }
            val next = schedule.firstOrNull { it.startMillis >= (now?.endMillis ?: nowMillis) }
            val archiveCutoff = nowMillis - channel.catchupDays * 86_400_000L
            val archived = if (channel.catchupDays > 0) schedule.filter { it.endMillis < nowMillis && it.startMillis >= archiveCutoff }.sortedByDescending { it.startMillis } else emptyList()
            val primary = if (catchupOnly) archived.getOrNull(0) else now
            val secondary = if (catchupOnly) archived.getOrNull(1) else next
            Row(Modifier.fillMaxWidth().height(88.dp)) {
                FocusCard(Modifier.width(250.dp).fillMaxHeight().padding(4.dp), onClick = { play(channel) }) { Row(Modifier.fillMaxSize().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { toggleFavorite(channel.id) }) { Icon(if (channel.id in favorites) Icons.Default.Star else Icons.Default.StarBorder, null, tint = if (channel.id in favorites) Mint else Muted) }; Text(channel.name, maxLines = 2, fontWeight = FontWeight.Bold) } }
                FocusCard(Modifier.weight(1f).fillMaxHeight().padding(4.dp), onClick = { if (catchupOnly && primary != null) playCatchup(channel, primary) else play(channel) }) { Column(Modifier.padding(12.dp)) { Text(primary?.title ?: if (catchupOnly) "No replay available" else "No guide information", fontWeight = FontWeight.Bold, maxLines = 1); Text(primary?.let { "${timeFormat.format(Date(it.startMillis))}–${timeFormat.format(Date(it.endMillis))}" } ?: if (catchupOnly) "Archive unavailable" else "Live", color = Muted, fontSize = 12.sp); if (!catchupOnly && now != null) LinearProgressIndicator(progress = { ((nowMillis - now.startMillis).toFloat() / (now.endMillis - now.startMillis)).coerceIn(0f, 1f) }, color = Mint, trackColor = Color.White.copy(alpha = .18f), modifier = Modifier.fillMaxWidth().padding(top = 5.dp).height(3.dp)) } }
                FocusCard(Modifier.weight(.65f).fillMaxHeight().padding(4.dp), onClick = { if (catchupOnly && secondary != null) playCatchup(channel, secondary) }) { Column(Modifier.padding(12.dp)) { Text(secondary?.title ?: if (catchupOnly) "No earlier replay" else "No upcoming program", maxLines = 1); secondary?.let { Text(timeFormat.format(Date(it.startMillis)), color = Muted, fontSize = 12.sp) } } }
            }
        } }
    }
}

@Composable private fun EventsScreen(vm: MainViewModel, allowedChannels: List<Channel>) {
    val state by vm.state.collectAsState()
    LaunchedEffect(Unit) { vm.refreshSports() }
    var league by remember { mutableStateOf<String?>(null) }
    val leagues = state.sportsEvents.map { it.league }.filter { it.isNotBlank() }.distinct().take(15)
    val events = state.sportsEvents.filter { league == null || it.league == league }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Live Events", fontSize = 34.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f)); IconButton(onClick = { vm.refreshSports(true) }) { Icon(Icons.Default.Refresh, "Refresh scores") } }
        Text("Schedules and scores from TheSportsDB. Watch suggestions are matched only against channels in your connected playlist.", color = Muted)
        if (state.sportsLoading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Mint)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { item { FilterChip(league == null, { league = null }, { Text("All") }) }; items(leagues) { item -> FilterChip(league == item, { league = item }, { Text(item) }) } }
        if (!state.sportsLoading && events.isEmpty()) Text("No events were returned for today.", color = Muted)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(events) { event ->
            val matches = vm.matches(event, allowedChannels)
            FocusCard(Modifier.fillMaxWidth(), onClick = { matches.firstOrNull()?.let { vm.play(it.channel) } }) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Text(event.league, color = Mint, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text(event.status, color = Muted) }
                    Text("${event.away}  ${event.awayScore.ifBlank { "–" }}  •  ${event.homeScore.ifBlank { "–" }}  ${event.home}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    val match = matches.firstOrNull(); Text(match?.let { "Watch on ${it.channel.name} • ${it.score}% match${it.reasons.takeIf { r -> r.isNotEmpty() }?.joinToString(prefix = " • ").orEmpty()}" } ?: "No matching channel in your playlist", color = if (match != null) Color(0xFF46D369) else Muted)
                }
            }
        } }
    }
}

@Composable private fun PosterShelf(title: String, content: List<Channel>, play: (Channel) -> Unit) {
    val genres = content.map { it.group }.filter { it.isNotBlank() }.distinct().take(6)
    LazyColumn(verticalArrangement = Arrangement.spacedBy(22.dp)) {
        item { Text(title, fontSize = 34.sp, fontWeight = FontWeight.Black) }
        if (content.isEmpty()) item { Text("Your provider has not returned any $title yet.", color = Muted) }
        else {
            item { CinematicRail("Featured $title", content.take(14), play) }
            item { CinematicRail("Top 10 Today", content.reversed().take(10), play) }
            genres.forEach { genre -> item { CinematicRail(genre, content.filter { it.group == genre }.take(14), play) } }
            item { CinematicRail("Recently Added", content.takeLast(14).reversed(), play) }
        }
    }
}

@Composable private fun DebridScreen(play: (Channel?) -> Unit) {
    val context = LocalContext.current
    val store = remember { SecureStore(context) }
    val resolver = remember { HttpDebridResolver() }
    val scope = rememberCoroutineScope()
    var provider by remember { mutableStateOf(DebridProvider.REAL_DEBRID) }
    var token by remember(provider) { mutableStateOf(store.debridToken(provider).orEmpty()) }
    var source by remember { mutableStateOf("") }
    var resolving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Debrid accounts", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Connect your own provider and resolve only links you are authorized to access. AstraWave does not search for or supply media.", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DebridProvider.entries.forEach { item -> FilterChip(provider == item, { provider = item; message = null }, { Text(item.name.replace('_', '-')) }) }
        }
        OutlinedTextField(token, { token = it }, label = { Text("${provider.name.replace('_', '-')} API token") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(enabled = token.isNotBlank(), onClick = { store.saveDebridToken(provider, token); message = "${provider.name.replace('_', '-')} connected securely" }) { Icon(Icons.Default.Lock, null); Text(" Save account") }
            if (store.debridToken(provider) != null) OutlinedButton(onClick = { store.clearDebrid(provider); token = ""; message = "Account disconnected" }) { Text("Disconnect") }
        }
        HorizontalDivider()
        TvField(source, { source = it }, "Authorized HTTP(S) media or hoster link")
        Button(enabled = !resolving && source.startsWith("http") && (store.debridToken(provider) != null || token.isNotBlank()), onClick = {
            if (token.isNotBlank()) store.saveDebridToken(provider, token)
            resolving = true; message = null
            scope.launch {
                runCatching { resolver.resolve(provider, source, store.debridToken(provider).orEmpty()) }
                    .onSuccess { media -> resolving = false; message = "Resolved securely"; play(Channel("debrid-${System.currentTimeMillis()}", media.filename.ifBlank { "Debrid stream" }, media.url, kind = MediaKind.MOVIE)) }
                    .onFailure { resolving = false; message = it.message }
            }
        }) { if (resolving) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.PlayArrow, null); Text(" Resolve and play") }
        message?.let { Text(it, color = if (it.contains("connected") || it.contains("Resolved")) Color(0xFF46D369) else Muted) }
    }
}

@Composable private fun ExtensionsScreen() {
    val context = LocalContext.current
    val store = remember { ExtensionStore(context) }
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(ExtensionKind.STREMIO) }
    var installed by remember { mutableStateOf(store.load()) }
    var reviewName by remember { mutableStateOf<String?>(null) }
    var reviewDetails by remember { mutableStateOf<String?>(null) }
    var reviewing by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("Extensions", fontSize = 34.sp, fontWeight = FontWeight.Black) }
        item { Text("Add a Stremio manifest or inspect a CloudStream-compatible repository you trust. AstraWave includes no extension sources.", color = Muted) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(kind == ExtensionKind.STREMIO, { kind = ExtensionKind.STREMIO; reviewName = null }, { Text("Stremio add-on") })
            FilterChip(kind == ExtensionKind.CLOUDSTREAM_REPOSITORY, { kind = ExtensionKind.CLOUDSTREAM_REPOSITORY; reviewName = null }, { Text("CloudStream repo") })
        } }
        item { TvField(url, { url = it }, if (kind == ExtensionKind.STREMIO) "HTTPS manifest URL or stremio:// URL" else "HTTPS repository JSON URL") }
        item { Button(onClick = {
            reviewing = true; error = null; reviewName = null
            scope.launch {
                runCatching {
                    if (kind == ExtensionKind.STREMIO) {
                        val manifest = StremioAddonClient().manifest(url)
                        manifest.name to "v${manifest.version} • ${manifest.types.joinToString()} • ${manifest.catalogs.size} catalogs • resources: ${manifest.resources.joinToString { it.name }}"
                    } else {
                        val plugins = CloudStreamRepositoryClient().discover(url)
                        "CloudStream repository" to "${plugins.size} plugin records found: ${plugins.take(6).joinToString { it.name }}"
                    }
                }.onSuccess { (name, details) -> reviewName = name; reviewDetails = details; reviewing = false }
                    .onFailure { error = it.message; reviewing = false }
            }
        }, enabled = url.isNotBlank() && !reviewing) { if (reviewing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.Security, null); Text(" Review source") } }
        reviewName?.let { name -> item {
            FocusCard(Modifier.fillMaxWidth().heightIn(min = 120.dp), onClick = {}) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(name, fontWeight = FontWeight.Black, fontSize = 20.sp)
                    Text(reviewDetails.orEmpty(), color = Muted)
                    Text("Host: ${runCatching { java.net.URI(url.replace("stremio://", "https://")).host }.getOrNull().orEmpty()}", color = Muted)
                    Button(onClick = {
                        val item = InstalledExtension("${kind.name}-${url.hashCode()}", name, url, kind, enabled = true, trusted = true)
                        installed = (installed.filterNot { it.id == item.id } + item); store.save(installed); reviewName = null; url = ""
                    }) { Icon(Icons.Default.Add, null); Text(" Install reviewed source") }
                }
            }
        } }
        error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
        item { HorizontalDivider(); Text("Installed sources", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
        if (installed.isEmpty()) item { Text("No extensions installed", color = Muted) }
        items(installed, key = { it.id }) { extension ->
            FocusCard(Modifier.fillMaxWidth().height(82.dp), onClick = {
                installed = installed.map { if (it.id == extension.id) it.copy(enabled = !it.enabled) else it }; store.save(installed)
            }) {
                Row(Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (extension.enabled) Icons.Default.ToggleOn else Icons.Default.ToggleOff, null, tint = if (extension.enabled) Color(0xFF46D369) else Muted)
                    Column(Modifier.padding(horizontal = 12.dp).weight(1f)) { Text(extension.name, fontWeight = FontWeight.Bold); Text("${extension.kind.name.replace('_', ' ')} • ${if (extension.enabled) "Enabled" else "Disabled"}", color = Muted, fontSize = 12.sp) }
                    TextButton(onClick = { installed = installed.filterNot { it.id == extension.id }; store.save(installed) }) { Text("Remove") }
                }
            }
        }
        item { Text("CloudStream repository metadata can be inspected and managed. Executable third-party plugin loading remains disabled until an audited sandbox runtime is available.", color = Muted, fontSize = 12.sp) }
    }
}

@Composable private fun SettingsScreen(profile: Profile, switchProfile: (Profile) -> Unit, deviceMode: DeviceMode, setDeviceMode: (DeviceMode) -> Unit, parental: ParentalControlStore, parentalUnlocked: Boolean, setParentalUnlocked: (Boolean) -> Unit, parentalChanged: () -> Unit) {
    val prefs = remember { PlaybackPreferences(LocalContext.current) }
    val secureStore = remember { SecureStore(LocalContext.current) }
    var buffer by remember { mutableStateOf(prefs.bufferMode) }; var subtitles by remember { mutableStateOf(prefs.subtitlesEnabled) }; var autoplay by remember { mutableStateOf(prefs.autoplayNext) }
    var parentalEnabled by remember { mutableStateOf(parental.enabled) }; var keywords by remember { mutableStateOf(parental.blockedKeywords) }; var pin by remember { mutableStateOf("") }; var pinMessage by remember { mutableStateOf<String?>(null) }
    var savedProfiles by remember { mutableStateOf(secureStore.profiles()) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Settings", fontSize = 34.sp, fontWeight = FontWeight.Black); Text("Profile: ${profile.name}"); Text("Source: ${profile.type}", color = Muted)
        Text("Provider profiles", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        savedProfiles.forEach { saved -> Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(8.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if (saved.type == SourceType.XTREAM) Icons.Default.Dns else Icons.Default.PlaylistPlay, null, tint = if (saved.id == profile.id) Mint else Muted); Column(Modifier.padding(horizontal = 12.dp).weight(1f)) { Text(saved.name, fontWeight = FontWeight.Bold); Text(saved.server.substringBefore("?").take(45), color = Muted, fontSize = 12.sp) }; if (saved.id != profile.id) TextButton(onClick = { switchProfile(saved) }) { Text("Connect") }; TextButton(onClick = { secureStore.deleteProfile(saved.id); savedProfiles = secureStore.profiles() }) { Text("Remove") } } }
        Text("Device layout", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { DeviceMode.entries.forEach { mode -> FilterChip(deviceMode == mode, { setDeviceMode(mode) }, { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }) } }
        Text("Playback buffer", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { BufferMode.entries.forEach { mode -> FilterChip(buffer == mode, { buffer = mode; prefs.bufferMode = mode }, { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }) } }
        Text("Fast is suited to responsive local networks; Large favors unstable connections and higher-bitrate streams.", color = Muted)
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(subtitles, { subtitles = it; prefs.subtitlesEnabled = it }); Text("  Enable subtitles by default") }
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(autoplay, { autoplay = it; prefs.autoplayNext = it }); Text("  Autoplay next VOD item") }
        HorizontalDivider(); Text("Parental controls", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(parentalEnabled, { parentalEnabled = it; parental.enabled = it; if (!it) setParentalUnlocked(false); parentalChanged() }); Text("  Hide restricted categories") }
        TvField(keywords, { keywords = it }, "Blocked words, separated by commas")
        OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(4) }, label = { Text("4-digit PIN") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(enabled = pin.length == 4, onClick = { secureStore.saveParentalPin(pin); parental.blockedKeywords = keywords; parental.enabled = true; parentalEnabled = true; setParentalUnlocked(false); parentalChanged(); pinMessage = "PIN and restrictions saved"; pin = "" }) { Icon(Icons.Default.Lock, null); Text(" Save PIN") }
            if (secureStore.hasParentalPin()) OutlinedButton(enabled = !parentalUnlocked && pin.length == 4, onClick = { val valid = secureStore.verifyParentalPin(pin); setParentalUnlocked(valid); pinMessage = if (valid) "Restricted content unlocked for this session" else "Incorrect PIN"; pin = "" }) { Icon(Icons.Default.LockOpen, null); Text(if (parentalUnlocked) "Unlocked" else "Unlock session") }
            if (parentalUnlocked) TextButton(onClick = { setParentalUnlocked(false); pinMessage = "Restricted content locked" }) { Text("Lock now") }
        }
        pinMessage?.let { Text(it, color = if (it.contains("Incorrect")) MaterialTheme.colorScheme.error else Color(0xFF46D369)) }
    }
}

@Composable private fun PlayerScreen(channel: Channel, content: List<Channel>, switchChannel: (Channel?) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember { PlaybackStore(context) }
    val preferences = remember { PlaybackPreferences(context) }
    val buffer = preferences.bufferMode
    val liveChannels = content.filter { it.kind == MediaKind.LIVE }
    val similarVod = content.filter { it.kind == channel.kind && it.streamUrl.isNotBlank() }
    val resume = remember(channel.id) { if (channel.kind == MediaKind.LIVE) 0L else store.progress(channel.id).positionMs }
    var playbackError by remember(channel.id) { mutableStateOf<String?>(null) }
    val player = remember(channel.id, buffer) { ExoPlayer.Builder(context).setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(buffer.minMs, buffer.maxMs, buffer.playbackMs, buffer.playbackMs * 2).build()).build().apply {
        trackSelectionParameters = trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !preferences.subtitlesEnabled).build()
        addListener(object : Player.Listener { override fun onPlayerError(error: PlaybackException) { playbackError = error.errorCodeName }; override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_ENDED && preferences.autoplayNext && channel.kind != MediaKind.LIVE && similarVod.size > 1) { val index = similarVod.indexOfFirst { it.id == channel.id }.coerceAtLeast(0); switchChannel(similarVod[(index + 1) % similarVod.size]) } } })
        setMediaItem(MediaItem.fromUri(channel.streamUrl)); prepare(); if (resume > 0) seekTo(resume); playWhenReady = true
    } }
    LaunchedEffect(player, channel.id) { while (true) { delay(5_000); if (channel.kind != MediaKind.LIVE) store.save(channel.id, player.currentPosition, player.duration) } }
    DisposableEffect(player) { onDispose { if (channel.kind != MediaKind.LIVE) store.save(channel.id, player.currentPosition, player.duration); player.release() } }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true; layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) } }, modifier = Modifier.fillMaxSize())
        Text(channel.name, Modifier.align(Alignment.TopStart).padding(22.dp).background(Color.Black.copy(alpha = .6f), RoundedCornerShape(8.dp)).padding(12.dp), fontWeight = FontWeight.Bold)
        IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopEnd).padding(18.dp)) { Icon(Icons.Default.Close, "Close player") }
        Row(Modifier.align(Alignment.TopCenter).padding(18.dp).background(Color.Black.copy(alpha = .68f), RoundedCornerShape(24.dp)).padding(horizontal = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = { TrackSelectionDialogBuilder(context, "Audio track", player, C.TRACK_TYPE_AUDIO).setShowDisableOption(false).build().show() }) { Icon(Icons.Default.AudioTrack, null); Text(" Audio") }
            TextButton(onClick = { TrackSelectionDialogBuilder(context, "Subtitles", player, C.TRACK_TYPE_TEXT).setShowDisableOption(true).build().show() }) { Icon(Icons.Default.Subtitles, null); Text(" Subtitles") }
        }
        if (channel.kind == MediaKind.LIVE && liveChannels.size > 1) {
            val index = liveChannels.indexOfFirst { it.id == channel.id }.coerceAtLeast(0)
            Row(Modifier.align(Alignment.BottomCenter).padding(28.dp).background(Color.Black.copy(alpha = .72f), RoundedCornerShape(30.dp)).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { switchChannel(liveChannels[(index - 1 + liveChannels.size) % liveChannels.size]) }) { Icon(Icons.Default.SkipPrevious, "Previous channel") }
                Text("Channel ${index + 1} of ${liveChannels.size}", modifier = Modifier.padding(horizontal = 18.dp))
                IconButton(onClick = { switchChannel(liveChannels[(index + 1) % liveChannels.size]) }) { Icon(Icons.Default.SkipNext, "Next channel") }
            }
        }
        playbackError?.let { error -> Row(Modifier.align(Alignment.Center).background(Color.Black.copy(alpha = .88f), RoundedCornerShape(12.dp)).padding(20.dp), verticalAlignment = Alignment.CenterVertically) { Text("Playback error: $error", color = Color.White); Button(onClick = { playbackError = null; player.prepare(); player.play() }, modifier = Modifier.padding(start = 14.dp)) { Icon(Icons.Default.Refresh, null); Text(" Retry") } } }
    }
}

@Composable private fun FocusCard(modifier: Modifier, onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(modifier.onFocusChanged { focused = it.isFocused }.border(if (focused) 3.dp else 0.dp, if (focused) Color.White else Color.Transparent, RoundedCornerShape(8.dp)).background(if (focused) Color(0xFF2B2B2B) else Panel, RoundedCornerShape(8.dp)).clickable(onClick = onClick).focusable(), content = content)
}
