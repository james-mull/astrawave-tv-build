# AstraWave TV

A remote-first Android TV and Fire TV media player for user-supplied Xtream Codes and M3U playlists.

## Included in this foundation

- Xtream Codes live-channel authentication and loading
- M3U/M3U8 parsing with channel names, logos, groups, and EPG identifiers
- Android Media3 playback for HLS and transport streams
- TV navigation, home, live channels, EPG shell, events, movies, series, debrid, and settings
- Channel matching for sports events using team and league aliases
- Encrypted local storage helper for debrid tokens
- Adapter boundary for Real-Debrid, AllDebrid, and Premiumize device authorization
- Stremio add-on manifest, catalog, and stream protocol client
- CloudStream repository metadata discovery with HTTPS enforcement
- Android TV and Fire TV launcher declarations

## Build

Open the folder in Android Studio or AndroidIDE (JDK 17), allow Gradle sync, and run the `app` configuration on an Android TV emulator or Fire TV device. To build a debug APK:

```bash
./gradlew assembleDebug
```

The included mobile bootstrap script downloads Gradle 8.9 the first time it runs. This is a large one-time download. The APK will be written to `app/build/outputs/apk/debug/app-debug.apk`.

The Android SDK is not bundled. AndroidIDE must finish its initial SDK setup before compiling.

## Required production work

1. Add XMLTV parsing and persist the guide in Room.
2. Implement the three debrid provider device flows using registered application IDs. Never embed private client secrets.
3. Select a licensed sports scores API and implement `SportsEventRepository`; replace demo event rows.
4. Load Xtream VOD and series endpoints, including seasons and episodes.
5. Add multiple profiles, favorites/history persistence, parental PINs, catch-up, subtitles, audio tracks, multi-view, and DVR where the source permits it.
6. Add release signing, privacy disclosures, provider terms, and automated tests.
7. Add extension persistence/review UI and an audited, signed CloudStream compatibility runtime. Arbitrary plugin execution is intentionally disabled in this milestone.

## Content policy

AstraWave contains no channels, playlists, sports feeds, movies, or series. Users must supply services and media they are authorized to access. Debrid integration is designed only for links the user is authorized to resolve.
