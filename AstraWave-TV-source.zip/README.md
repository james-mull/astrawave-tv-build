# AstraWave TV

## Cinematic browse experience

The Android TV interface now uses AstraWave's own red-and-black cinematic design with a featured hero, poster artwork, Continue Watching progress, Trending Now, Popular Series, Live Now, Top 10, genre rails, and Recently Added catalogs. Content and artwork are populated only from services the user connects and is authorized to use.

Universal search now filters across live channels, movies, series, groups, and provider identifiers. Movie and series cards open a cinematic detail page with provider metadata, collection labeling, My List state, trailer action, related titles, and direct playback.

## Trakt setup

Create a Trakt API application and provide its client ID at build time. Do not commit account tokens.

```bash
./gradlew :app:assembleDebug -PTRAKT_CLIENT_ID="your-client-id"
```

For GitHub Actions, create a repository secret named `TRAKT_CLIENT_ID` and append `-PTRAKT_CLIENT_ID="${{ secrets.TRAKT_CLIENT_ID }}"` to the Gradle build command. AstraWave uses Trakt's TV device-code authorization and encrypts returned tokens on the Android device.

## Debrid providers

Real-Debrid, AllDebrid, and Premiumize can be connected with the user's own API token. Tokens are encrypted on-device. The resolver accepts only explicit HTTP(S) links supplied by the user or an authorized connected source, calls the selected provider's official API, validates the returned HTTP(S) media URL, and hands it to Media3. AstraWave does not bundle catalogs, hoster links, torrents, credentials, or provider accounts.

## Extensions

Users can review and install their own HTTPS Stremio manifest or inspect a CloudStream-compatible repository index. The review card exposes the source host, declared resources, supported types, catalog count, version, and discovered plugin names before approval. Approved source metadata is persisted locally and can be enabled, disabled, or removed. AstraWave does not ship extension URLs, and executable CloudStream plugin loading is deliberately disabled until an audited sandbox exists.

## Live TV and EPG

Xtream profiles automatically load their XMLTV guide endpoint. M3U profiles can supply an optional XMLTV URL during setup. AstraWave parses programs, matches them using `epg_channel_id` or `tvg-id`, and displays searchable Now/Next rows, start and end times, live progress, favorites, and provider channel groups. Xtream category IDs are translated to their provider category names when available.

## Catch-up TV

Xtream live channels marked by the connected provider as archive-enabled appear under the Guide's Catch-up filter. Completed EPG programs within each channel's advertised archive window can be replayed through the provider's authenticated timeshift endpoint. AstraWave uses the portal-reported timezone when constructing requests and does not record, host, or supply archived programming.

## Xtream VOD catalogs

Xtream connections load live streams, VOD movies, and series in one account refresh. Movie and series category IDs are translated to provider category names. Movie entries include poster art, rating, year, plot, container-aware playback URLs, and direct Media3 playback. Series entries include cover/backdrop art and provider IDs ready for season and episode retrieval; AstraWave deliberately avoids treating a series-level catalog record as a playable stream.

Series details now request `get_series_info` on demand, parse all provider seasons and episodes, and display season selectors with episode numbers, titles, artwork, plots, duration, and rating. Episode container extensions are respected when constructing authorized Xtream playback URLs. Loading and empty states are shown without blocking the rest of the catalog.

## Playback continuity

Media3 playback positions and durations are saved locally every five seconds and when the player closes. Movies and episodes resume automatically. Detail buttons change to Resume when appropriate, episode rows display real progress or a watched marker after 90%, and the home Continue Watching rail contains only unfinished VOD. Live TV is intentionally excluded from resume tracking.

Player settings persist Fast, Balanced, or Large buffering presets, default subtitle state, and VOD autoplay. The full-screen player offers previous/next channel switching for live TV, advances to the next available VOD item when autoplay is enabled, and displays a focused retry action with the Media3 error code when playback fails.

The player also exposes dedicated Audio and Subtitles buttons. Media3 enumerates the tracks supplied by the connected stream, labels the available languages and formats, applies the selected audio track immediately, and lets viewers choose a subtitle track or disable subtitles. The provider stream determines which choices are available.

## TV, phone, and tablet layouts

On first launch AstraWave detects the Android UI mode and recommends TV, Phone, or Tablet while allowing the user to override it. TV mode uses landscape orientation and a D-pad navigation rail. Phone mode permits device rotation and uses a touch-friendly, horizontally scrollable bottom navigation bar. Tablet mode uses a compact adaptive sidebar. The saved selection can be changed from Settings without signing in again.

## Live sports events

The Live Events section loads today's schedules and available scores from TheSportsDB v1, supports league filters and manual refresh, and limits automatic refreshes to once every two minutes. The included `123` key is TheSportsDB's documented free development key; production builds can pass `-PSPORTSDB_API_KEY="your-key"`. Event team and league terms are ranked against the user's playlist only, with match confidence and reasons displayed before playback. AstraWave does not provide sports channels.

## Parental controls

Settings can protect restricted content with a four-digit PIN stored in Android encrypted preferences. Parents can configure comma-separated title and category keywords, hide matching live channels, movies, and series, unlock them for the current session, or lock them again immediately. Filtering happens before home, search, guide, catalogs, related titles, Trakt rows, sports channel matching, and player channel switching receive content.

## Provider profiles

Xtream and M3U profiles can be saved with friendly names in Android encrypted preferences. The login screen offers one-tap reconnection to saved profiles, while Settings lists the active profile and allows switching to or removing another profile. Portal usernames and passwords are never displayed in the profile manager.

## Persistent favorites

Live-channel favorites and VOD My List selections persist across app restarts. Each saved provider profile has an isolated favorites set, preventing similarly named or numbered content from another portal from appearing in the wrong list.

## Games and emulators

The Games section detects and launches installed RetroArch, PPSSPP, Dolphin, and DuckStation apps. If one is missing, AstraWave opens its verified official download page; Android retains all browser and installer confirmations. Users can add legally obtained game files with Android's Storage Access Framework, retain read access, open them with a compatible installed emulator, and remove them from AstraWave's list. AstraWave contains no ROMs, BIOS files, or copyrighted game downloads.

A remote-first Android TV and Fire TV media player for user-supplied Xtream Codes and M3U playlists.

## Included in this foundation

- Xtream Codes live-channel authentication and loading
- M3U/M3U8 parsing with channel names, logos, groups, and EPG identifiers
- Android Media3 playback for HLS and transport streams
- TV navigation, home, live channels, EPG shell, events, movies, series, debrid, and settings
- Channel matching for sports events using team and league aliases
- Encrypted local storage helper for debrid tokens
- Adapter boundary for Real-Debrid, AllDebrid, and Premiumize device authorization
- Stremio add-on manifest, catalog, and stream protocol client
- CloudStream repository metadata discovery with HTTPS enforcement
- Android TV and Fire TV launcher declarations

## Build

Open the folder in Android Studio or AndroidIDE (JDK 17), allow Gradle sync, and run the `app` configuration on an Android TV emulator or Fire TV device. To build a debug APK:

```bash
./gradlew assembleDebug
```

The included mobile bootstrap script downloads Gradle 8.9 the first time it runs. This is a large one-time download. The APK will be written to `app/build/outputs/apk/debug/app-debug.apk`.

The Android SDK is not bundled. AndroidIDE must finish its initial SDK setup before compiling.

## Required production work

1. Add XMLTV parsing and persist the guide in Room.
2. Implement the three debrid provider device flows using registered application IDs. Never embed private client secrets.
3. Select a licensed sports scores API and implement `SportsEventRepository`; replace demo event rows.
4. Load Xtream VOD and series endpoints, including seasons and episodes.
5. Add multi-view and DVR where the source permits it.
6. Add release signing, privacy disclosures, provider terms, and automated tests.
7. Add extension persistence/review UI and an audited, signed CloudStream compatibility runtime. Arbitrary plugin execution is intentionally disabled in this milestone.

## Content policy

AstraWave contains no channels, playlists, sports feeds, movies, or series. Users must supply services and media they are authorized to access. Debrid integration is designed only for links the user is authorized to resolve.
