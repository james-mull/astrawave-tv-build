package tv.astrawave.player.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import tv.astrawave.player.model.DebridProvider

class SecureStore(context: Context) {
    private val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
    private val prefs = EncryptedSharedPreferences.create(
        context, "astrawave_secure", key,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveDebridToken(provider: DebridProvider, token: String) =
        prefs.edit().putString("debrid_${provider.name}", token).apply()

    fun debridToken(provider: DebridProvider): String? = prefs.getString("debrid_${provider.name}", null)
    fun clearDebrid(provider: DebridProvider) = prefs.edit().remove("debrid_${provider.name}").apply()
}
