package tv.astrawave.player.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import tv.astrawave.player.model.DebridProvider
import tv.astrawave.player.model.Profile

class SecureStore(context: Context) {
    private val prefs: SharedPreferences = createEncryptedPreferences(context)

    private fun createEncryptedPreferences(context: Context): SharedPreferences {
        fun open(): SharedPreferences {
            val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            return EncryptedSharedPreferences.create(
                context, "astrawave_secure", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
        return runCatching(::open).getOrElse { firstError ->
            // A debug APK signed on a different machine can leave encrypted
            // preferences that the replacement install can no longer decrypt.
            // Reset only this app-owned credential store and rebuild it securely.
            context.deleteSharedPreferences("astrawave_secure")
            runCatching(::open).getOrElse { throw IllegalStateException("Secure account storage is unavailable", firstError) }
        }
    }

    fun saveDebridToken(provider: DebridProvider, token: String) =
        prefs.edit().putString("debrid_${provider.name}", token).apply()

    fun debridToken(provider: DebridProvider): String? = prefs.getString("debrid_${provider.name}", null)
    fun clearDebrid(provider: DebridProvider) = prefs.edit().remove("debrid_${provider.name}").apply()

    fun saveTraktTokens(accessToken: String, refreshToken: String) = prefs.edit().putString("trakt_access", accessToken).putString("trakt_refresh", refreshToken).apply()
    fun traktAccessToken(): String? = prefs.getString("trakt_access", null)
    fun clearTrakt() = prefs.edit().remove("trakt_access").remove("trakt_refresh").apply()
    fun saveParentalPin(pin: String) = prefs.edit().putString("parental_pin", pin).apply()
    fun hasParentalPin(): Boolean = prefs.contains("parental_pin")
    fun verifyParentalPin(pin: String): Boolean = pin.length == 4 && prefs.getString("parental_pin", null) == pin

    fun profiles(): List<Profile> = runCatching { Json.decodeFromString<List<Profile>>(prefs.getString("profiles", "[]")!!) }.getOrDefault(emptyList())
    fun saveProfile(profile: Profile) {
        val updated = profiles().filterNot { it.id == profile.id } + profile
        prefs.edit().putString("profiles", Json.encodeToString(updated)).apply()
    }
    fun deleteProfile(id: String) = prefs.edit().putString("profiles", Json.encodeToString(profiles().filterNot { it.id == id })).apply()
}
