package tv.astrawave.player.data

import android.content.Context

class FavoritesStore(context: Context) {
    private val prefs = context.getSharedPreferences("astrawave_favorites", Context.MODE_PRIVATE)

    fun favorites(profileId: String): Set<String> =
        prefs.getStringSet(key(profileId), emptySet()).orEmpty().toSet()

    fun save(profileId: String, favorites: Set<String>) {
        prefs.edit().putStringSet(key(profileId), favorites.toSet()).apply()
    }

    private fun key(profileId: String) = "profile_$profileId"
}
