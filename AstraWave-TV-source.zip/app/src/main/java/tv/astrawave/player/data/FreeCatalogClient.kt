package tv.astrawave.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import tv.astrawave.player.model.Channel
import tv.astrawave.player.model.MediaKind
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Keyless discovery metadata. Stremio Cinemeta supplies English movie metadata
 * and TVmaze supplies current US/English television metadata. Neither service is
 * used as a playback source; playback remains with the user's IPTV provider or
 * connected debrid cloud.
 */
class FreeCatalogClient(
    private val http: OkHttpClient = OkHttpClient.Builder().callTimeout(14, TimeUnit.SECONDS).build(),
    private val json: Json = Json { ignoreUnknownKeys = true }
) {
    suspend fun catalogs(): TmdbCatalogs = coroutineScope {
        val movieDeferred = async { runCatching { movieCatalogs() } }
        val seriesDeferred = async { runCatching { seriesCatalogs() } }
        val movies = movieDeferred.await()
        val series = seriesDeferred.await()
        if (movies.isFailure && series.isFailure) throw movies.exceptionOrNull() ?: series.exceptionOrNull()!!
        TmdbCatalogs(movies.getOrDefault(emptyList()), series.getOrDefault(emptyList()))
    }

    suspend fun search(query: String, kind: MediaKind): List<Channel> = when (kind) {
        MediaKind.MOVIE -> cinemetaSearch(query, MediaKind.MOVIE)
        MediaKind.SERIES -> tvmazeSearch(query)
        else -> emptyList()
    }

    private suspend fun movieCatalogs(): List<CuratedShelf> = coroutineScope {
        val requests = listOf(
            Triple("Popular Movies", "top", null),
            Triple("New Movies", "year", Calendar.getInstance().get(Calendar.YEAR).toString()),
            Triple("Top Rated", "imdbRating", null),
            Triple("Action & Adventure", "top", "Action"),
            Triple("Thrillers & Mysteries", "top", "Thriller"),
            Triple("Comedy Night", "top", "Comedy"),
            Triple("Horror After Dark", "top", "Horror"),
            Triple("Science Fiction", "top", "Sci-Fi"),
            Triple("Family Movies", "top", "Family"),
            Triple("Documentaries", "top", "Documentary")
        )
        requests.map { (title, catalog, genre) ->
            async {
                runCatching { cinemetaCatalog(MediaKind.MOVIE, catalog, genre) }.getOrDefault(emptyList())
                    .distinctBy { normalizeTitle(it.name) }
                    .take(20)
                    .takeIf { it.isNotEmpty() }
                    ?.let { CuratedShelf(title, "English discovery • no API key required", it) }
            }
        }.awaitAll().filterNotNull()
    }

    private suspend fun cinemetaCatalog(kind: MediaKind, catalog: String, genre: String?): List<Channel> = withContext(Dispatchers.IO) {
        val type = if (kind == MediaKind.MOVIE) "movie" else "series"
        val extra = genre?.let { "/genre=${encode(it)}" }.orEmpty()
        parseCinemeta(execute("https://v3-cinemeta.strem.io/catalog/$type/$catalog$extra.json"), kind)
    }

    private suspend fun cinemetaSearch(query: String, kind: MediaKind): List<Channel> = withContext(Dispatchers.IO) {
        val type = if (kind == MediaKind.MOVIE) "movie" else "series"
        parseCinemeta(execute("https://v3-cinemeta.strem.io/catalog/$type/top/search=${encode(query)}.json"), kind).take(50)
    }

    private fun parseCinemeta(root: kotlinx.serialization.json.JsonElement, kind: MediaKind): List<Channel> =
        root.jsonObject["metas"]?.jsonArray.orEmpty().mapNotNull { node ->
            val o = node.jsonObject
            val id = o["id"]?.jsonPrimitive?.contentOrNull ?: o["imdb_id"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
            val name = o["name"]?.jsonPrimitive?.contentOrNull?.takeIf(String::isNotBlank) ?: return@mapNotNull null
            val country = o["country"]?.jsonPrimitive?.contentOrNull.orEmpty()
            if (country.isNotBlank() && !country.contains("United States", true) && !country.contains("USA", true)) return@mapNotNull null
            val genres = (o["genres"] ?: o["genre"])?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull }.orEmpty()
            Channel(
                id = "cinemeta-${kind.name.lowercase()}-$id",
                name = name,
                streamUrl = "",
                logo = o["poster"]?.jsonPrimitive?.contentOrNull,
                backdrop = o["background"]?.jsonPrimitive?.contentOrNull,
                group = genres.firstOrNull() ?: if (kind == MediaKind.MOVIE) "Movies" else "Series",
                kind = kind,
                plot = o["description"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                year = (o["year"] ?: o["releaseInfo"])?.jsonPrimitive?.contentOrNull.orEmpty().take(4),
                rating = o["imdbRating"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                externalId = id
            )
        }

    private suspend fun seriesCatalogs(): List<CuratedShelf> = coroutineScope {
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val base = Calendar.getInstance()
        val dates = (-1..3).map { offset ->
            (base.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, offset) }.let { formatter.format(it.time) }
        }
        val scheduled = dates.flatMap { date ->
            listOf(false, true).map { web -> async { runCatching { tvmazeSchedule(date, web) }.getOrDefault(emptyList()) } }
        }.awaitAll().flatten().distinctBy { normalizeTitle(it.name) }
        val ranked = scheduled.sortedWith(compareByDescending<Channel> { it.rating.toDoubleOrNull() ?: 0.0 }.thenBy { it.name })
        buildList {
            ranked.take(20).takeIf { it.isNotEmpty() }?.let { add(CuratedShelf("Airing This Week in the USA", "US broadcast and streaming schedules • no API key required", it)) }
            shelf("Popular US & English Series", "Currently airing English-language series", ranked) { true }?.let(::add)
            shelf("Drama", "Current drama series", ranked) { it.group.contains("Drama", true) }?.let(::add)
            shelf("Crime & Mystery", "Crime, mystery and thriller series", ranked) { text(it).containsAny("crime", "mystery", "thriller") }?.let(::add)
            shelf("Comedy", "Current comedy series", ranked) { text(it).contains("comedy") }?.let(::add)
            shelf("Sci-Fi & Fantasy", "Current speculative series", ranked) { text(it).containsAny("science-fiction", "science fiction", "fantasy", "supernatural") }?.let(::add)
            shelf("Reality & Competition", "Reality, competition and game shows", ranked) { text(it).containsAny("reality", "game show", "competition") }?.let(::add)
            shelf("Documentary & Factual", "Documentary, news and factual series", ranked) { text(it).containsAny("documentary", "news") }?.let(::add)
        }
    }

    private suspend fun tvmazeSchedule(date: String, web: Boolean): List<Channel> = withContext(Dispatchers.IO) {
        val endpoint = if (web) "https://api.tvmaze.com/schedule/web" else "https://api.tvmaze.com/schedule"
        val url = endpoint.toHttpUrl().newBuilder().addQueryParameter("country", "US").addQueryParameter("date", date).build()
        (execute(url.toString()) as? JsonArray).orEmpty().mapNotNull { node -> parseTvmazeShow(node.jsonObject["show"]?.jsonObject ?: return@mapNotNull null) }
    }

    private suspend fun tvmazeSearch(query: String): List<Channel> = withContext(Dispatchers.IO) {
        val url = "https://api.tvmaze.com/search/shows".toHttpUrl().newBuilder().addQueryParameter("q", query).build()
        (execute(url.toString()) as? JsonArray).orEmpty().mapNotNull { node ->
            parseTvmazeShow(node.jsonObject["show"]?.jsonObject ?: return@mapNotNull null)
        }.filter { it.group.isNotBlank() }.distinctBy { normalizeTitle(it.name) }.take(50)
    }

    private fun parseTvmazeShow(o: kotlinx.serialization.json.JsonObject): Channel? {
        val id = o["id"]?.jsonPrimitive?.contentOrNull ?: return null
        val name = o["name"]?.jsonPrimitive?.contentOrNull?.takeIf(String::isNotBlank) ?: return null
        val language = o["language"]?.jsonPrimitive?.contentOrNull.orEmpty()
        val country = runCatching { o["network"]?.jsonObject?.get("country")?.jsonObject?.get("code")?.jsonPrimitive?.contentOrNull }.getOrNull()
            ?: runCatching { o["webChannel"]?.jsonObject?.get("country")?.jsonObject?.get("code")?.jsonPrimitive?.contentOrNull }.getOrNull()
        if (!language.equals("English", true) || (country != null && country != "US")) return null
        val genres = o["genres"]?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull }.orEmpty()
        val type = o["type"]?.jsonPrimitive?.contentOrNull.orEmpty()
        val image = runCatching { o["image"]?.jsonObject }.getOrNull()
        val imdb = runCatching { o["externals"]?.jsonObject?.get("imdb")?.jsonPrimitive?.contentOrNull }.getOrNull()
        return Channel(
            id = "tvmaze-series-$id",
            name = name,
            streamUrl = "",
            logo = image?.get("medium")?.jsonPrimitive?.contentOrNull,
            backdrop = image?.get("original")?.jsonPrimitive?.contentOrNull,
            group = genres.firstOrNull() ?: type.ifBlank { "Series" },
            kind = MediaKind.SERIES,
            plot = stripHtml(o["summary"]?.jsonPrimitive?.contentOrNull.orEmpty()),
            year = o["premiered"]?.jsonPrimitive?.contentOrNull.orEmpty().take(4),
            rating = runCatching { o["rating"]?.jsonObject?.get("average")?.jsonPrimitive?.doubleOrNull }.getOrNull()?.let { String.format(Locale.US, "%.1f", it) }.orEmpty(),
            externalId = imdb ?: "tvmaze:$id"
        )
    }

    private fun execute(url: String) = http.newCall(Request.Builder().url(url).header("User-Agent", "AstraWaveTV/0.6").build()).execute().use { response ->
        if (!response.isSuccessful) error("Catalog service returned HTTP ${response.code}")
        json.parseToJsonElement(response.body?.string().orEmpty())
    }

    private fun shelf(title: String, note: String, items: List<Channel>, predicate: (Channel) -> Boolean): CuratedShelf? =
        items.filter(predicate).take(20).takeIf { it.size >= 3 }?.let { CuratedShelf(title, note, it) }

    private fun text(item: Channel) = "${item.group} ${item.plot}".lowercase(Locale.US)
    private fun String.containsAny(vararg values: String) = values.any(::contains)
    private fun normalizeTitle(value: String) = value.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), " ").trim()
    private fun encode(value: String) = URLEncoder.encode(value, "UTF-8").replace("+", "%20")
    private fun stripHtml(value: String) = value.replace(Regex("<[^>]+>"), " ").replace("&amp;", "&").replace("&quot;", "\"").replace(Regex("\\s+"), " ").trim()
}
