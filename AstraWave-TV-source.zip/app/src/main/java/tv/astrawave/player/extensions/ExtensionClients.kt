package tv.astrawave.player.extensions

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder

class StremioAddonClient(private val http: OkHttpClient = OkHttpClient()) {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun manifest(input: String): StremioManifest = withContext(Dispatchers.IO) {
        val url = normalizeManifestUrl(input)
        val element = json.parseToJsonElement(get(url)).jsonObject
        StremioManifest(
            id = element.req("id"), name = element.req("name"),
            description = element["description"]?.jsonPrimitive?.content.orEmpty(),
            version = element.req("version"),
            resources = element["resources"]?.jsonArray?.map { resource ->
                ResourceRef(if (resource is JsonPrimitive) resource.content else resource.jsonObject.req("name"))
            }.orEmpty(),
            types = element["types"]?.jsonArray?.map { it.jsonPrimitive.content }.orEmpty(),
            catalogs = element["catalogs"]?.jsonArray?.map { item ->
                val o = item.jsonObject
                StremioCatalog(o.req("type"), o.req("id"), o["name"]?.jsonPrimitive?.content)
            }.orEmpty()
        )
    }

    suspend fun catalog(manifestUrl: String, type: String, id: String, search: String? = null): List<StremioMeta> = withContext(Dispatchers.IO) {
        val base = normalizeManifestUrl(manifestUrl).removeSuffix("/manifest.json")
        val extra = search?.let { "/search=${enc(it)}" }.orEmpty()
        json.decodeFromString<CatalogResponse>(get("$base/catalog/${enc(type)}/${enc(id)}$extra.json")).metas
    }

    suspend fun streams(manifestUrl: String, type: String, id: String): List<StremioStream> = withContext(Dispatchers.IO) {
        val base = normalizeManifestUrl(manifestUrl).removeSuffix("/manifest.json")
        json.decodeFromString<StreamResponse>(get("$base/stream/${enc(type)}/${enc(id)}.json")).streams
    }

    private fun normalizeManifestUrl(input: String): String {
        val https = input.trim().replace(Regex("^stremio://", RegexOption.IGNORE_CASE), "https://")
        require(https.startsWith("https://") || https.startsWith("http://127.0.0.1")) { "Extensions must use HTTPS (localhost excepted)" }
        return if (https.endsWith("manifest.json")) https else "${https.trimEnd('/')}/manifest.json"
    }

    private fun get(url: String): String {
        val request = Request.Builder().url(url).header("User-Agent", "AstraWaveTV/0.1").build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Extension returned HTTP ${response.code}")
            return response.body?.string() ?: error("Extension returned no data")
        }
    }

    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")
    private fun JsonObject.req(name: String) = this[name]?.jsonPrimitive?.content ?: error("Manifest is missing $name")
}

class CloudStreamRepositoryClient(private val http: OkHttpClient = OkHttpClient()) {
    private val json = Json { ignoreUnknownKeys = true }

    /** Reads repository metadata only. Executable plugin loading requires a separately
     * audited compatibility runtime, signature verification, and explicit consent. */
    suspend fun discover(repositoryUrl: String): List<CloudStreamPlugin> = withContext(Dispatchers.IO) {
        require(repositoryUrl.startsWith("https://")) { "Repository must use HTTPS" }
        val request = Request.Builder().url(repositoryUrl).header("User-Agent", "AstraWaveTV/0.1").build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Repository returned HTTP ${response.code}")
            val root = json.parseToJsonElement(response.body?.string().orEmpty())
            val items = when (root) {
                is JsonArray -> root
                is JsonObject -> root["plugins"]?.jsonArray ?: JsonArray(emptyList())
                else -> JsonArray(emptyList())
            }
            items.mapNotNull { runCatching { json.decodeFromJsonElement<CloudStreamPlugin>(it) }.getOrNull() }
        }
    }
}
