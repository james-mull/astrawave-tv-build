package tv.astrawave.player

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import tv.astrawave.player.ui.AstraWaveApp
import tv.astrawave.player.ui.AstraWaveTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AstraWaveTheme { AstraWaveApp() } }
    }
}
