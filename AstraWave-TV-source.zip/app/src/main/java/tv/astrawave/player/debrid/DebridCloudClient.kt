package tv.astrawave.player.debrid

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import tv.astrawave.player.model.DebridProvider
import java.util.Locale
import java.util.concurrent.TimeUnit

data class DebridCloudFile(
    val id: String,
    val name: String,
    val url: String,
    val sizeBytes: Long,
    val provider: DebridProvider,
    val needsUnlock: Boolean = false
)

class DebridCloudClient(
    private val http: OkHttpClient = OkHttpClient.Builder().callTimeout(15, TimeUnit.SECONDS).build(),
    private val json: Json = Json { ignoreUnknownKeys = true }
) {
    suspend fun search(provider: DebridProvider, token: String, title: String, season: Int? = null, episode: Int? = null): List<DebridCloudFile> = withContext(Dispatchers.IO) {
        require(token.isNotBlank()) { "Connect ${provider.label()} first" }
        val files = when (provider) {
            DebridProvider.REAL_DEBRID -> realDebrid(token)
            DebridProvider.ALL_DEBRID -> allDebrid(token)
            DebridProvider.PREMIUMIZE -> premiumize(token)
        }
        val wanted = normalize(title)
        files.asSequence().filter { file ->
            val name = normalize(file.name)
            val titleMatch = wanted.isNotBlank() && if (wanted.length <= 3) Regex("(^| )${Regex.escape(wanted)}( |$)").containsMatchIn(name) else name.contains(wanted) || wanted.contains(name.takeIf { it.length > 5 }.orEmpty())
            val episodeMatch = if (season != null && episode != null) {
                val code = "s${season.toString().padStart(2, '0')}e${episode.toString().padStart(2, '0')}"
                name.contains(code) || name.contains("season $season episode $episode")
            } else true
            titleMatch && episodeMatch && isVideo(file.name)
        }.sortedWith(compareByDescending<DebridCloudFile> { quality(it.name) }.thenByDescending { it.sizeBytes }).take(40).toList()
    }

    private fun realDebrid(token: String): List<DebridCloudFile> {
        val root = execute(Request.Builder().url("https://api.real-debrid.com/rest/1.0/downloads?limit=5000").bearer(token).build())
        return root.jsonArray.mapNotNull { node ->
            val item = node.jsonObject
            val url = item["download"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
            val name = item["filename"]?.jsonPrimitive?.contentOrNull.orEmpty().ifBlank { "Debrid file" }
            DebridCloudFile(item["id"]?.jsonPrimitive?.contentOrNull ?: url.hashCode().toString(), name, url, item["filesize"]?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L, DebridProvider.REAL_DEBRID)
        }
    }

    private fun allDebrid(token: String): List<DebridCloudFile> {
        val data = execute(Request.Builder().url("https://api.alldebrid.com/v4/user/links").bearer(token).build()).jsonObject["data"]?.jsonObject
        return data?.get("links")?.jsonArray.orEmpty().mapNotNull { node ->
            val item = node.jsonObject
            val url = item["link"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
            val name = item["filename"]?.jsonPrimitive?.contentOrNull.orEmpty().ifBlank { "Debrid file" }
            DebridCloudFile(url.hashCode().toString(), name, url, item["size"]?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L, DebridProvider.ALL_DEBRID, needsUnlock = true)
        }
    }

    private fun premiumize(token: String): List<DebridCloudFile> {
        val root = execute(Request.Builder().url("https://www.premiumize.me/api/folder/list").bearer(token).build()).jsonObject
        return premiumizeFiles(root["content"]?.jsonArray ?: JsonArray(emptyList()), token, depth = 0)
    }

    private fun premiumizeFiles(items: JsonArray, token: String, depth: Int): List<DebridCloudFile> = items.flatMap { node ->
        val item = node.jsonObject
        val id = item["id"]?.jsonPrimitive?.contentOrNull.orEmpty()
        if (item["type"]?.jsonPrimitive?.contentOrNull == "folder" && depth < 1 && id.isNotBlank()) {
            val nested = execute(Request.Builder().url("https://www.premiumize.me/api/folder/list?id=$id").bearer(token).build()).jsonObject
            premiumizeFiles(nested["content"]?.jsonArray ?: JsonArray(emptyList()), token, depth + 1)
        } else {
            val url = item["link"]?.jsonPrimitive?.contentOrNull
            if (url == null) emptyList() else listOf(DebridCloudFile(id.ifBlank { url.hashCode().toString() }, item["name"]?.jsonPrimitive?.contentOrNull.orEmpty().ifBlank { "Debrid file" }, url, item["size"]?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L, DebridProvider.PREMIUMIZE))
        }
    }

    private fun execute(request: Request) = http.newCall(request).execute().use { response ->
        val body = response.body?.string().orEmpty()
        if (!response.isSuccessful) error("Debrid library request failed (${response.code})")
        json.parseToJsonElement(body).also { element ->
            if (element is JsonObject && (element["status"]?.jsonPrimitive?.contentOrNull == "error" || element["error"] != null)) error("Debrid provider rejected the library request")
        }
    }

    private fun Request.Builder.bearer(token: String) = header("Authorization", "Bearer $token").header("Accept", "application/json")
    private fun normalize(value: String) = value.lowercase(Locale.US).replace(Regex("\\b(19|20)\\d{2}\\b"), " ").replace(Regex("[^a-z0-9]+"), " ").trim()
    private fun isVideo(name: String) = listOf(".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".m2ts", ".webm").any { name.substringBefore('?').endsWith(it, true) }
    private fun quality(name: String): Int { val n = name.lowercase(Locale.US); return when { "2160" in n || "4k" in n -> 4; "1080" in n -> 3; "720" in n -> 2; else -> 1 } }
    private fun DebridProvider.label() = name.lowercase().replace('_', ' ').replaceFirstChar(Char::uppercase)
}
