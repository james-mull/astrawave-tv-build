package tv.astrawave.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import tv.astrawave.player.model.Channel
import tv.astrawave.player.model.MediaKind
import java.util.Locale
import java.util.concurrent.TimeUnit

data class TmdbCatalogs(val movies: List<CuratedShelf>, val series: List<CuratedShelf>)

class TmdbCatalogClient(
    private val credential: String,
    private val http: OkHttpClient = OkHttpClient.Builder().callTimeout(12, TimeUnit.SECONDS).build(),
    private val json: Json = Json { ignoreUnknownKeys = true }
) {
    val configured: Boolean get() = credential.isNotBlank()

    suspend fun catalogs(providerContent: List<Channel>): TmdbCatalogs = coroutineScope {
        require(configured) { "TMDB catalog key is not configured" }
        val movieContent = providerContent.filter { it.kind == MediaKind.MOVIE }
        val seriesContent = providerContent.filter { it.kind == MediaKind.SERIES }
        val movieIndex = withContext(Dispatchers.Default) { movieContent.groupBy { normalizedTitle(it.name) } }
        val seriesIndex = withContext(Dispatchers.Default) { seriesContent.groupBy { normalizedTitle(it.name) } }
        val movieRequests = listOf(
            CatalogRequest("Trending Movies This Week", "What people are watching now", "trending/movie/week", kind = MediaKind.MOVIE),
            CatalogRequest("Popular on TMDB", "Popular movies available through your connected sources", "movie/popular", mapOf("region" to "US"), MediaKind.MOVIE),
            CatalogRequest("Top Rated Movies", "Highly rated movies from TMDB", "movie/top_rated", mapOf("region" to "US"), MediaKind.MOVIE),
            CatalogRequest("Now Playing in the USA", "Current theatrical releases", "movie/now_playing", mapOf("region" to "US"), MediaKind.MOVIE),
            CatalogRequest("Mind-Bending Sci-Fi", "Science fiction and thrillers with strong audience activity", "discover/movie", mapOf("with_genres" to "878,53", "sort_by" to "vote_average.desc", "vote_count.gte" to "250")),
            CatalogRequest("Crime & Mystery", "Crime and mystery favorites", "discover/movie", mapOf("with_genres" to "80,9648", "sort_by" to "popularity.desc")),
            CatalogRequest("Critically Acclaimed", "Highly rated films with a substantial audience", "discover/movie", mapOf("sort_by" to "vote_average.desc", "vote_count.gte" to "1000")),
            CatalogRequest("Hidden Gems", "Well-rated films beyond the biggest releases", "discover/movie", mapOf("sort_by" to "vote_average.desc", "vote_count.gte" to "100", "vote_count.lte" to "1500")),
            CatalogRequest("Comedy Night", "Popular comedies available in your provider library", "discover/movie", mapOf("with_genres" to "35", "sort_by" to "popularity.desc")),
            CatalogRequest("Action & Adventure", "Popular action and adventure movies", "discover/movie", mapOf("with_genres" to "28,12", "sort_by" to "popularity.desc")),
            CatalogRequest("Horror After Dark", "Popular horror movies matched to your library", "discover/movie", mapOf("with_genres" to "27", "sort_by" to "popularity.desc")),
            CatalogRequest("Family Movie Night", "Popular animation and family movies", "discover/movie", mapOf("with_genres" to "16,10751", "sort_by" to "popularity.desc")),
            CatalogRequest("Documentary Spotlight", "Popular documentaries available from your provider", "discover/movie", mapOf("with_genres" to "99", "sort_by" to "popularity.desc")),
            CatalogRequest("90s Rewind", "Popular movies released during the 1990s", "discover/movie", mapOf("primary_release_date.gte" to "1990-01-01", "primary_release_date.lte" to "1999-12-31", "sort_by" to "popularity.desc"))
        )
        val seriesRequests = listOf(
            CatalogRequest("Trending TV This Week", "Series people are watching now", "trending/tv/week"),
            CatalogRequest("Popular TV", "Popular series matched to your provider", "tv/popular"),
            CatalogRequest("Top Rated TV", "Highly rated series available from your provider", "tv/top_rated"),
            CatalogRequest("On the Air", "Currently airing series matched to your library", "tv/on_the_air"),
            CatalogRequest("Sci-Fi & Mystery TV", "Science fiction and mystery series", "discover/tv", mapOf("with_genres" to "10765,9648", "sort_by" to "popularity.desc")),
            CatalogRequest("Critically Acclaimed TV", "Highly rated series with a substantial audience", "discover/tv", mapOf("sort_by" to "vote_average.desc", "vote_count.gte" to "500")),
            CatalogRequest("Crime & Drama TV", "Popular crime and drama series", "discover/tv", mapOf("with_genres" to "80,18", "sort_by" to "popularity.desc")),
            CatalogRequest("Comedy Series", "Popular comedy series", "discover/tv", mapOf("with_genres" to "35", "sort_by" to "popularity.desc")),
            CatalogRequest("Reality & Competition", "Popular reality and competition shows", "discover/tv", mapOf("with_genres" to "10764", "sort_by" to "popularity.desc")),
            CatalogRequest("Documentary Series", "Documentary and factual series", "discover/tv", mapOf("with_genres" to "99", "sort_by" to "popularity.desc")),
            CatalogRequest("Family TV", "Family and kids series", "discover/tv", mapOf("with_genres" to "10751,10762", "sort_by" to "popularity.desc"))
        )
        // Catalog endpoints are independent. A transient failure or empty match
        // in one row must not hide every other useful row.
        val normalizedMovieRequests = movieRequests.map { if (it.kind == null) it.copy(kind = MediaKind.MOVIE) else it }
        val normalizedSeriesRequests = seriesRequests.map { if (it.kind == null) it.copy(kind = MediaKind.SERIES) else it }
        val movieResults = normalizedMovieRequests.map { request -> async { runCatching { loadShelf(request, movieIndex) } } }.awaitAll()
        val seriesResults = normalizedSeriesRequests.map { request -> async { runCatching { loadShelf(request, seriesIndex) } } }.awaitAll()
        val results = movieResults + seriesResults
        if (results.all { it.isFailure }) throw results.firstNotNullOf { it.exceptionOrNull() }
        val movies = movieResults.mapNotNull { it.getOrNull() }
        val series = seriesResults.mapNotNull { it.getOrNull() }
        TmdbCatalogs(movies, series)
    }

    private suspend fun loadShelf(request: CatalogRequest, providerIndex: Map<String, List<Channel>>): CuratedShelf? = withContext(Dispatchers.IO) {
        val url = "https://api.themoviedb.org/3/${request.path}".toHttpUrl().newBuilder().apply {
            addQueryParameter("language", "en-US")
            request.parameters.forEach { (name, value) -> addQueryParameter(name, value) }
            if (!credential.startsWith("eyJ")) addQueryParameter("api_key", credential)
        }.build()
        val call = Request.Builder().url(url).header("Accept", "application/json").apply {
            if (credential.startsWith("eyJ")) header("Authorization", "Bearer $credential")
        }.build()
        http.newCall(call).execute().use { response ->
            if (!response.isSuccessful) error("TMDB returned HTTP ${response.code}")
            val results = json.parseToJsonElement(response.body?.string().orEmpty()).jsonObject["results"]?.jsonArray.orEmpty()
            val matched = results.asSequence().mapNotNull { node ->
                val item = node.jsonObject
                val aliases = sequenceOf(
                    item["title"]?.jsonPrimitive?.contentOrNull,
                    item["name"]?.jsonPrimitive?.contentOrNull,
                    item["original_title"]?.jsonPrimitive?.contentOrNull,
                    item["original_name"]?.jsonPrimitive?.contentOrNull
                ).filterNotNull().toList()
                val name = aliases.firstOrNull()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                val id = item["id"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
                val providerMatch = aliases.asSequence().map(::normalizedTitle).flatMap { providerIndex[it].orEmpty().asSequence() }.firstOrNull()
                val poster = item["poster_path"]?.jsonPrimitive?.contentOrNull?.let { "https://image.tmdb.org/t/p/w500$it" }
                val backdrop = item["backdrop_path"]?.jsonPrimitive?.contentOrNull?.let { "https://image.tmdb.org/t/p/w1280$it" }
                val plot = item["overview"]?.jsonPrimitive?.contentOrNull.orEmpty()
                val year = (item["release_date"] ?: item["first_air_date"])?.jsonPrimitive?.contentOrNull.orEmpty().take(4)
                val rating = item["vote_average"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull()?.let { String.format(Locale.US, "%.1f", it) }.orEmpty()
                providerMatch?.copy(logo = poster ?: providerMatch.logo, backdrop = backdrop ?: providerMatch.backdrop, plot = plot.ifBlank { providerMatch.plot }, year = year.ifBlank { providerMatch.year }, rating = rating.ifBlank { providerMatch.rating }, externalId = "tmdb:$id")
                    ?: Channel(id = "tmdb-${request.kind?.name?.lowercase()}-$id", name = name, streamUrl = "", logo = poster, backdrop = backdrop, group = request.title, kind = request.kind ?: MediaKind.MOVIE, plot = plot, year = year, rating = rating, externalId = "tmdb:$id")
            }.distinctBy { it.id }.take(20).toList()
            matched.takeIf { it.isNotEmpty() }?.let { CuratedShelf(request.title, request.note, it) }
        }
    }

    private fun normalizedTitle(value: String): String = value.lowercase(Locale.US)
        .replace(Regex("\\[[^]]*]"), " ")
        .replace(Regex("\\((19|20)\\d{2}\\)"), " ")
        .replace(Regex("^(us|usa|4k|uhd|hd)\\s*[:|+\\-]\\s*"), "")
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()

    private data class CatalogRequest(val title: String, val note: String, val path: String, val parameters: Map<String, String> = emptyMap(), val kind: MediaKind? = null)
}
