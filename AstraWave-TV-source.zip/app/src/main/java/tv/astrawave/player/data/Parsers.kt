package tv.astrawave.player.data

import tv.astrawave.player.model.Channel

object M3uParser {
    private val attr = Regex("([\\w-]+)=\"([^\"]*)\"")

    fun parse(text: String): List<Channel> {
        val lines = text.lineSequence().map(String::trim).filter(String::isNotEmpty).toList()
        val result = mutableListOf<Channel>()
        var info: String? = null
        for (line in lines) {
            if (line.startsWith("#EXTINF", true)) info = line
            else if (!line.startsWith("#") && info != null) {
                val attrs = attr.findAll(info!!).associate { it.groupValues[1] to it.groupValues[2] }
                val name = info!!.substringAfterLast(',').trim().ifBlank { "Untitled" }
                result += Channel(
                    id = attrs["tvg-id"].orEmpty().ifBlank { line.hashCode().toString() },
                    name = name,
                    streamUrl = line,
                    logo = attrs["tvg-logo"],
                    group = attrs["group-title"].orEmpty().ifBlank { "Other" },
                    epgId = attrs["tvg-id"]
                )
                info = null
            }
        }
        return result
    }
}

object ChannelMatcher {
    private val noise = setOf("tv", "hd", "uhd", "4k", "live", "network", "channel", "the", "and", "vs")
    private val leagueAliases = mapOf(
        "nfl" to setOf("nfl", "football", "sunday ticket"),
        "nba" to setOf("nba", "basketball", "league pass"),
        "mlb" to setOf("mlb", "baseball", "extra innings"),
        "nhl" to setOf("nhl", "hockey", "center ice"),
        "ncaa" to setOf("ncaa", "college", "espn"),
        "ufc" to setOf("ufc", "mma", "fight", "ppv"),
        "premier league" to setOf("premier league", "epl", "soccer", "football")
    )

    fun rank(queryTerms: List<String>, channels: List<Channel>): List<tv.astrawave.player.model.ChannelMatch> {
        val phrases = queryTerms.map(::normalize).filter { it.length > 2 }
        val queryTokens = phrases.flatMap(::tokens).toSet()
        return channels.asSequence()
            .filter { it.kind == tv.astrawave.player.model.MediaKind.LIVE && it.streamUrl.isNotBlank() }
            .map { channel ->
            val haystack = normalize("${channel.name} ${channel.group}")
            val channelTokens = tokens(haystack)
            val sharedTokens = queryTokens.intersect(channelTokens).filter { it.length > 2 }
            val phraseHits = phrases.filter { phrase -> phrase.length > 3 && haystack.contains(phrase) }
            val aliasHits = leagueAliases.filter { (league, aliases) -> phrases.any { it.contains(league) } && aliases.any { haystack.contains(it) } }.keys
            val exact = phrases.any { normalize(channel.name) == it }
            val score = (sharedTokens.size * 12 + phraseHits.size * 30 + aliasHits.size * 28 + if (exact) 35 else 0).coerceAtMost(100)
            val reasons = buildList {
                if (phraseHits.isNotEmpty()) add("event name")
                if (sharedTokens.isNotEmpty()) add(sharedTokens.take(3).joinToString("/"))
                if (aliasHits.isNotEmpty()) add(aliasHits.joinToString("/"))
            }
            tv.astrawave.player.model.ChannelMatch(channel, score, reasons)
        }
            .filter { it.score >= 18 }
            .sortedByDescending { it.score }
            .take(8)
            .toList()
    }

    private fun normalize(value: String) = value.lowercase()
        .replace(Regex("[^a-z0-9 ]"), " ")
        .split(Regex("\\s+")).filter { it !in noise }.joinToString(" ")

    private fun tokens(value: String) = normalize(value).split(' ').filter { it.length > 1 }.toSet()
}
