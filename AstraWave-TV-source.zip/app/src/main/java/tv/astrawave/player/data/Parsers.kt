package tv.astrawave.player.data

import tv.astrawave.player.model.Channel

object M3uParser {
    private val attr = Regex("([\\w-]+)=\"([^\"]*)\"")

    fun parse(text: String): List<Channel> {
        val lines = text.lineSequence().map(String::trim).filter(String::isNotEmpty).toList()
        val result = mutableListOf<Channel>()
        var info: String? = null
        for (line in lines) {
            if (line.startsWith("#EXTINF", true)) info = line
            else if (!line.startsWith("#") && info != null) {
                val attrs = attr.findAll(info!!).associate { it.groupValues[1] to it.groupValues[2] }
                val name = info!!.substringAfterLast(',').trim().ifBlank { "Untitled" }
                result += Channel(
                    id = attrs["tvg-id"].orEmpty().ifBlank { line.hashCode().toString() },
                    name = name,
                    streamUrl = line,
                    logo = attrs["tvg-logo"],
                    group = attrs["group-title"].orEmpty().ifBlank { "Other" },
                    epgId = attrs["tvg-id"]
                )
                info = null
            }
        }
        return result
    }
}

object ChannelMatcher {
    private val noise = setOf("tv", "hd", "uhd", "4k", "live", "network", "channel")
    fun rank(queryTerms: List<String>, channels: List<Channel>) = channels.map { channel ->
        val haystack = normalize("${channel.name} ${channel.group}")
        val hits = queryTerms.map(::normalize).filter { it.length > 2 && haystack.contains(it) }
        val exact = queryTerms.any { normalize(channel.name) == normalize(it) }
        tv.astrawave.player.model.ChannelMatch(channel, hits.size * 20 + if (exact) 40 else 0, hits)
    }.filter { it.score > 0 }.sortedByDescending { it.score }.take(8)

    private fun normalize(value: String) = value.lowercase()
        .replace(Regex("[^a-z0-9 ]"), " ")
        .split(Regex("\\s+")).filter { it !in noise }.joinToString(" ")
}
