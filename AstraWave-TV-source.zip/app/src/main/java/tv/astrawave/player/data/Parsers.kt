package tv.astrawave.player.data

import tv.astrawave.player.model.Channel

object M3uParser {
    private val attr = Regex("([\\w-]+)=\"([^\"]*)\"")

    fun parse(text: String): List<Channel> {
        val lines = text.lineSequence().map(String::trim).filter(String::isNotEmpty).toList()
        val result = mutableListOf<Channel>()
        var info: String? = null
        for (line in lines) {
            if (line.startsWith("#EXTINF", true)) info = line
            else if (!line.startsWith("#") && info != null) {
                val attrs = attr.findAll(info!!).associate { it.groupValues[1] to it.groupValues[2] }
                val name = info!!.substringAfterLast(',').trim().ifBlank { "Untitled" }
                result += Channel(
                    id = attrs["tvg-id"].orEmpty().ifBlank { line.hashCode().toString() },
                    name = name,
                    streamUrl = line,
                    logo = attrs["tvg-logo"],
                    group = attrs["group-title"].orEmpty().ifBlank { "Other" },
                    epgId = attrs["tvg-id"]
                )
                info = null
            }
        }
        return result
    }
}

object ChannelMatcher {
    private val noise = setOf("tv", "hd", "fhd", "uhd", "4k", "live", "network", "channel", "the", "and", "vs", "us", "usa")
    private val leagueAliases = mapOf(
        "nfl" to setOf("nfl", "football", "sunday ticket"),
        "nba" to setOf("nba", "basketball", "league pass"),
        "mlb" to setOf("mlb", "baseball", "extra innings"),
        "nhl" to setOf("nhl", "hockey", "center ice"),
        "ncaa" to setOf("ncaa", "college", "espn"),
        "ufc" to setOf("ufc", "mma", "fight", "ppv"),
        "premier league" to setOf("premier league", "epl", "soccer", "football"),
        "mls" to setOf("mls", "soccer", "apple tv", "fox sports"),
        "wnba" to setOf("wnba", "basketball", "espn", "ion")
    )
    private val broadcasterAliases = mapOf(
        "espn" to setOf("espn", "espn1"), "espn2" to setOf("espn2", "espn 2"),
        "espnu" to setOf("espnu", "espn u"), "abc" to setOf("abc", "koat"),
        "nbc" to setOf("nbc", "kob 4", "kob4"), "cbs" to setOf("cbs", "krqe"), "fox" to setOf("fox", "fox new mexico", "kasa"),
        "fs1" to setOf("fs1", "fox sports 1"), "fs2" to setOf("fs2", "fox sports 2"),
        "tnt" to setOf("tnt"), "tbs" to setOf("tbs"), "tru tv" to setOf("trutv", "tru tv"),
        "nfl network" to setOf("nfl network", "nfln"), "nba tv" to setOf("nba tv", "nbatv"),
        "mlb network" to setOf("mlb network", "mlbn"), "nhl network" to setOf("nhl network", "nhln"),
        "cbs sports" to setOf("cbs sports", "cbssn"), "nbc sports" to setOf("nbc sports", "nbcsn"),
        "peacock" to setOf("peacock"), "prime video" to setOf("prime video", "amazon prime"),
        "apple tv" to setOf("apple tv", "mls season pass"), "ion" to setOf("ion"),
        "fanduel sports" to setOf("fanduel sports", "bally sports"), "bally sports" to setOf("bally sports", "fanduel sports"),
        "yes network" to setOf("yes network", "yes"), "nesn" to setOf("nesn"), "sny" to setOf("sny"),
        "msg" to setOf("msg", "msg sportsnet"), "altitude" to setOf("altitude sports")
    )

    fun rank(queryTerms: List<String>, channels: List<Channel>, guideTextByChannel: Map<String, String> = emptyMap()): List<tv.astrawave.player.model.ChannelMatch> {
        val phrases = queryTerms.map(::normalize).filter { it.length > 2 }
        val queryTokens = phrases.flatMap(::tokens).toSet()
        return channels.asSequence()
            .filter { it.kind == tv.astrawave.player.model.MediaKind.LIVE && it.streamUrl.isNotBlank() }
            .map { channel ->
            val guideText = listOfNotNull(guideTextByChannel[channel.id], channel.epgId?.let(guideTextByChannel::get)).joinToString(" ")
            val haystack = normalize("${channel.name} ${channel.group} $guideText")
            val channelTokens = tokens(haystack)
            val sharedTokens = queryTokens.intersect(channelTokens).filter { it.length > 2 }
            val phraseHits = phrases.filter { phrase -> phrase.length > 3 && haystack.contains(phrase) }
            val aliasHits = leagueAliases.filter { (league, aliases) -> phrases.any { it.contains(league) } && aliases.any { haystack.contains(it) } }.keys
            val broadcasterHits = broadcasterAliases.filter { (network, aliases) ->
                phrases.any { phrase -> phrase.contains(network) || aliases.any(phrase::contains) } && aliases.any(haystack::contains)
            }.keys
            val guideHit = guideText.isNotBlank() && phrases.any { phrase -> phrase.length > 4 && normalize(guideText).contains(phrase) }
            val exact = phrases.any { normalize(channel.name) == it }
            val sportsCategory = listOf("sport", "nfl", "nba", "mlb", "nhl", "football", "basketball", "baseball", "hockey", "soccer", "ppv").any(haystack::contains)
            val score = (sharedTokens.size * 10 + phraseHits.size * 25 + aliasHits.size * 20 + broadcasterHits.size * 58 + if (guideHit) 55 else 0 + if (exact) 35 else 0 + if (sportsCategory) 4 else 0).coerceAtMost(100)
            val reasons = buildList {
                if (broadcasterHits.isNotEmpty()) add("broadcast: ${broadcasterHits.joinToString("/")}")
                if (guideHit) add("provider guide")
                if (phraseHits.isNotEmpty()) add("event name")
                if (sharedTokens.isNotEmpty()) add(sharedTokens.take(3).joinToString("/"))
                if (aliasHits.isNotEmpty()) add(aliasHits.joinToString("/"))
            }
            tv.astrawave.player.model.ChannelMatch(channel, score, reasons)
        }
            .filter { it.score >= 16 }
            .sortedByDescending { it.score }
            .distinctBy { normalize(it.channel.name) }
            .take(12)
            .toList()
    }

    private fun normalize(value: String) = value.lowercase()
        .replace(Regex("[^a-z0-9 ]"), " ")
        .split(Regex("\\s+")).filter { it !in noise }.joinToString(" ")

    private fun tokens(value: String) = normalize(value).split(' ').filter { it.length > 1 }.toSet()
}
