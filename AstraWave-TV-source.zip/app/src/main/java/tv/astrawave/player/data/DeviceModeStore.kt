package tv.astrawave.player.data

import android.content.Context
import android.content.res.Configuration

enum class DeviceMode { TV, PHONE, TABLET }

class DeviceModeStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("astrawave_device", Context.MODE_PRIVATE)
    fun selected(): DeviceMode? = prefs.getString("mode", null)?.let { runCatching { DeviceMode.valueOf(it) }.getOrNull() }
    fun save(mode: DeviceMode) = prefs.edit().putString("mode", mode.name).apply()
    fun recommended(): DeviceMode {
        val uiMode = context.resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK
        if (uiMode == Configuration.UI_MODE_TYPE_TELEVISION) return DeviceMode.TV
        return if (context.resources.configuration.smallestScreenWidthDp >= 600) DeviceMode.TABLET else DeviceMode.PHONE
    }
}
