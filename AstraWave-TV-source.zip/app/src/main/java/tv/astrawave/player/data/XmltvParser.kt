package tv.astrawave.player.data

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import tv.astrawave.player.model.Program
import java.io.Reader
import java.text.SimpleDateFormat
import java.util.Locale

object XmltvParser {
    fun parse(reader: Reader): List<Program> {
        val parser = Xml.newPullParser().apply { setInput(reader) }
        val result = mutableListOf<Program>()
        val now = System.currentTimeMillis()
        val earliest = now - 3L * 86_400_000L
        val latest = now + 10L * 86_400_000L
        var channel = ""; var start = 0L; var stop = 0L; var title = ""; var description = ""; var tag = ""
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            when (parser.eventType) {
                XmlPullParser.START_TAG -> {
                    tag = parser.name
                    if (tag == "programme") {
                        channel = parser.getAttributeValue(null, "channel").orEmpty()
                        start = time(parser.getAttributeValue(null, "start"))
                        stop = time(parser.getAttributeValue(null, "stop"))
                        title = ""; description = ""
                    }
                }
                XmlPullParser.TEXT -> when (tag) { "title" -> title += parser.text; "desc" -> description += parser.text }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "programme" && channel.isNotBlank() && title.isNotBlank() && stop > start && stop >= earliest && start <= latest && result.size < 150_000) result += Program(channel, title.trim(), start, stop, description.trim())
                    tag = ""
                }
            }
            parser.next()
        }
        return result.sortedBy { it.startMillis }
    }

    private fun time(value: String?): Long {
        val raw = value.orEmpty().trim()
        val patterns = listOf("yyyyMMddHHmmss Z", "yyyyMMddHHmmssZ", "yyyyMMddHHmmss")
        return patterns.firstNotNullOfOrNull { pattern -> runCatching { SimpleDateFormat(pattern, Locale.US).parse(raw)?.time }.getOrNull() } ?: 0L
    }
}
