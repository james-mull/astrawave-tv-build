package tv.astrawave.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import tv.astrawave.player.model.SportsEvent
import java.text.SimpleDateFormat
import java.util.Locale

class SportsDataClient(private val apiKey: String, private val http: OkHttpClient = OkHttpClient(), private val json: Json = Json { ignoreUnknownKeys = true }) {
    suspend fun events(date: String): List<SportsEvent> = withContext(Dispatchers.IO) {
        val request = Request.Builder().url("https://www.thesportsdb.com/api/v1/json/$apiKey/eventsday.php?d=$date").header("User-Agent", "AstraWaveTV/0.1").build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Sports provider returned HTTP ${response.code}")
            val root = json.parseToJsonElement(response.body?.string().orEmpty()).jsonObject
            root["events"]?.jsonArray.orEmpty().mapNotNull { node ->
                val o = node.jsonObject; val id = o["idEvent"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
                val home = o["strHomeTeam"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null; val away = o["strAwayTeam"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
                val league = o["strLeague"]?.jsonPrimitive?.contentOrNull.orEmpty(); val status = o["strStatus"]?.jsonPrimitive?.contentOrNull ?: o["strProgress"]?.jsonPrimitive?.contentOrNull ?: o["strTime"]?.jsonPrimitive?.contentOrNull ?: "Scheduled"
                SportsEvent(id, league, home, away, parseTime(o["dateEvent"]?.jsonPrimitive?.contentOrNull, o["strTime"]?.jsonPrimitive?.contentOrNull), status, o["intHomeScore"]?.jsonPrimitive?.contentOrNull.orEmpty(), o["intAwayScore"]?.jsonPrimitive?.contentOrNull.orEmpty())
            }
        }
    }
    private fun parseTime(date: String?, time: String?): Long = runCatching { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).parse("${date.orEmpty()} ${time.orEmpty().ifBlank { "00:00:00" }}")?.time ?: 0L }.getOrDefault(0L)
}
