package tv.astrawave.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.JsonArray
import okhttp3.OkHttpClient
import okhttp3.Request
import tv.astrawave.player.model.SportsEvent
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class SportsDataClient(private val apiKey: String, private val http: OkHttpClient = OkHttpClient.Builder().callTimeout(10, TimeUnit.SECONDS).build(), private val json: Json = Json { ignoreUnknownKeys = true }) {
    suspend fun events(date: String): List<SportsEvent> = withContext(Dispatchers.IO) {
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val base = formatter.parse(date) ?: return@withContext emptyList()
        val calendar = Calendar.getInstance().apply { time = base }
        val dates = (0..1).map { offset ->
            calendar.time = base
            calendar.add(Calendar.DAY_OF_YEAR, offset)
            formatter.format(calendar.time)
        }
        val sports = listOf("American Football", "Baseball", "Basketball", "Ice Hockey", "Soccer", "Fighting")
        dates.flatMap { day -> sports.flatMap { sport -> runCatching { eventsForDate(day, sport) }.getOrDefault(emptyList()) } }
            .distinctBy { it.id }.sortedBy { it.startMillis }
    }

    private fun eventsForDate(date: String, sport: String): List<SportsEvent> {
        val encodedSport = URLEncoder.encode(sport, "UTF-8")
        val request = Request.Builder().url("https://www.thesportsdb.com/api/v1/json/$apiKey/eventsday.php?d=$date&s=$encodedSport").header("User-Agent", "AstraWaveTV/0.1").build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Sports provider returned HTTP ${response.code}")
            val root = json.parseToJsonElement(response.body?.string().orEmpty()).jsonObject
            val events = root["events"] as? JsonArray ?: return emptyList()
            return events.mapNotNull { node ->
                val o = node.jsonObject; val id = o["idEvent"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
                val eventTitle = o["strEvent"]?.jsonPrimitive?.contentOrNull.orEmpty()
                val home = o["strHomeTeam"]?.jsonPrimitive?.contentOrNull.orEmpty()
                val away = o["strAwayTeam"]?.jsonPrimitive?.contentOrNull.orEmpty()
                if (home.isBlank() && away.isBlank() && eventTitle.isBlank()) return@mapNotNull null
                val league = o["strLeague"]?.jsonPrimitive?.contentOrNull.orEmpty(); val status = o["strStatus"]?.jsonPrimitive?.contentOrNull ?: o["strProgress"]?.jsonPrimitive?.contentOrNull ?: o["strTime"]?.jsonPrimitive?.contentOrNull ?: "Scheduled"
                val broadcasters = listOf("strTVStation", "strBroadcast", "strChannel").flatMap { field ->
                    o[field]?.jsonPrimitive?.contentOrNull.orEmpty().split(',', '/', ';', '|')
                }.map(String::trim).filter(String::isNotBlank).distinct()
                SportsEvent(id, league, home, away, parseTime(o["strTimestamp"]?.jsonPrimitive?.contentOrNull, o["dateEvent"]?.jsonPrimitive?.contentOrNull, o["strTime"]?.jsonPrimitive?.contentOrNull), status, o["intHomeScore"]?.jsonPrimitive?.contentOrNull.orEmpty(), o["intAwayScore"]?.jsonPrimitive?.contentOrNull.orEmpty(), eventTitle, broadcasters)
            }
        }
    }

    private fun parseTime(timestamp: String?, date: String?, time: String?): Long {
        val utc = TimeZone.getTimeZone("UTC")
        val timestampResult = timestamp?.let { value ->
            listOf("yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss'Z'").firstNotNullOfOrNull { pattern ->
                runCatching { SimpleDateFormat(pattern, Locale.US).apply { timeZone = utc }.parse(value)?.time }.getOrNull()
            }
        }
        return timestampResult ?: runCatching { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply { timeZone = utc }.parse("${date.orEmpty()} ${time.orEmpty().ifBlank { "00:00:00" }}")?.time ?: 0L }.getOrDefault(0L)
    }
}
