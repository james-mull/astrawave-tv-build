package tv.astrawave.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.JsonArray
import okhttp3.OkHttpClient
import okhttp3.Request
import tv.astrawave.player.model.SportsEvent
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class SportsDataClient(private val apiKey: String, private val http: OkHttpClient = OkHttpClient.Builder().callTimeout(10, TimeUnit.SECONDS).build(), private val json: Json = Json { ignoreUnknownKeys = true }) {
    suspend fun events(date: String): List<SportsEvent> = coroutineScope {
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val base = formatter.parse(date) ?: return@coroutineScope emptyList()
        val calendar = Calendar.getInstance().apply { time = base }
        val dates = (0..2).map { offset ->
            calendar.time = base
            calendar.add(Calendar.DAY_OF_YEAR, offset)
            formatter.format(calendar.time)
        }
        // One request per day is substantially faster and more reliable than
        // making a separate request for every sport.
        dates.map { day -> async(Dispatchers.IO) { runCatching { eventsForDate(day) }.getOrDefault(emptyList()) } }.awaitAll().flatten()
            .distinctBy { it.id }.sortedBy { it.startMillis }
    }

    private fun eventsForDate(date: String): List<SportsEvent> {
        val request = Request.Builder().url("https://www.thesportsdb.com/api/v1/json/$apiKey/eventsday.php?d=$date").header("User-Agent", "AstraWaveTV/0.6").build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Sports provider returned HTTP ${response.code}")
            val root = json.parseToJsonElement(response.body?.string().orEmpty()).jsonObject
            val events = root["events"] as? JsonArray ?: return emptyList()
            return events.mapNotNull { node ->
                val o = node.jsonObject; val id = o["idEvent"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
                val eventTitle = o["strEvent"]?.jsonPrimitive?.contentOrNull.orEmpty()
                val home = o["strHomeTeam"]?.jsonPrimitive?.contentOrNull.orEmpty()
                val away = o["strAwayTeam"]?.jsonPrimitive?.contentOrNull.orEmpty()
                if (home.isBlank() && away.isBlank() && eventTitle.isBlank()) return@mapNotNull null
                val league = o["strLeague"]?.jsonPrimitive?.contentOrNull.orEmpty()
                val sport = o["strSport"]?.jsonPrimitive?.contentOrNull.orEmpty()
                val relevant = "$league $sport $eventTitle".lowercase(Locale.US).let { text ->
                    listOf("nfl", "nba", "mlb", "nhl", "wnba", "ncaa", "major league soccer", "mls", "premier league", "uefa", "ufc", "mma", "boxing", "formula 1", "nascar", "indycar", "american football", "baseball", "basketball", "ice hockey").any(text::contains)
                }
                if (!relevant) return@mapNotNull null
                val status = o["strStatus"]?.jsonPrimitive?.contentOrNull ?: o["strProgress"]?.jsonPrimitive?.contentOrNull ?: o["strTime"]?.jsonPrimitive?.contentOrNull ?: "Scheduled"
                val broadcasters = listOf("strTVStation", "strBroadcast", "strChannel").flatMap { field ->
                    o[field]?.jsonPrimitive?.contentOrNull.orEmpty().split(',', '/', ';', '|')
                }.map(String::trim).filter(String::isNotBlank).distinct()
                SportsEvent(id, league, home, away, parseTime(o["strTimestamp"]?.jsonPrimitive?.contentOrNull, o["dateEvent"]?.jsonPrimitive?.contentOrNull, o["strTime"]?.jsonPrimitive?.contentOrNull), status, o["intHomeScore"]?.jsonPrimitive?.contentOrNull.orEmpty(), o["intAwayScore"]?.jsonPrimitive?.contentOrNull.orEmpty(), eventTitle, broadcasters)
            }
        }
    }

    private fun parseTime(timestamp: String?, date: String?, time: String?): Long {
        val utc = TimeZone.getTimeZone("UTC")
        val timestampResult = timestamp?.let { value ->
            listOf("yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss'Z'").firstNotNullOfOrNull { pattern ->
                runCatching { SimpleDateFormat(pattern, Locale.US).apply { timeZone = utc }.parse(value)?.time }.getOrNull()
            }
        }
        return timestampResult ?: runCatching { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply { timeZone = utc }.parse("${date.orEmpty()} ${time.orEmpty().ifBlank { "00:00:00" }}")?.time ?: 0L }.getOrDefault(0L)
    }
}
