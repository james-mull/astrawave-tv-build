package tv.astrawave.player.data

import android.content.Context
import tv.astrawave.player.model.Channel
import tv.astrawave.player.model.MediaKind
import java.util.Locale

class ContentPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("astrawave_content", Context.MODE_PRIVATE)
    var includeWorld: Boolean
        get() = prefs.getBoolean("include_world", false)
        set(value) { prefs.edit().putBoolean("include_world", value).apply() }
}

data class CuratedShelf(val title: String, val note: String, val items: List<Channel>)

object ContentDiscovery {
    private val internationalMarkers = setOf(
        "arabic", "bollywood", "india", "indian", "pakistan", "punjabi", "hindi", "turkish",
        "korean", "k drama", "japanese", "anime", "latino", "latin america", "spanish", "espanol",
        "portuguese", "brazil", "brazilian", "french", "german", "italian", "polish", "russian",
        "uk only", "united kingdom", "africa", "african", "philippines", "filipino", "albanian",
        "greek", "romanian", "serbian", "croatian", "netherlands", "dutch", "swedish", "norwegian"
    )

    private val mindBendingMovies = setOf(
        "Inception", "The Matrix", "Memento", "Shutter Island", "Donnie Darko", "Fight Club",
        "Arrival", "Ex Machina", "Coherence", "Predestination", "Enemy", "Primer", "Mulholland Drive",
        "The Prestige", "Black Swan", "Eternal Sunshine of the Spotless Mind", "The Truman Show",
        "Source Code", "Annihilation", "Everything Everywhere All at Once", "Tenet", "Moon", "Looper"
    )
    private val essentialMovies = setOf(
        "The Godfather", "The Godfather Part II", "Casablanca", "Citizen Kane", "Pulp Fiction",
        "The Shawshank Redemption", "Goodfellas", "Jaws", "Alien", "Aliens", "The Dark Knight",
        "Get Out", "Moonlight", "No Country for Old Men", "There Will Be Blood", "The Social Network",
        "Mad Max Fury Road", "Whiplash", "The Silence of the Lambs", "Back to the Future", "Rocky"
    )
    private val prestigeSeries = setOf(
        "Breaking Bad", "Better Call Saul", "The Sopranos", "The Wire", "Mad Men", "Succession",
        "The Bear", "Severance", "Chernobyl", "Fargo", "True Detective", "The Last of Us", "Andor",
        "The Americans", "Only Murders in the Building", "The Leftovers", "Mr Robot"
    )
    private val mindBendingSeries = setOf(
        "Dark", "Black Mirror", "Severance", "Westworld", "Mr Robot", "The Leftovers", "Twin Peaks",
        "Lost", "Legion", "Devs", "1899", "Silo", "Fringe", "The OA", "Maniac"
    )

    fun usaFirst(content: List<Channel>, includeWorld: Boolean): List<Channel> {
        if (includeWorld) return content
        val filtered = content.filterNot(::isExplicitlyInternational)
        return filtered.ifEmpty { content }
    }

    fun shelves(content: List<Channel>, kind: MediaKind): List<CuratedShelf> {
        val critics = content.filter { it.rating.toDoubleOrNull()?.let { score -> score >= 8.0 } == true }
            .sortedByDescending { it.rating.toDoubleOrNull() ?: 0.0 }.take(20)
        return buildList {
            if (kind == MediaKind.MOVIE) {
                addShelf("Mind-Bending Movies", "Psychological and reality-bending favorites", content, mindBendingMovies)
                addShelf("Rotten Tomatoes Essentials", "Matches from the editorial Essential Movies guide", content, essentialMovies)
            } else if (kind == MediaKind.SERIES) {
                addShelf("Prestige TV", "Acclaimed series worth starting", content, prestigeSeries)
                addShelf("Mind-Bending Series", "Mystery, science fiction and altered reality", content, mindBendingSeries)
            }
            if (critics.size >= 3) add(CuratedShelf("Highly Rated", "Provider titles rated 8.0 or higher", critics))
            val trueStories = content.filter { item ->
                val text = "${item.name} ${item.group} ${item.plot}".lowercase(Locale.US)
                listOf("true story", "based on true", "biography", "documentary", "docuseries").any(text::contains)
            }.take(20)
            if (trueStories.size >= 3) add(CuratedShelf("Based on Real Events", "Documentaries, biographies and true stories", trueStories))
        }
    }

    private fun MutableList<CuratedShelf>.addShelf(title: String, note: String, content: List<Channel>, titles: Set<String>) {
        val normalizedTitles = titles.map(::normalizeTitle).toSet()
        val matches = content.filter { normalizeTitle(it.name) in normalizedTitles }.take(20)
        if (matches.isNotEmpty()) add(CuratedShelf(title, note, matches))
    }

    private fun isExplicitlyInternational(item: Channel): Boolean {
        val category = item.group.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), " ")
        return internationalMarkers.any { marker -> category.contains(marker) }
    }

    private fun normalizeTitle(value: String): String = value.lowercase(Locale.US)
        .replace(Regex("\\[[^]]*]"), " ")
        .replace(Regex("\\((19|20)\\d{2}\\)"), " ")
        .replace(Regex("^(us|usa|4k|uhd|hd)\\s*[:|+-]\\s*"), "")
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()
}
