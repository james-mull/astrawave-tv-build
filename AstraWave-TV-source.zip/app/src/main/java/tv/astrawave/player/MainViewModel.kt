package tv.astrawave.player

import android.app.Application

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import tv.astrawave.player.data.ChannelMatcher
import tv.astrawave.player.data.CuratedShelf
import tv.astrawave.player.data.FavoritesStore
import tv.astrawave.player.data.IptvRepository
import tv.astrawave.player.data.PlaybackStore
import tv.astrawave.player.data.SportsDataClient
import tv.astrawave.player.data.TmdbCatalogClient
import tv.astrawave.player.data.SecureStore
import tv.astrawave.player.model.Channel
import tv.astrawave.player.model.ChannelMatch
import tv.astrawave.player.model.Episode
import tv.astrawave.player.model.Profile
import tv.astrawave.player.model.Program
import tv.astrawave.player.model.SportsEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppState(
    val profile: Profile? = null,
    val channels: List<Channel> = emptyList(),
    val programs: List<Program> = emptyList(),
    val episodesBySeries: Map<String, List<Episode>> = emptyMap(),
    val seriesLoadingId: String? = null,
    val sportsEvents: List<SportsEvent> = emptyList(),
    val sportsLoading: Boolean = false,
    val sportsUpdatedAt: Long = 0L,
    val movieCatalogs: List<CuratedShelf> = emptyList(),
    val seriesCatalogs: List<CuratedShelf> = emptyList(),
    val catalogsLoading: Boolean = false,
    val catalogMessage: String? = null,
    val favorites: Set<String> = emptySet(),
    val restoringSession: Boolean = false,
    val loading: Boolean = false,
    val guideLoading: Boolean = false,
    val error: String? = null,
    val playing: Channel? = null
)

class MainViewModel private constructor(application: Application, private val repository: IptvRepository, private val sportsClient: SportsDataClient, private val bundledTmdbCredential: String) : AndroidViewModel(application) {
    constructor(application: Application) : this(application, IptvRepository(), SportsDataClient(BuildConfig.SPORTSDB_API_KEY), BuildConfig.TMDB_API_KEY)
    private val favoritesStore = FavoritesStore(application)
    private val playbackStore = PlaybackStore(application)
    private val secureStore by lazy { SecureStore(application) }
    private val _state = MutableStateFlow(AppState(restoringSession = true))
    val state = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val savedProfile = runCatching { secureStore.activeProfile() }.getOrNull()
            if (savedProfile == null) {
                _state.value = AppState()
            } else {
                connectProfile(savedProfile, restoring = true)
            }
        }
    }

    fun connect(profile: Profile) = connectProfile(profile, restoring = false)

    private fun connectProfile(profile: Profile, restoring: Boolean) = viewModelScope.launch {
        _state.value = _state.value.copy(restoringSession = restoring, loading = true, error = null)
        runCatching { repository.load(profile) }
            .onSuccess { channels ->
                // A provider connection must remain usable even if an old
                // debug install left unreadable encrypted preferences.
                runCatching { secureStore.saveProfile(profile) }
                _state.value = AppState(profile = profile, channels = channels, favorites = favoritesStore.favorites(profile.id))
                refreshCatalogs(channels)
            }
            .onFailure {
                _state.value = AppState(
                    error = if (restoring) {
                        "Saved provider could not reconnect: ${it.message ?: "provider unavailable"}"
                    } else {
                        it.message ?: "Could not load playlist"
                    }
                )
            }
    }

    fun refreshCatalogs(content: List<Channel> = _state.value.channels) {
        if (content.isEmpty() || _state.value.catalogsLoading) return
        val credential = secureStore.tmdbCredential().orEmpty().ifBlank { bundledTmdbCredential }
        if (credential.isBlank()) {
            _state.value = _state.value.copy(catalogMessage = "Add a TMDB API key in Settings to enable current online catalogs")
            return
        }
        val tmdbClient = TmdbCatalogClient(credential)
        viewModelScope.launch {
            _state.value = _state.value.copy(catalogsLoading = true, catalogMessage = null)
            runCatching { tmdbClient.catalogs(content) }
                .onSuccess { catalogs -> _state.value = _state.value.copy(movieCatalogs = catalogs.movies, seriesCatalogs = catalogs.series, catalogsLoading = false, catalogMessage = if (catalogs.movies.isEmpty() && catalogs.series.isEmpty()) "TMDB loaded, but no catalog titles matched this provider library" else null) }
                .onFailure { _state.value = _state.value.copy(catalogsLoading = false, catalogMessage = "TMDB catalogs unavailable: ${it.message ?: "network error"}") }
        }
    }

    fun catalogCredentialChanged() {
        _state.value = _state.value.copy(movieCatalogs = emptyList(), seriesCatalogs = emptyList(), catalogMessage = null)
        refreshCatalogs()
    }

    fun loadGuide() {
        val profile = _state.value.profile ?: return
        if (_state.value.guideLoading || _state.value.programs.isNotEmpty()) return
        viewModelScope.launch {
            _state.value = _state.value.copy(guideLoading = true)
            runCatching { repository.loadPrograms(profile) }
                .onSuccess { programs -> _state.value = _state.value.copy(programs = programs, guideLoading = false) }
                .onFailure { _state.value = _state.value.copy(guideLoading = false, error = "Guide unavailable: ${it.message ?: "provider error"}") }
        }
    }

    fun play(channel: Channel?) {
        if (channel?.kind == tv.astrawave.player.model.MediaKind.LIVE) playbackStore.saveRecentLive(channel.id)
        _state.value = _state.value.copy(playing = channel)
    }
    fun disconnect() { _state.value = AppState() }
    fun clearError() { _state.value = _state.value.copy(error = null) }
    fun playCatchup(channel: Channel, program: Program) {
        val profile = _state.value.profile ?: return
        runCatching { repository.catchup(profile, channel, program) }
            .onSuccess { play(it) }
            .onFailure { _state.value = _state.value.copy(error = it.message ?: "Could not start catch-up") }
    }
    fun toggleFavorite(id: String) {
        val next = _state.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        _state.value = _state.value.copy(favorites = next)
        _state.value.profile?.let { favoritesStore.save(it.id, next) }
    }

    fun programsFor(channel: Channel): List<Program> = _state.value.programs.filter { it.channelId == channel.epgId || it.channelId == channel.id }

    fun loadSeriesEpisodes(series: Channel) {
        val providerId = series.providerId ?: return
        val profile = _state.value.profile ?: return
        if (_state.value.episodesBySeries.containsKey(series.id) || _state.value.seriesLoadingId == series.id) return
        viewModelScope.launch {
            _state.value = _state.value.copy(seriesLoadingId = series.id, error = null)
            runCatching { repository.loadEpisodes(profile, providerId) }
                .onSuccess { episodes -> _state.value = _state.value.copy(episodesBySeries = _state.value.episodesBySeries + (series.id to episodes), seriesLoadingId = null) }
                .onFailure { _state.value = _state.value.copy(seriesLoadingId = null, error = it.message ?: "Could not load episodes") }
        }
    }

    fun refreshSports(force: Boolean = false) {
        if (_state.value.sportsLoading || (!force && System.currentTimeMillis() - _state.value.sportsUpdatedAt < 120_000)) return
        viewModelScope.launch {
            _state.value = _state.value.copy(sportsLoading = true)
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            runCatching { sportsClient.events(date) }
                .onSuccess { events -> _state.value = _state.value.copy(sportsEvents = events, sportsLoading = false, sportsUpdatedAt = System.currentTimeMillis()) }
                .onFailure { _state.value = _state.value.copy(sportsLoading = false, error = it.message ?: "Could not refresh sports") }
        }
    }

    fun matches(event: SportsEvent, channels: List<Channel> = _state.value.channels): List<ChannelMatch> = ChannelMatcher.rank(
        listOf(event.home, event.away, event.league, event.title, "${event.home} ${event.away}"), channels
    )
}
