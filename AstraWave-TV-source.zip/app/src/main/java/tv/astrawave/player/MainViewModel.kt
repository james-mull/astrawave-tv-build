package tv.astrawave.player

import android.app.Application

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import tv.astrawave.player.data.ChannelMatcher
import tv.astrawave.player.data.FavoritesStore
import tv.astrawave.player.data.IptvRepository
import tv.astrawave.player.data.SportsDataClient
import tv.astrawave.player.model.Channel
import tv.astrawave.player.model.ChannelMatch
import tv.astrawave.player.model.Episode
import tv.astrawave.player.model.Profile
import tv.astrawave.player.model.Program
import tv.astrawave.player.model.SportsEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppState(
    val profile: Profile? = null,
    val channels: List<Channel> = emptyList(),
    val programs: List<Program> = emptyList(),
    val episodesBySeries: Map<String, List<Episode>> = emptyMap(),
    val seriesLoadingId: String? = null,
    val sportsEvents: List<SportsEvent> = emptyList(),
    val sportsLoading: Boolean = false,
    val sportsUpdatedAt: Long = 0L,
    val favorites: Set<String> = emptySet(),
    val loading: Boolean = false,
    val error: String? = null,
    val playing: Channel? = null
)

class MainViewModel private constructor(application: Application, private val repository: IptvRepository, private val sportsClient: SportsDataClient) : AndroidViewModel(application) {
    constructor(application: Application) : this(application, IptvRepository(), SportsDataClient(BuildConfig.SPORTSDB_API_KEY))
    private val favoritesStore = FavoritesStore(application)
    private val _state = MutableStateFlow(AppState())
    val state = _state.asStateFlow()

    fun connect(profile: Profile) = viewModelScope.launch {
        _state.value = _state.value.copy(loading = true, error = null)
        runCatching {
            val channels = repository.load(profile)
            val programs = runCatching { repository.loadPrograms(profile) }.getOrDefault(emptyList())
            channels to programs
        }
            .onSuccess { (channels, programs) -> _state.value = AppState(profile = profile, channels = channels, programs = programs, favorites = favoritesStore.favorites(profile.id)) }
            .onFailure { _state.value = _state.value.copy(loading = false, error = it.message ?: "Could not load playlist") }
    }

    fun play(channel: Channel?) { _state.value = _state.value.copy(playing = channel) }
    fun playCatchup(channel: Channel, program: Program) {
        val profile = _state.value.profile ?: return
        runCatching { repository.catchup(profile, channel, program) }
            .onSuccess { play(it) }
            .onFailure { _state.value = _state.value.copy(error = it.message ?: "Could not start catch-up") }
    }
    fun toggleFavorite(id: String) {
        val next = _state.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        _state.value = _state.value.copy(favorites = next)
        _state.value.profile?.let { favoritesStore.save(it.id, next) }
    }

    fun programsFor(channel: Channel): List<Program> = _state.value.programs.filter { it.channelId == channel.epgId || it.channelId == channel.id }

    fun loadSeriesEpisodes(series: Channel) {
        val providerId = series.providerId ?: return
        val profile = _state.value.profile ?: return
        if (_state.value.episodesBySeries.containsKey(series.id) || _state.value.seriesLoadingId == series.id) return
        viewModelScope.launch {
            _state.value = _state.value.copy(seriesLoadingId = series.id, error = null)
            runCatching { repository.loadEpisodes(profile, providerId) }
                .onSuccess { episodes -> _state.value = _state.value.copy(episodesBySeries = _state.value.episodesBySeries + (series.id to episodes), seriesLoadingId = null) }
                .onFailure { _state.value = _state.value.copy(seriesLoadingId = null, error = it.message ?: "Could not load episodes") }
        }
    }

    fun refreshSports(force: Boolean = false) {
        if (_state.value.sportsLoading || (!force && System.currentTimeMillis() - _state.value.sportsUpdatedAt < 120_000)) return
        viewModelScope.launch {
            _state.value = _state.value.copy(sportsLoading = true)
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            runCatching { sportsClient.events(date) }
                .onSuccess { events -> _state.value = _state.value.copy(sportsEvents = events, sportsLoading = false, sportsUpdatedAt = System.currentTimeMillis()) }
                .onFailure { _state.value = _state.value.copy(sportsLoading = false, error = it.message ?: "Could not refresh sports") }
        }
    }

    fun matches(event: SportsEvent, channels: List<Channel> = _state.value.channels): List<ChannelMatch> = ChannelMatcher.rank(
        listOf(event.home, event.away, event.league, "${event.home} ${event.away}"), channels
    )
}
