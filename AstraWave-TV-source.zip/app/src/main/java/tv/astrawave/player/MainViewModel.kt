package tv.astrawave.player

import android.app.Application

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import tv.astrawave.player.data.ChannelMatcher
import tv.astrawave.player.data.CuratedShelf
import tv.astrawave.player.data.FavoritesStore
import tv.astrawave.player.data.FreeCatalogClient
import tv.astrawave.player.data.IptvRepository
import tv.astrawave.player.data.PlaybackStore
import tv.astrawave.player.data.SportsDataClient
import tv.astrawave.player.data.TmdbCatalogClient
import tv.astrawave.player.data.SecureStore
import tv.astrawave.player.model.Channel
import tv.astrawave.player.model.ChannelMatch
import tv.astrawave.player.model.Episode
import tv.astrawave.player.model.MediaKind
import tv.astrawave.player.model.Profile
import tv.astrawave.player.model.Program
import tv.astrawave.player.model.SportsEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppState(
    val profile: Profile? = null,
    val channels: List<Channel> = emptyList(),
    val programs: List<Program> = emptyList(),
    val episodesBySeries: Map<String, List<Episode>> = emptyMap(),
    val seriesLoadingId: String? = null,
    val sportsEvents: List<SportsEvent> = emptyList(),
    val sportsLoading: Boolean = false,
    val sportsUpdatedAt: Long = 0L,
    val movieCatalogs: List<CuratedShelf> = emptyList(),
    val seriesCatalogs: List<CuratedShelf> = emptyList(),
    val catalogsLoading: Boolean = false,
    val catalogMessage: String? = null,
    val catalogSearchResults: Map<MediaKind, List<Channel>> = emptyMap(),
    val catalogSearchQuery: Map<MediaKind, String> = emptyMap(),
    val catalogSearchLoading: Set<MediaKind> = emptySet(),
    val favorites: Set<String> = emptySet(),
    val restoringSession: Boolean = false,
    val loading: Boolean = false,
    val guideLoading: Boolean = false,
    val error: String? = null,
    val playing: Channel? = null
)

class MainViewModel private constructor(application: Application, private val repository: IptvRepository, private val sportsClient: SportsDataClient, private val bundledTmdbCredential: String) : AndroidViewModel(application) {
    constructor(application: Application) : this(application, IptvRepository(), SportsDataClient(BuildConfig.SPORTSDB_API_KEY), BuildConfig.TMDB_API_KEY)
    private val favoritesStore = FavoritesStore(application)
    private val playbackStore = PlaybackStore(application)
    private val freeCatalogClient = FreeCatalogClient()
    private val secureStore by lazy { SecureStore(application) }
    private val _state = MutableStateFlow(AppState(restoringSession = true))
    private var guideSearchIndex: Map<String, String> = emptyMap()
    private val catalogSearchJobs = mutableMapOf<MediaKind, kotlinx.coroutines.Job>()
    val state = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val savedProfile = runCatching { secureStore.activeProfile() }.getOrNull()
            if (savedProfile == null) {
                _state.value = AppState()
            } else {
                connectProfile(savedProfile, restoring = true)
            }
        }
    }

    fun connect(profile: Profile) = connectProfile(profile, restoring = false)

    private fun connectProfile(profile: Profile, restoring: Boolean) = viewModelScope.launch {
        _state.value = _state.value.copy(restoringSession = restoring, loading = true, error = null)
        runCatching { repository.load(profile) }
            .onSuccess { channels ->
                // A provider connection must remain usable even if an old
                // debug install left unreadable encrypted preferences.
                runCatching { secureStore.saveProfile(profile) }
                guideSearchIndex = emptyMap()
                _state.value = AppState(profile = profile, channels = channels, favorites = favoritesStore.favorites(profile.id))
                refreshCatalogs(channels)
            }
            .onFailure {
                _state.value = AppState(
                    error = if (restoring) {
                        "Saved provider could not reconnect: ${it.message ?: "provider unavailable"}"
                    } else {
                        it.message ?: "Could not load playlist"
                    }
                )
            }
    }

    fun refreshCatalogs(content: List<Channel> = _state.value.channels) {
        if (content.isEmpty() || _state.value.catalogsLoading) return
        val credential = secureStore.tmdbCredential().orEmpty().ifBlank { bundledTmdbCredential }
        viewModelScope.launch {
            _state.value = _state.value.copy(catalogsLoading = true, catalogMessage = null)
            runCatching {
                coroutineScope {
                    val free = async { runCatching { freeCatalogClient.catalogs() } }
                    val tmdb = credential.takeIf(String::isNotBlank)?.let { key -> async { runCatching { TmdbCatalogClient(key).catalogs(content) } } }
                    val freeResult = free.await()
                    val tmdbResult = tmdb?.await()
                    if (freeResult.isFailure && (tmdbResult == null || tmdbResult.isFailure)) {
                        throw freeResult.exceptionOrNull() ?: tmdbResult?.exceptionOrNull() ?: error("No catalog service available")
                    }
                    val freeCatalogs = freeResult.getOrNull()
                    val tmdbCatalogs = tmdbResult?.getOrNull()
                    tv.astrawave.player.data.TmdbCatalogs(
                        movies = mergeShelves(freeCatalogs?.movies.orEmpty(), tmdbCatalogs?.movies.orEmpty()),
                        series = mergeShelves(freeCatalogs?.series.orEmpty(), tmdbCatalogs?.series.orEmpty())
                    )
                }
            }.onSuccess { catalogs ->
                _state.value = _state.value.copy(
                    movieCatalogs = catalogs.movies,
                    seriesCatalogs = catalogs.series,
                    catalogsLoading = false,
                    catalogMessage = if (catalogs.movies.isEmpty() && catalogs.series.isEmpty()) "Online catalogs returned no titles; provider VOD is still available" else null
                )
            }.onFailure {
                _state.value = _state.value.copy(catalogsLoading = false, catalogMessage = "Online catalogs unavailable: ${it.message ?: "network error"}. Provider VOD is still available.")
            }
        }
    }

    fun searchCatalog(query: String, kind: MediaKind) {
        val clean = query.trim()
        if (clean.length < 2) {
            catalogSearchJobs.remove(kind)?.cancel()
            _state.value = _state.value.copy(
                catalogSearchResults = _state.value.catalogSearchResults - kind,
                catalogSearchQuery = _state.value.catalogSearchQuery - kind,
                catalogSearchLoading = _state.value.catalogSearchLoading - kind
            )
            return
        }
        if (_state.value.catalogSearchQuery[kind] == clean) return
        catalogSearchJobs.remove(kind)?.cancel()
        _state.value = _state.value.copy(
            catalogSearchQuery = _state.value.catalogSearchQuery + (kind to clean),
            catalogSearchLoading = _state.value.catalogSearchLoading + kind
        )
        catalogSearchJobs[kind] = viewModelScope.launch {
            val results = runCatching { freeCatalogClient.search(clean, kind) }.getOrDefault(emptyList())
            if (_state.value.catalogSearchQuery[kind] != clean) return@launch
            _state.value = _state.value.copy(
                catalogSearchResults = _state.value.catalogSearchResults + (kind to results),
                catalogSearchLoading = _state.value.catalogSearchLoading - kind
            )
            catalogSearchJobs.remove(kind)
        }
    }

    private fun mergeShelves(primary: List<CuratedShelf>, secondary: List<CuratedShelf>): List<CuratedShelf> =
        (primary + secondary).distinctBy { it.title.lowercase(Locale.US) }

    fun catalogCredentialChanged() {
        _state.value = _state.value.copy(movieCatalogs = emptyList(), seriesCatalogs = emptyList(), catalogMessage = null)
        refreshCatalogs()
    }

    fun loadGuide() {
        val profile = _state.value.profile ?: return
        if (_state.value.guideLoading || _state.value.programs.isNotEmpty()) return
        viewModelScope.launch {
            _state.value = _state.value.copy(guideLoading = true)
            runCatching { repository.loadPrograms(profile) }
                .onSuccess { programs ->
                    guideSearchIndex = programs.groupBy { it.channelId }.mapValues { (_, schedule) -> schedule.take(12).joinToString(" ") { it.title } }
                    _state.value = _state.value.copy(programs = programs, guideLoading = false)
                }
                .onFailure { _state.value = _state.value.copy(guideLoading = false, error = "Guide unavailable: ${it.message ?: "provider error"}") }
        }
    }

    fun play(channel: Channel?) {
        if (channel?.kind == tv.astrawave.player.model.MediaKind.LIVE) playbackStore.saveRecentLive(channel.id)
        _state.value = _state.value.copy(playing = channel)
    }
    fun disconnect() { guideSearchIndex = emptyMap(); _state.value = AppState() }
    fun clearError() { _state.value = _state.value.copy(error = null) }
    fun playCatchup(channel: Channel, program: Program) {
        val profile = _state.value.profile ?: return
        runCatching { repository.catchup(profile, channel, program) }
            .onSuccess { play(it) }
            .onFailure { _state.value = _state.value.copy(error = it.message ?: "Could not start catch-up") }
    }
    fun toggleFavorite(id: String) {
        val next = _state.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        _state.value = _state.value.copy(favorites = next)
        _state.value.profile?.let { favoritesStore.save(it.id, next) }
    }

    fun programsFor(channel: Channel): List<Program> = _state.value.programs.filter { it.channelId == channel.epgId || it.channelId == channel.id }

    fun loadSeriesEpisodes(series: Channel) {
        val providerId = series.providerId ?: return
        val profile = _state.value.profile ?: return
        if (_state.value.episodesBySeries.containsKey(series.id) || _state.value.seriesLoadingId == series.id) return
        viewModelScope.launch {
            _state.value = _state.value.copy(seriesLoadingId = series.id, error = null)
            runCatching { repository.loadEpisodes(profile, providerId) }
                .onSuccess { episodes -> _state.value = _state.value.copy(episodesBySeries = _state.value.episodesBySeries + (series.id to episodes), seriesLoadingId = null) }
                .onFailure { _state.value = _state.value.copy(seriesLoadingId = null, error = it.message ?: "Could not load episodes") }
        }
    }

    fun refreshSports(force: Boolean = false) {
        if (_state.value.sportsLoading || (!force && System.currentTimeMillis() - _state.value.sportsUpdatedAt < 120_000)) return
        viewModelScope.launch {
            _state.value = _state.value.copy(sportsLoading = true)
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            runCatching { sportsClient.events(date) }
                .onSuccess { events -> _state.value = _state.value.copy(sportsEvents = events, sportsLoading = false, sportsUpdatedAt = System.currentTimeMillis()) }
                .onFailure { _state.value = _state.value.copy(sportsLoading = false, error = it.message ?: "Could not refresh sports") }
        }
    }

    fun matches(event: SportsEvent, channels: List<Channel> = _state.value.channels): List<ChannelMatch> = ChannelMatcher.rank(
        event.broadcasters + listOf(event.home, event.away, event.league, event.title, "${event.home} ${event.away}"), channels, guideSearchIndex
    )
}
