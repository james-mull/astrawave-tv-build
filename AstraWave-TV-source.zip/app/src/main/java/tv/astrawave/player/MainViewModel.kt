package tv.astrawave.player

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import tv.astrawave.player.data.ChannelMatcher
import tv.astrawave.player.data.IptvRepository
import tv.astrawave.player.model.Channel
import tv.astrawave.player.model.ChannelMatch
import tv.astrawave.player.model.Profile
import tv.astrawave.player.model.SportsEvent

data class AppState(
    val profile: Profile? = null,
    val channels: List<Channel> = emptyList(),
    val favorites: Set<String> = emptySet(),
    val loading: Boolean = false,
    val error: String? = null,
    val playing: Channel? = null
)

class MainViewModel(private val repository: IptvRepository = IptvRepository()) : ViewModel() {
    private val _state = MutableStateFlow(AppState())
    val state = _state.asStateFlow()

    fun connect(profile: Profile) = viewModelScope.launch {
        _state.value = _state.value.copy(loading = true, error = null)
        runCatching { repository.load(profile) }
            .onSuccess { _state.value = AppState(profile = profile, channels = it) }
            .onFailure { _state.value = _state.value.copy(loading = false, error = it.message ?: "Could not load playlist") }
    }

    fun play(channel: Channel?) { _state.value = _state.value.copy(playing = channel) }
    fun toggleFavorite(id: String) {
        val next = _state.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        _state.value = _state.value.copy(favorites = next)
    }

    fun matches(event: SportsEvent): List<ChannelMatch> = ChannelMatcher.rank(
        listOf(event.home, event.away, event.league, "${event.home} ${event.away}"), _state.value.channels
    )
}
