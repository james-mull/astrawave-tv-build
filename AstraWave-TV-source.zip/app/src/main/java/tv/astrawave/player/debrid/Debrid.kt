package tv.astrawave.player.debrid

import tv.astrawave.player.model.DebridProvider

data class DeviceCode(val code: String, val verificationUrl: String, val deviceCode: String, val expiresIn: Int)
data class ResolvedMedia(val url: String, val filename: String = "", val mimeType: String? = null)

interface DebridClient {
    val provider: DebridProvider
    suspend fun beginLink(): DeviceCode
    suspend fun pollToken(deviceCode: String): String?
    suspend fun unrestrict(link: String, token: String): ResolvedMedia
}

/**
 * Provider implementations belong behind this interface because device-flow URLs,
 * client IDs and approval requirements differ. Never place a private client secret
 * in the APK. Production builds should proxy secret-bearing exchanges through a backend.
 */
class DebridRegistry(private val clients: Set<DebridClient>) {
    fun client(provider: DebridProvider) = clients.firstOrNull { it.provider == provider }
}
