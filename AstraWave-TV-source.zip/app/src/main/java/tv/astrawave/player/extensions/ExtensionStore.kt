package tv.astrawave.player.extensions

import android.content.Context
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class ExtensionStore(context: Context) {
    private val prefs = context.getSharedPreferences("astrawave_extensions", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }
    fun load(): List<InstalledExtension> = runCatching { json.decodeFromString<List<InstalledExtension>>(prefs.getString("installed", "[]")!!) }.getOrDefault(emptyList())
    fun save(items: List<InstalledExtension>) = prefs.edit().putString("installed", json.encodeToString(items)).apply()
}
