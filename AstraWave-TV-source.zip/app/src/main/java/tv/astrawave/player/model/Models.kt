package tv.astrawave.player.model

import kotlinx.serialization.Serializable

@Serializable enum class SourceType { XTREAM, M3U }
enum class MediaKind { LIVE, MOVIE, SERIES, CATCHUP }

@Serializable data class Profile(
    val id: String,
    val name: String,
    val type: SourceType,
    val server: String,
    val username: String = "",
    val password: String = "",
    val epgUrl: String = ""
)

data class Channel(
    val id: String,
    val name: String,
    val streamUrl: String,
    val logo: String? = null,
    val group: String = "Other",
    val epgId: String? = null,
    val kind: MediaKind = MediaKind.LIVE,
    val providerId: String? = null,
    val plot: String = "",
    val year: String = "",
    val rating: String = "",
    val backdrop: String? = null,
    val catchupDays: Int = 0,
    val catchupTimezone: String = "UTC",
    val fallbackStreamUrl: String? = null
)

data class Program(
    val channelId: String,
    val title: String,
    val startMillis: Long,
    val endMillis: Long,
    val description: String = ""
)

data class Episode(
    val id: String,
    val seriesId: String,
    val season: Int,
    val number: Int,
    val title: String,
    val streamUrl: String,
    val plot: String = "",
    val artwork: String? = null,
    val duration: String = "",
    val rating: String = ""
)

data class SportsEvent(
    val id: String,
    val league: String,
    val home: String,
    val away: String,
    val startMillis: Long,
    val status: String,
    val homeScore: String = "",
    val awayScore: String = "",
    val title: String = ""
)

data class ChannelMatch(val channel: Channel, val score: Int, val reasons: List<String>)
enum class DebridProvider { REAL_DEBRID, ALL_DEBRID, PREMIUMIZE }
