package tv.astrawave.player.model

enum class SourceType { XTREAM, M3U }
enum class MediaKind { LIVE, MOVIE, SERIES }

data class Profile(
    val id: String,
    val name: String,
    val type: SourceType,
    val server: String,
    val username: String = "",
    val password: String = "",
    val epgUrl: String = ""
)

data class Channel(
    val id: String,
    val name: String,
    val streamUrl: String,
    val logo: String? = null,
    val group: String = "Other",
    val epgId: String? = null,
    val kind: MediaKind = MediaKind.LIVE
)

data class Program(
    val channelId: String,
    val title: String,
    val startMillis: Long,
    val endMillis: Long,
    val description: String = ""
)

data class SportsEvent(
    val id: String,
    val league: String,
    val home: String,
    val away: String,
    val startMillis: Long,
    val status: String,
    val homeScore: String = "",
    val awayScore: String = ""
)

data class ChannelMatch(val channel: Channel, val score: Int, val reasons: List<String>)
enum class DebridProvider { REAL_DEBRID, ALL_DEBRID, PREMIUMIZE }
