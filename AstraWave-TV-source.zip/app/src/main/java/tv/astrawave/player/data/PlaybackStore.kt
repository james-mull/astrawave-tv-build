package tv.astrawave.player.data

import android.content.Context

data class PlaybackProgress(val positionMs: Long, val durationMs: Long) {
    val fraction: Float get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val watched: Boolean get() = durationMs > 0 && fraction >= .9f
}

class PlaybackStore(context: Context) {
    private val prefs = context.getSharedPreferences("astrawave_playback", Context.MODE_PRIVATE)
    fun progress(id: String) = PlaybackProgress(prefs.getLong("pos_$id", 0L), prefs.getLong("dur_$id", 0L))
    fun activeIds(): Set<String> = prefs.all.keys.asSequence()
        .filter { it.startsWith("pos_") }
        .map { it.removePrefix("pos_") }
        .filter { progress(it).fraction in .01f..0.89f }
        .toSet()
    fun recentLiveIds(): List<String> = prefs.getString("recent_live", "").orEmpty().split('\u001F').filter(String::isNotBlank)
    fun saveRecentLive(id: String) {
        val recent = (listOf(id) + recentLiveIds().filterNot { it == id }).take(20)
        prefs.edit().putString("recent_live", recent.joinToString("\u001F")).apply()
    }
    fun save(id: String, positionMs: Long, durationMs: Long) {
        if (positionMs < 0 || durationMs <= 0) return
        prefs.edit().putLong("pos_$id", positionMs).putLong("dur_$id", durationMs).apply()
    }
    fun clear(id: String) = prefs.edit().remove("pos_$id").remove("dur_$id").apply()
}
