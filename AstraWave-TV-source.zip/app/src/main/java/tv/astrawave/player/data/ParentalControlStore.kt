package tv.astrawave.player.data

import android.content.Context
import tv.astrawave.player.model.Channel

class ParentalControlStore(context: Context) {
    private val prefs = context.getSharedPreferences("astrawave_parental", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = prefs.getBoolean("enabled", false)
        set(value) {
            prefs.edit().putBoolean("enabled", value).apply()
        }

    var blockedKeywords: String
        get() = prefs.getString("keywords", "adult,xxx,18+") ?: "adult,xxx,18+"
        set(value) {
            prefs.edit().putString("keywords", value).apply()
        }

    fun isBlocked(item: Channel): Boolean {
        if (!enabled) return false
        val haystack = "${item.name} ${item.group}".lowercase()
        return blockedKeywords.split(',').map { it.trim().lowercase() }.filter { it.isNotBlank() }.any { haystack.contains(it) }
    }
}
