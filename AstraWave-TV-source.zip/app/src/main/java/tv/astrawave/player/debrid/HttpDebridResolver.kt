package tv.astrawave.player.debrid

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import tv.astrawave.player.model.DebridProvider

class HttpDebridResolver(
    private val http: OkHttpClient = OkHttpClient(),
    private val json: Json = Json { ignoreUnknownKeys = true }
) {
    suspend fun resolve(provider: DebridProvider, source: String, token: String): ResolvedMedia = withContext(Dispatchers.IO) {
        require(source.startsWith("https://") || source.startsWith("http://")) { "Only HTTP(S) links are accepted" }
        require(token.isNotBlank()) { "Connect the selected provider first" }
        when (provider) {
            DebridProvider.REAL_DEBRID -> realDebrid(source, token)
            DebridProvider.ALL_DEBRID -> allDebrid(source, token)
            DebridProvider.PREMIUMIZE -> premiumize(source, token)
        }.also { require(it.url.startsWith("https://") || it.url.startsWith("http://")) { "Provider returned an invalid media URL" } }
    }

    private fun realDebrid(source: String, token: String): ResolvedMedia {
        val request = Request.Builder().url("https://api.real-debrid.com/rest/1.0/unrestrict/link")
            .header("Authorization", "Bearer $token").post(FormBody.Builder().add("link", source).build()).build()
        val root = execute(request)
        return ResolvedMedia(root["download"]!!.jsonPrimitive.content, root["filename"]?.jsonPrimitive?.content.orEmpty())
    }

    private fun allDebrid(source: String, token: String): ResolvedMedia {
        val request = Request.Builder().url("https://api.alldebrid.com/v4/link/unlock")
            .header("Authorization", "Bearer $token").post(FormBody.Builder().add("link", source).build()).build()
        val data = execute(request)["data"]!!.jsonObject
        return ResolvedMedia(data["link"]!!.jsonPrimitive.content, data["filename"]?.jsonPrimitive?.content.orEmpty())
    }

    private fun premiumize(source: String, token: String): ResolvedMedia {
        val request = Request.Builder().url("https://www.premiumize.me/api/transfer/directdl")
            .header("Authorization", "Bearer $token").post(FormBody.Builder().add("src", source).build()).build()
        val first = execute(request)["content"]!!.jsonArray.first().jsonObject
        return ResolvedMedia(first["link"]!!.jsonPrimitive.content, first["path"]?.jsonPrimitive?.content.orEmpty())
    }

    private fun execute(request: Request) = http.newCall(request).execute().use { response ->
        val body = response.body?.string().orEmpty()
        if (!response.isSuccessful) error("Debrid provider request failed (${response.code})")
        json.parseToJsonElement(body).jsonObject.also { root ->
            root["error"]?.let { error(it.toString()) }
            if (root["status"]?.jsonPrimitive?.content == "error") error("Debrid provider rejected the link")
        }
    }
}
