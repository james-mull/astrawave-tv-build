package tv.astrawave.player.extensions

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

enum class ExtensionKind { STREMIO, CLOUDSTREAM_REPOSITORY }

@Serializable
data class StremioManifest(
    val id: String,
    val name: String,
    val description: String = "",
    val version: String,
    val resources: List<ResourceRef> = emptyList(),
    val types: List<String> = emptyList(),
    val catalogs: List<StremioCatalog> = emptyList()
)

@Serializable
data class ResourceRef(val name: String = "")

@Serializable
data class StremioCatalog(
    val type: String,
    val id: String,
    val name: String? = null,
    val extra: List<CatalogExtra> = emptyList()
)

@Serializable data class CatalogExtra(val name: String, val isRequired: Boolean = false)

@Serializable
data class StremioMeta(
    val id: String,
    val type: String,
    val name: String,
    val poster: String? = null,
    val background: String? = null,
    val description: String? = null,
    val releaseInfo: String? = null
)

@Serializable data class CatalogResponse(val metas: List<StremioMeta> = emptyList())

@Serializable
data class StremioStream(
    val url: String? = null,
    val ytId: String? = null,
    val externalUrl: String? = null,
    val title: String? = null,
    val name: String? = null
)

@Serializable data class StreamResponse(val streams: List<StremioStream> = emptyList())

@Serializable
data class CloudStreamPlugin(
    val name: String,
    val url: String? = null,
    val version: Int? = null,
    val status: Int? = null,
    val language: String? = null,
    val tvTypes: List<String> = emptyList()
)

@Serializable
data class InstalledExtension(
    val id: String,
    val name: String,
    val sourceUrl: String,
    val kind: ExtensionKind,
    val enabled: Boolean = true,
    val trusted: Boolean = false
)
