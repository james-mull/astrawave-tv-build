package tv.astrawave.player.data

import android.content.Context

enum class BufferMode(val minMs: Int, val maxMs: Int, val playbackMs: Int) {
    FAST(8_000, 20_000, 800), BALANCED(15_000, 45_000, 1_500), LARGE(30_000, 90_000, 2_500)
}

class PlaybackPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("astrawave_preferences", Context.MODE_PRIVATE)
    var bufferMode: BufferMode
        get() = runCatching { BufferMode.valueOf(prefs.getString("buffer", BufferMode.BALANCED.name)!!) }.getOrDefault(BufferMode.BALANCED)
        set(value) { prefs.edit().putString("buffer", value.name).apply() }
    var subtitlesEnabled: Boolean
        get() = prefs.getBoolean("subtitles", true)
        set(value) { prefs.edit().putBoolean("subtitles", value).apply() }
    var autoplayNext: Boolean
        get() = prefs.getBoolean("autoplay_next", true)
        set(value) { prefs.edit().putBoolean("autoplay_next", value).apply() }
}
