package tv.astrawave.player.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF071015)
val Panel = Color(0xFF102028)
val Mint = Color(0xFF38E8B7)
val Violet = Color(0xFF7C5CFF)
val Muted = Color(0xFF9BAFB8)

@Composable fun AstraWaveTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Mint, secondary = Violet, background = Ink,
            surface = Panel, onPrimary = Ink, onBackground = Color.White
        ),
        content = content
    )
}
