package tv.astrawave.player.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF090909)
val Panel = Color(0xFF181818)
val Mint = Color(0xFFE50914) // AstraWave cinematic red
val Violet = Color(0xFFB20710)
val Muted = Color(0xFFB3B3B3)

@Composable fun AstraWaveTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Mint, secondary = Violet, background = Ink,
            surface = Panel, onPrimary = Ink, onBackground = Color.White
        ),
        content = content
    )
}
