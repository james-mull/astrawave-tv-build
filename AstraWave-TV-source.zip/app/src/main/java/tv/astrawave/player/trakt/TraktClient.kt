package tv.astrawave.player.trakt

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

@Serializable data class TraktDeviceCode(val device_code: String, val user_code: String, val verification_url: String, val expires_in: Int, val interval: Int)
@Serializable data class TraktToken(val access_token: String, val token_type: String = "bearer", val expires_in: Int = 0, val refresh_token: String = "", val scope: String = "public", val created_at: Long = 0)

class TraktClient(private val clientId: String, private val http: OkHttpClient = OkHttpClient(), private val json: Json = Json { ignoreUnknownKeys = true }) {
    private val mediaType = "application/json; charset=utf-8".toMediaType()
    suspend fun requestDeviceCode(): TraktDeviceCode = post("https://api.trakt.tv/oauth/device/code", "{\"client_id\":\"$clientId\"}")
    suspend fun waitForAuthorization(code: TraktDeviceCode): TraktToken = withContext(Dispatchers.IO) {
        val deadline = System.currentTimeMillis() + code.expires_in * 1000L
        while (System.currentTimeMillis() < deadline) {
            delay(code.interval.coerceAtLeast(5) * 1000L)
            val body = json.encodeToString(mapOf("code" to code.device_code, "client_id" to clientId))
            val request = Request.Builder().url("https://api.trakt.tv/oauth/device/token").post(body.toRequestBody(mediaType)).build()
            http.newCall(request).execute().use { response ->
                when (response.code) {
                    200 -> return@withContext json.decodeFromString(response.body!!.string())
                    400 -> Unit
                    404 -> error("Trakt device code is invalid")
                    409 -> error("Trakt device code was already used")
                    410 -> error("Trakt device code expired")
                    418 -> error("Trakt authorization was denied")
                    429 -> delay(5000L)
                    else -> error("Trakt authorization failed (${response.code})")
                }
            }
        }
        error("Trakt device code expired")
    }
    private suspend inline fun <reified T> post(url: String, body: String): T = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(url).post(body.toRequestBody(mediaType)).build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Trakt request failed (${response.code})")
            json.decodeFromString(response.body!!.string())
        }
    }
}
