package tv.astrawave.player.ui

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.TrackSelectionDialogBuilder
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import tv.astrawave.player.BuildConfig
import tv.astrawave.player.MainViewModel
import tv.astrawave.player.data.ContentDiscovery
import tv.astrawave.player.data.ContentPreferences
import tv.astrawave.player.data.SecureStore
import tv.astrawave.player.data.PlaybackStore
import tv.astrawave.player.data.PlaybackPreferences
import tv.astrawave.player.data.BufferMode
import tv.astrawave.player.data.DeviceMode
import tv.astrawave.player.data.DeviceModeStore
import tv.astrawave.player.data.ParentalControlStore
import tv.astrawave.player.debrid.HttpDebridResolver
import tv.astrawave.player.extensions.CloudStreamRepositoryClient
import tv.astrawave.player.extensions.ExtensionKind
import tv.astrawave.player.extensions.ExtensionStore
import tv.astrawave.player.extensions.InstalledExtension
import tv.astrawave.player.extensions.StremioAddonClient
import tv.astrawave.player.model.*
import tv.astrawave.player.trakt.TraktClient
import tv.astrawave.player.trakt.TraktDeviceCode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Destination(val label: String) { HOME("Home"), SEARCH("Search"), LIVE("Live TV"), GUIDE("Guide"), EVENTS("Live Events"), MOVIES("Movies"), SERIES("Series"), MY_LIST("My List"), GAMES("Games"), TRAKT("Trakt"), EXTENSIONS("Extensions"), DEBRID("Debrid"), SETTINGS("Settings") }
private enum class VodSort(val label: String) { FEATURED("Featured"), NEWEST("Newest"), RATING("Rating"), AZ("A–Z") }

private fun searchScore(item: Channel, query: String): Int {
    val needle = query.trim().lowercase(Locale.getDefault())
    if (needle.isBlank()) return 0
    val name = item.name.lowercase(Locale.getDefault())
    val group = item.group.lowercase(Locale.getDefault())
    val searchable = "$name $group ${item.year} ${item.plot.lowercase(Locale.getDefault())} ${item.epgId.orEmpty().lowercase(Locale.getDefault())}"
    val terms = needle.split(Regex("\\s+")).filter { it.length > 1 }
    if (terms.any { !searchable.contains(it) }) return 0
    return when {
        name == needle -> 120
        name.startsWith(needle) -> 95
        name.contains(needle) -> 75
        group == needle -> 55
        else -> 30 + terms.count { name.contains(it) } * 8
    }
}

private fun franchiseKey(title: String): String? {
    val cleaned = title.replace(Regex("\\((19|20)\\d{2}\\)"), "").substringBefore(':').trim()
    val words = cleaned.split(Regex("[^A-Za-z0-9]+"))
        .filter { it.length > 2 && it.lowercase(Locale.US) !in setOf("the", "and", "part", "chapter") }
    return words.take(2).takeIf { it.size == 2 }?.joinToString(" ") { it.lowercase(Locale.US).replaceFirstChar(Char::uppercase) }
}

private fun Episode.asChannel() = Channel("episode-$id", title, streamUrl, artwork, "Season $season", kind = MediaKind.SERIES, providerId = id, plot = plot, rating = rating)

private fun scheduleFor(channel: Channel, programsByChannel: Map<String, List<Program>>): List<Program> =
    if (channel.epgId == null || channel.epgId == channel.id) programsByChannel[channel.id].orEmpty()
    else programsByChannel[channel.epgId].orEmpty() + programsByChannel[channel.id].orEmpty()

private fun playbackCandidates(url: String): List<String> {
    if (url.isBlank()) return emptyList()
    val alternate = when {
        Regex("(?i)\\.ts(?=\\?|$)").containsMatchIn(url) -> url.replace(Regex("(?i)\\.ts(?=\\?|$)"), ".m3u8")
        Regex("(?i)\\.m3u8(?=\\?|$)").containsMatchIn(url) -> url.replace(Regex("(?i)\\.m3u8(?=\\?|$)"), ".ts")
        else -> null
    }
    return listOfNotNull(url, alternate).distinct()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AstraWaveApp(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val deviceStore = remember { DeviceModeStore(context) }
    // Pick the appropriate layout automatically on a fresh install so the
    // provider login is always the first interactive screen. Users can still
    // override this later from Settings.
    var deviceMode by remember { mutableStateOf(deviceStore.selected() ?: deviceStore.recommended()) }
    val parentalStore = remember { ParentalControlStore(context) }
    var parentalUnlocked by remember { mutableStateOf(false) }
    var parentalRevision by remember { mutableIntStateOf(0) }
    LaunchedEffect(deviceMode) { (context as? Activity)?.requestedOrientation = if (deviceMode == DeviceMode.TV) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    val state by vm.state.collectAsState()
    val focusManager = LocalFocusManager.current
    LaunchedEffect(state.profile) {
        if (state.profile != null) {
            focusManager.clearFocus(force = true)
            (context as? Activity)?.let { activity ->
                WindowCompat.getInsetsController(activity.window, activity.window.decorView).hide(WindowInsetsCompat.Type.ime())
            }
        }
    }
    val parentalEnabled = parentalRevision.let { parentalStore.enabled }
    val visibleChannels = remember(state.channels, parentalEnabled, parentalUnlocked, parentalRevision) {
        if (parentalEnabled && !parentalUnlocked) state.channels.filterNot(parentalStore::isBlocked) else state.channels
    }
    val liveChannels = remember(visibleChannels) { visibleChannels.filter { it.kind == MediaKind.LIVE } }
    val movieChannels = remember(visibleChannels) { visibleChannels.filter { it.kind == MediaKind.MOVIE } }
    val seriesChannels = remember(visibleChannels) { visibleChannels.filter { it.kind == MediaKind.SERIES } }
    val vodChannels = remember(movieChannels, seriesChannels) { movieChannels + seriesChannels }
    var destination by remember { mutableStateOf(Destination.HOME) }
    var selectedContent by remember { mutableStateOf<Channel?>(null) }
    val openContent: (Channel) -> Unit = { item -> if (item.kind == MediaKind.LIVE) vm.play(item) else { if (item.kind == MediaKind.SERIES) vm.loadSeriesEpisodes(item); selectedContent = item } }
    if (state.playing != null) {
        BackHandler { vm.play(null) }
        PlayerScreen(state.playing!!, visibleChannels, vm::play, onBack = { vm.play(null) })
        return
    }
    if (state.restoringSession) {
        Box(
            Modifier.fillMaxSize().background(Ink).safeDrawingPadding(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                CircularProgressIndicator(color = Mint)
                Text("Signing you back in…", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Loading your saved provider", color = Muted)
            }
        }
        return
    }
    if (state.profile == null) {
        Box(Modifier.fillMaxSize().background(Ink).safeDrawingPadding()) {
            LoginScreen(
                loading = state.loading,
                error = state.error,
                clearError = vm::clearError,
                connect = { profile -> destination = Destination.HOME; vm.connect(profile) }
            )
        }
        return
    }
    BackHandler(enabled = selectedContent != null || (state.profile != null && destination != Destination.HOME)) {
        if (selectedContent != null) selectedContent = null else destination = Destination.HOME
    }
    val content: @Composable BoxScope.() -> Unit = {
            when {
                selectedContent != null -> ContentDetailsScreen(selectedContent!!, visibleChannels, state.episodesBySeries[selectedContent!!.id].orEmpty(), state.seriesLoadingId == selectedContent!!.id, { selectedContent = null }, { if (it.kind == MediaKind.SERIES) vm.loadSeriesEpisodes(it); selectedContent = it }, vm::play, vm::toggleFavorite, state.favorites)
                destination == Destination.HOME -> HomeScreen(visibleChannels, state.favorites, state.profile?.name.orEmpty(), openContent, { state.profile?.let(vm::connect) }) { destination = it }
                destination == Destination.SEARCH -> UniversalSearchScreen(visibleChannels, openContent)
                destination == Destination.LIVE -> {
                    LaunchedEffect(state.profile?.id) { vm.loadGuide() }
                    ChannelBrowser(liveChannels, state.programs, state.guideLoading, state.favorites, vm::toggleFavorite, openContent) { destination = Destination.HOME }
                }
                destination == Destination.GUIDE -> {
                    LaunchedEffect(state.profile?.id) { vm.loadGuide() }
                    GuideScreen(liveChannels, state.programs, state.guideLoading, state.favorites, vm::toggleFavorite, vm::play, vm::playCatchup) { destination = Destination.HOME }
                }
                destination == Destination.EVENTS -> EventsScreen(vm, liveChannels)
                destination == Destination.MOVIES -> PosterShelf("Movies", movieChannels, openContent) { destination = Destination.HOME }
                destination == Destination.SERIES -> PosterShelf("Series", seriesChannels, openContent) { destination = Destination.HOME }
                destination == Destination.MY_LIST -> MyListScreen(visibleChannels.filter { it.id in state.favorites }, openContent, vm::toggleFavorite) { destination = Destination.HOME }
                destination == Destination.GAMES -> GamesScreen()
                destination == Destination.TRAKT -> TraktScreen(vodChannels, openContent)
                destination == Destination.EXTENSIONS -> ExtensionsScreen()
                destination == Destination.DEBRID -> DebridScreen(vm::play)
                else -> SettingsScreen(state.profile!!, visibleChannels, vm::connect, vm::disconnect, { state.profile?.let(vm::connect) }, deviceMode!!, { mode -> deviceStore.save(mode); deviceMode = mode }, parentalStore, parentalUnlocked, { parentalUnlocked = it }, { parentalRevision++ })
            }
            if (state.loading) {
                Column(Modifier.align(Alignment.Center).background(Color.Black.copy(alpha = .90f), RoundedCornerShape(14.dp)).padding(horizontal = 30.dp, vertical = 22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(Modifier.size(30.dp), color = Mint, strokeWidth = 3.dp)
                    Text("Syncing your provider", fontWeight = FontWeight.Bold)
                    Text("Loading channels, movies and series…", color = Muted, fontSize = 12.sp)
                }
            }
            state.error?.let { message ->
                Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xFF3A1114), RoundedCornerShape(10.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ErrorOutline, null, tint = Color(0xFFFFB4AB))
                    Text(message, color = Color(0xFFFFDAD6), modifier = Modifier.padding(horizontal = 10.dp).weight(1f), maxLines = 3, overflow = TextOverflow.Ellipsis)
                    IconButton(onClick = vm::clearError) { Icon(Icons.Default.Close, "Dismiss error") }
                }
            }
    }
    if (deviceMode == DeviceMode.PHONE) {
        val primaryDestinations = remember { listOf(Destination.HOME, Destination.SEARCH, Destination.LIVE, Destination.MOVIES, Destination.SERIES) }
        val moreDestinations = remember { Destination.entries.filterNot(primaryDestinations::contains) }
        var moreExpanded by remember { mutableStateOf(false) }
        Column(Modifier.fillMaxSize().background(Ink).safeDrawingPadding()) {
            Surface(color = Color(0xFF130507), modifier = Modifier.fillMaxWidth().height(64.dp)) {
                Row(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ASTRAWAVE", color = Mint, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text(state.profile?.name.orEmpty(), color = Muted, fontSize = 11.sp)
                    }
                    Text("${visibleChannels.size} ITEMS", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(BuildConfig.VERSION_NAME, color = Mint, fontSize = 10.sp, modifier = Modifier.padding(start = 10.dp))
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                when {
                    selectedContent != null -> ContentDetailsScreen(selectedContent!!, visibleChannels, state.episodesBySeries[selectedContent!!.id].orEmpty(), state.seriesLoadingId == selectedContent!!.id, { selectedContent = null }, { if (it.kind == MediaKind.SERIES) vm.loadSeriesEpisodes(it); selectedContent = it }, vm::play, vm::toggleFavorite, state.favorites)
                    destination == Destination.HOME -> HomeScreen(visibleChannels, state.favorites, state.profile?.name.orEmpty(), openContent, { state.profile?.let(vm::connect) }) { destination = it }
                    destination == Destination.SEARCH -> UniversalSearchScreen(visibleChannels, openContent)
                    destination == Destination.LIVE -> { LaunchedEffect(state.profile?.id) { vm.loadGuide() }; ChannelBrowser(liveChannels, state.programs, state.guideLoading, state.favorites, vm::toggleFavorite, openContent) { destination = Destination.HOME } }
                    destination == Destination.GUIDE -> { LaunchedEffect(state.profile?.id) { vm.loadGuide() }; GuideScreen(liveChannels, state.programs, state.guideLoading, state.favorites, vm::toggleFavorite, vm::play, vm::playCatchup) { destination = Destination.HOME } }
                    destination == Destination.EVENTS -> EventsScreen(vm, liveChannels)
                    destination == Destination.MOVIES -> PosterShelf("Movies", movieChannels, openContent) { destination = Destination.HOME }
                    destination == Destination.SERIES -> PosterShelf("Series", seriesChannels, openContent) { destination = Destination.HOME }
                    destination == Destination.MY_LIST -> MyListScreen(visibleChannels.filter { it.id in state.favorites }, openContent, vm::toggleFavorite) { destination = Destination.HOME }
                    destination == Destination.GAMES -> GamesScreen()
                    destination == Destination.TRAKT -> TraktScreen(vodChannels, openContent)
                    destination == Destination.EXTENSIONS -> ExtensionsScreen()
                    destination == Destination.DEBRID -> DebridScreen(vm::play)
                    else -> SettingsScreen(state.profile!!, visibleChannels, vm::connect, vm::disconnect, { state.profile?.let(vm::connect) }, deviceMode!!, { mode -> deviceStore.save(mode); deviceMode = mode }, parentalStore, parentalUnlocked, { parentalUnlocked = it }, { parentalRevision++ })
                }
                if (state.loading) {
                    Column(Modifier.align(Alignment.Center).background(Color.Black.copy(alpha = .94f), RoundedCornerShape(14.dp)).padding(horizontal = 30.dp, vertical = 22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircularProgressIndicator(Modifier.size(30.dp), color = Mint, strokeWidth = 3.dp)
                        Text("Syncing your provider", fontWeight = FontWeight.Bold)
                        Text("Loading channels, movies and series…", color = Muted, fontSize = 12.sp)
                    }
                }
                state.error?.let { message ->
                    Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xFF3A1114), RoundedCornerShape(10.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ErrorOutline, null, tint = Color(0xFFFFB4AB))
                        Text(message, color = Color(0xFFFFDAD6), modifier = Modifier.padding(horizontal = 10.dp).weight(1f), maxLines = 3, overflow = TextOverflow.Ellipsis)
                        IconButton(onClick = vm::clearError) { Icon(Icons.Default.Close, "Dismiss error") }
                    }
                }
            }
            NavigationBar(containerColor = Color(0xFF050505), tonalElevation = 0.dp) {
                primaryDestinations.forEach { item ->
                    NavigationBarItem(
                        selected = destination == item,
                        onClick = { destination = item; selectedContent = null },
                        icon = { Icon(icon(item), item.label) },
                        label = { Text(item.label, maxLines = 1, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = Color.White, indicatorColor = Mint.copy(alpha = .34f), unselectedIconColor = Muted, unselectedTextColor = Muted)
                    )
                }
                NavigationBarItem(
                    selected = destination in moreDestinations,
                    onClick = { moreExpanded = true },
                    icon = { Icon(Icons.Default.MoreHoriz, "More") },
                    label = { Text("More", maxLines = 1, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = Color.White, indicatorColor = Mint.copy(alpha = .34f), unselectedIconColor = Muted, unselectedTextColor = Muted)
                )
            }
            if (moreExpanded) {
                val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
                ModalBottomSheet(onDismissRequest = { moreExpanded = false }, sheetState = sheetState, containerColor = Panel) {
                    Column(
                        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("More from AstraWave", fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp))
                        moreDestinations.forEach { item ->
                            ListItem(
                                headlineContent = { Text(item.label, fontWeight = FontWeight.SemiBold) },
                                leadingContent = { Icon(icon(item), null, tint = Mint) },
                                trailingContent = { Icon(Icons.Default.ChevronRight, null, tint = Muted) },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { destination = item; selectedContent = null; moreExpanded = false }
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                    }
                }
            }
        }
    } else {
        Row(Modifier.fillMaxSize().background(Ink)) {
            NavigationRail(containerColor = Color(0xFF050505), modifier = Modifier.width(if (deviceMode == DeviceMode.TABLET) 160.dp else 190.dp).verticalScroll(rememberScrollState())) {
                Spacer(Modifier.height(24.dp)); Text("ASTRAWAVE", color = Mint, fontWeight = FontWeight.Black, letterSpacing = 3.sp, modifier = Modifier.padding(12.dp))
                Destination.entries.forEach { item -> NavigationRailItem(selected = destination == item, onClick = { destination = item; selectedContent = null }, icon = { Icon(icon(item), null) }, label = { Text(item.label) }, alwaysShowLabel = true) }
            }
            Box(Modifier.fillMaxSize().padding(if (deviceMode == DeviceMode.TABLET) 20.dp else 28.dp), content = content)
        }
    }
}

@Composable private fun DeviceSetupScreen(recommended: DeviceMode, select: (DeviceMode) -> Unit) {
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF250507), Ink))).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("ASTRAWAVE", color = Mint, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
        Spacer(Modifier.height(18.dp)); Text("How are you watching?", fontSize = 34.sp, fontWeight = FontWeight.Black); Text("Choose a layout. You can change this later in Settings.", color = Muted)
        Spacer(Modifier.height(28.dp)); LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(DeviceMode.entries) { mode -> FocusCard(Modifier.width(210.dp).height(150.dp), onClick = { select(mode) }) { Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Icon(if (mode == DeviceMode.TV) Icons.Default.Tv else if (mode == DeviceMode.TABLET) Icons.Default.Tablet else Icons.Default.PhoneAndroid, null, tint = if (mode == recommended) Mint else Color.White, modifier = Modifier.size(40.dp)); Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 20.sp, fontWeight = FontWeight.Bold); if (mode == recommended) Text("Recommended", color = Mint, fontSize = 12.sp) } } } }
    }
}

private fun icon(d: Destination) = when(d) {
    Destination.HOME -> Icons.Default.Home; Destination.SEARCH -> Icons.Default.Search; Destination.LIVE -> Icons.Default.LiveTv
    Destination.GUIDE -> Icons.Default.ViewTimeline; Destination.EVENTS -> Icons.Default.SportsFootball
    Destination.MOVIES -> Icons.Default.Movie; Destination.SERIES -> Icons.Default.Tv
    Destination.MY_LIST -> Icons.Default.Bookmarks
    Destination.GAMES -> Icons.Default.SportsEsports
    Destination.TRAKT -> Icons.Default.Sync
    Destination.EXTENSIONS -> Icons.Default.Extension; Destination.DEBRID -> Icons.Default.Link; Destination.SETTINGS -> Icons.Default.Settings
}

private data class EmulatorOption(val name: String, val systems: String, val packageName: String, val officialUrl: String)

@Composable private fun MyListScreen(saved: List<Channel>, open: (Channel) -> Unit, remove: (String) -> Unit, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf<MediaKind?>(null) }
    val shown = remember(saved, query, kind) { saved.filter { (kind == null || it.kind == kind) && (query.isBlank() || searchScore(it, query) > 0) } }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionHeader("My List", "${saved.size} saved titles and channels", onBack)
        OutlinedTextField(query, { query = it }, label = { Text("Search My List") }, leadingIcon = { Icon(Icons.Default.Search, null) }, trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, "Clear search") } }, singleLine = true, modifier = Modifier.fillMaxWidth())
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(kind == null, { kind = null }, { Text("All") }) }
            item { FilterChip(kind == MediaKind.LIVE, { kind = MediaKind.LIVE }, { Text("Live TV") }) }
            item { FilterChip(kind == MediaKind.MOVIE, { kind = MediaKind.MOVIE }, { Text("Movies") }) }
            item { FilterChip(kind == MediaKind.SERIES, { kind = MediaKind.SERIES }, { Text("Series") }) }
        }
        if (saved.isEmpty()) EmptyState(Icons.Default.Bookmarks, "My List is empty", "Use Add to My List on a movie, series or channel to keep it here.")
        else if (shown.isEmpty()) EmptyState(Icons.Default.SearchOff, "No saved items matched", "Clear the search or select another content type.")
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 22.dp)) { items(shown, key = { "saved-${it.id}" }) { item -> SavedItemRow(item, open, remove) } }
    }
}

@Composable private fun SavedItemRow(item: Channel, open: (Channel) -> Unit, remove: (String) -> Unit) {
    FocusCard(Modifier.fillMaxWidth().height(88.dp), onClick = { open(item) }) {
        Row(Modifier.fillMaxSize().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(58.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF242424)), contentAlignment = Alignment.Center) { if (item.logo.isNullOrBlank()) Icon(if (item.kind == MediaKind.LIVE) Icons.Default.LiveTv else Icons.Default.Movie, null, tint = Mint) else AsyncImage(item.logo, item.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
            Column(Modifier.padding(horizontal = 14.dp).weight(1f)) { Text(item.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text("${if (item.kind == MediaKind.LIVE) "Live TV" else if (item.kind == MediaKind.SERIES) "Series" else "Movie"} • ${item.group}", color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            IconButton(onClick = { remove(item.id) }) { Icon(Icons.Default.BookmarkRemove, "Remove from My List", tint = Muted) }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable private fun GamesScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("astrawave_games", android.content.Context.MODE_PRIVATE) }
    var games by remember { mutableStateOf(prefs.getStringSet("uris", emptySet()).orEmpty().toSet()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { runCatching { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }; games = games + it.toString(); prefs.edit().putStringSet("uris", games).apply() }
    }
    val emulators = remember { listOf(
        EmulatorOption("RetroArch", "Multi-system retro frontend", "com.retroarch.aarch64", "https://www.retroarch.com/?page=platforms"),
        EmulatorOption("PPSSPP", "PSP", "org.ppsspp.ppsspp", "https://www.ppsspp.org/download/"),
        EmulatorOption("Dolphin", "GameCube and Wii", "org.dolphinemu.dolphinemu", "https://dolphin-emu.org/download/"),
        EmulatorOption("DuckStation", "PlayStation 1", "com.github.stenzek.duckstation", "https://github.com/stenzek/duckstation/releases")
    ) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Games & Emulators", fontSize = 34.sp, fontWeight = FontWeight.Black) }
        item { Text("Launch installed emulators or visit their official download pages. Use only games and firmware you legally own or free homebrew.", color = Muted) }
        item { Text("Emulators", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        items(emulators, key = { it.packageName }) { emulator ->
            val launchIntent = context.packageManager.getLaunchIntentForPackage(emulator.packageName)
            FocusCard(Modifier.fillMaxWidth().height(82.dp), onClick = { if (launchIntent != null) context.startActivity(launchIntent) else context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(emulator.officialUrl))) }) {
                Row(Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.SportsEsports, null, tint = Mint); Column(Modifier.padding(horizontal = 14.dp).weight(1f)) { Text(emulator.name, fontWeight = FontWeight.Bold); Text(emulator.systems, color = Muted) }; Text(if (launchIntent != null) "OPEN" else "OFFICIAL DOWNLOAD", color = if (launchIntent != null) Color(0xFF46D369) else Mint, fontWeight = FontWeight.Bold) }
            }
        }
        item { HorizontalDivider(); Row(verticalAlignment = Alignment.CenterVertically) { Text("My legal game files", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Button(onClick = { picker.launch(arrayOf("application/octet-stream", "application/zip", "application/x-iso9660-image")) }) { Icon(Icons.Default.Add, null); Text(" Add file") } } }
        if (games.isEmpty()) item { Text("No game files added. AstraWave does not include or download ROMs or BIOS files.", color = Muted) }
        items(games.toList(), key = { it }) { value ->
            val uri = Uri.parse(value)
            FocusCard(Modifier.fillMaxWidth().height(72.dp), onClick = { context.startActivity(Intent(Intent.ACTION_VIEW).setData(uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }) {
                Row(Modifier.fillMaxSize().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.FolderOpen, null, tint = Mint); Text(uri.lastPathSegment ?: "Game file", Modifier.padding(horizontal = 12.dp).weight(1f), maxLines = 1); TextButton(onClick = { games = games - value; prefs.edit().putStringSet("uris", games).apply() }) { Text("Remove") } }
            }
        }
    }
}

@Composable private fun TraktScreen(content: List<Channel>, open: (Channel) -> Unit) {
    val context = LocalContext.current
    val store = remember { SecureStore(context) }
    val scope = rememberCoroutineScope()
    var connected by remember { mutableStateOf(store.traktAccessToken() != null) }
    var deviceCode by remember { mutableStateOf<TraktDeviceCode?>(null) }
    var connecting by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item { Text("Trakt", fontSize = 34.sp, fontWeight = FontWeight.Black) }
        item { Text("Sync watch history, progress and lists across supported devices.", color = Muted) }
        item {
            FocusCard(Modifier.fillMaxWidth().heightIn(min = 116.dp), onClick = {}) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(if (connected) "✓ TRAKT CONNECTED" else "TRAKT ACCOUNT", color = if (connected) Color(0xFF46D369) else Mint, fontWeight = FontWeight.Black)
                    when {
                        BuildConfig.TRAKT_CLIENT_ID.isBlank() -> Text("Add TRAKT_CLIENT_ID to Gradle properties before building to enable connection.", color = Muted)
                        deviceCode != null -> { Text("Go to ${deviceCode!!.verification_url}", color = Muted); Text(deviceCode!!.user_code, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp) }
                        else -> Text(if (connected) "Tokens are encrypted on this device." else "Connect using Trakt's secure TV device code.", color = Muted)
                    }
                    if (!connected) Button(enabled = !connecting && BuildConfig.TRAKT_CLIENT_ID.isNotBlank(), onClick = {
                        connecting = true; error = null
                        scope.launch {
                            runCatching { val client = TraktClient(BuildConfig.TRAKT_CLIENT_ID); val code = client.requestDeviceCode(); deviceCode = code; client.waitForAuthorization(code) }
                                .onSuccess { token -> store.saveTraktTokens(token.access_token, token.refresh_token); connected = true; connecting = false; deviceCode = null }
                                .onFailure { error = it.message; connecting = false }
                        }
                    }) { if (connecting) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.Link, null); Text(if (deviceCode == null) " Connect Trakt" else " Waiting for approval") }
                    else OutlinedButton(onClick = { store.clearTrakt(); connected = false }) { Text("Disconnect") }
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }
        }
        if (connected) {
            item { CinematicRail("Trakt Watchlist", content.take(12), open) }
            item { CinematicRail("Continue Watching", content.drop(3).take(12), open, showProgress = true) }
            item { CinematicRail("Recently Watched", content.reversed().take(12), open) }
        }
    }
}

@Composable private fun UniversalSearchScreen(content: List<Channel>, open: (Channel) -> Unit) {
    val context = LocalContext.current
    val searchPrefs = remember(context) { context.getSharedPreferences("astrawave_search", android.content.Context.MODE_PRIVATE) }
    var input by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf<MediaKind?>(null) }
    var recent by remember { mutableStateOf(searchPrefs.getStringSet("recent", emptySet()).orEmpty().toList()) }
    LaunchedEffect(input) { if (input.isBlank()) query = "" else { delay(250); query = input.trim() } }
    var results by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    LaunchedEffect(content, query, filter) {
        if (query.isBlank()) { results = emptyList(); searching = false }
        else {
            searching = true
            results = withContext(Dispatchers.Default) {
                content.asSequence().filter { filter == null || it.kind == filter }
                    .map { it to searchScore(it, query) }.filter { it.second > 0 }
                    .sortedWith(compareByDescending<Pair<Channel, Int>> { it.second }.thenBy { it.first.name })
                    .map { it.first }.take(200).toList()
            }
            searching = false
        }
    }
    val movies = remember(results) { results.filter { it.kind == MediaKind.MOVIE } }
    val series = remember(results) { results.filter { it.kind == MediaKind.SERIES } }
    val live = remember(results) { results.filter { it.kind == MediaKind.LIVE } }
    val discoverMovies = remember(content) { content.filter { it.kind == MediaKind.MOVIE }.take(14) }
    val discoverSeries = remember(content) { content.filter { it.kind == MediaKind.SERIES }.take(14) }
    val discoverLive = remember(content) { content.filter { it.kind == MediaKind.LIVE }.take(14) }
    fun openResult(item: Channel) {
        if (query.isNotBlank()) {
            recent = (listOf(query) + recent.filterNot { it.equals(query, true) }).take(6)
            searchPrefs.edit().putStringSet("recent", LinkedHashSet(recent)).apply()
        }
        open(item)
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Text("Search AstraWave", fontSize = 34.sp, fontWeight = FontWeight.Black) }
        item {
            OutlinedTextField(input, { input = it }, label = { Text("Movies, series, channels, genres or years") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, trailingIcon = { if (input.isNotEmpty()) IconButton(onClick = { input = "" }) { Icon(Icons.Default.Close, "Clear search") } }, modifier = Modifier.fillMaxWidth())
        }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(filter == null, { filter = null }, { Text("All") }) }
            item { FilterChip(filter == MediaKind.LIVE, { filter = MediaKind.LIVE }, { Text("Live TV") }) }
            item { FilterChip(filter == MediaKind.MOVIE, { filter = MediaKind.MOVIE }, { Text("Movies") }) }
            item { FilterChip(filter == MediaKind.SERIES, { filter = MediaKind.SERIES }, { Text("Series") }) }
        } }
        if (query.isBlank()) {
            if (recent.isNotEmpty()) item { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Recent searches", fontWeight = FontWeight.Bold); LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(recent) { term -> AssistChip(onClick = { input = term }, label = { Text(term) }, leadingIcon = { Icon(Icons.Default.History, null) }) } } } }
            item { Text("Explore while you search", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            if (discoverMovies.isNotEmpty()) item { CinematicRail("Popular Movies", discoverMovies, open) }
            if (discoverSeries.isNotEmpty()) item { CinematicRail("Popular Series", discoverSeries, open) }
            if (discoverLive.isNotEmpty()) item { CinematicRail("Live Now", discoverLive, open, landscape = true) }
        } else if (searching) {
            item { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp); Text("  Searching your library…", color = Muted) } }
        } else if (results.isEmpty()) {
            item { EmptyState(Icons.Default.SearchOff, "No results for “$query”", "Try a shorter title, another genre, a year, or switch the content filter.") }
        } else {
            item { Text("${results.size}${if (results.size == 200) "+" else ""} results", color = Muted) }
            if (movies.isNotEmpty()) item { CinematicRail("Movies", movies.take(30), ::openResult) }
            if (series.isNotEmpty()) item { CinematicRail("Series", series.take(30), ::openResult) }
            if (live.isNotEmpty()) item { CinematicRail("Live TV", live.take(30), ::openResult, landscape = true) }
        }
    }
}

@Composable private fun ContentDetailsScreen(item: Channel, allContent: List<Channel>, episodes: List<Episode>, episodesLoading: Boolean, onBack: () -> Unit, open: (Channel) -> Unit, play: (Channel) -> Unit, toggleFavorite: (String) -> Unit, favorites: Set<String>) {
    val context = LocalContext.current
    val compact = LocalConfiguration.current.screenWidthDp < 600
    val playbackStore = remember(context) { PlaybackStore(context) }
    val itemProgress = remember(item.id) { playbackStore.progress(item.id) }
    val related = remember(item.id, allContent) { allContent.asSequence().filter { it.id != item.id && it.kind == item.kind && it.group == item.group }.take(18).toList() }
    val collectionKey = remember(item.name) { franchiseKey(item.name) }
    val collection = remember(item.id, collectionKey, allContent) { collectionKey?.let { key -> allContent.filter { it.id != item.id && it.kind == item.kind && franchiseKey(it.name) == key }.take(18) }.orEmpty() }
    val seasons = remember(episodes) { episodes.map { it.season }.distinct().sorted() }
    var selectedSeason by remember(item.id, seasons) { mutableStateOf(seasons.firstOrNull() ?: 1) }
    val selectedEpisodes = remember(episodes, selectedSeason) { episodes.filter { it.season == selectedSeason } }
    val firstEpisode = selectedEpisodes.firstOrNull() ?: episodes.firstOrNull()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(22.dp)) {
        item {
            Box(Modifier.fillMaxWidth().height(if (compact) 430.dp else 330.dp).background(Panel, RoundedCornerShape(12.dp))) {
                AsyncImage(model = item.backdrop ?: item.logo, contentDescription = item.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black.copy(alpha = .98f), Color.Black.copy(alpha = .72f), Color.Transparent))))
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Ink.copy(alpha = .94f)))))
                Column(Modifier.align(Alignment.BottomStart).widthIn(max = 720.dp).padding(if (compact) 20.dp else 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(item.name, fontSize = if (compact) 30.sp else 38.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(listOf(item.year, item.group, if (item.kind == MediaKind.MOVIE) "Movie" else "Series", item.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty(), "HD").filter { it.isNotBlank() }.joinToString("  •  "), color = Color.White.copy(alpha = .8f))
                    if (collection.isNotEmpty() && collectionKey != null) Text("PART OF THE ${collectionKey.uppercase()} COLLECTION", color = Mint, fontWeight = FontWeight.Bold)
                    val playButton: @Composable () -> Unit = { Button(onClick = { if (item.kind == MediaKind.SERIES) firstEpisode?.let { play(it.asChannel()) } else if (item.streamUrl.isNotBlank()) play(item) }, enabled = if (item.kind == MediaKind.SERIES) firstEpisode != null else item.streamUrl.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black), modifier = if (compact) Modifier.fillMaxWidth() else Modifier) { Icon(Icons.Default.PlayArrow, null); Text(if (item.kind == MediaKind.SERIES) " Play episode 1" else if (itemProgress.positionMs > 30_000 && !itemProgress.watched) " Resume" else " Play", fontWeight = FontWeight.Bold) } }
                    val listButton: @Composable () -> Unit = { OutlinedButton(onClick = { toggleFavorite(item.id) }, modifier = if (compact) Modifier.fillMaxWidth() else Modifier) { Icon(if (item.id in favorites) Icons.Default.Check else Icons.Default.Add, null); Text(if (item.id in favorites) " My List" else " Add to My List") } }
                    if (compact) Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { playButton(); listButton() } else Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { playButton(); listButton() }
                }
                FilledTonalButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(14.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color.Black.copy(alpha = .72f), contentColor = Color.White)) { Icon(Icons.Default.ArrowBack, "Back"); Text(" Back") }
            }
        }
        item { Text(item.plot.ifBlank { "Available from your connected provider. Playback source and metadata remain tied to the service you authorized." }, color = Muted, fontSize = 16.sp) }
        if (item.kind == MediaKind.SERIES) {
            if (episodesLoading) item { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp); Text("  Loading seasons and episodes…", color = Muted) } }
            else if (episodes.isEmpty()) item { Text("No episodes were returned by the provider.", color = Muted) }
            else {
                item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(seasons) { season -> FilterChip(selectedSeason == season, { selectedSeason = season }, { Text("Season $season") }) } } }
                item { Text("${selectedEpisodes.size} episodes", color = Muted) }
                items(selectedEpisodes, key = { "episode-${it.id}" }) { episode ->
                    val episodeProgress = playbackStore.progress("episode-${episode.id}")
                    FocusCard(Modifier.fillMaxWidth().height(112.dp), onClick = { play(episode.asChannel()) }) {
                        Row(Modifier.fillMaxSize().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(model = episode.artwork ?: item.logo, contentDescription = episode.title, contentScale = ContentScale.Crop, modifier = Modifier.width(if (compact) 96.dp else 150.dp).fillMaxHeight().background(Panel, RoundedCornerShape(6.dp)))
                            Column(Modifier.padding(horizontal = 14.dp).weight(1f)) { Text("${episode.number}. ${episode.title}", fontWeight = FontWeight.Bold, maxLines = 1); Text(listOf(episode.duration, episode.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty()).filter { it.isNotBlank() }.joinToString(" • "), color = Muted, fontSize = 12.sp); Text(episode.plot, color = Muted, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                            if (episodeProgress.watched) Icon(Icons.Default.CheckCircle, "Watched", tint = Color(0xFF46D369)) else Icon(Icons.Default.PlayArrow, "Play episode")
                        }
                        if (episodeProgress.fraction > 0f && !episodeProgress.watched) LinearProgressIndicator(progress = { episodeProgress.fraction }, color = Mint, trackColor = Color.White.copy(alpha = .2f), modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(4.dp))
                    }
                }
            }
        }
        if (collection.isNotEmpty() && collectionKey != null) item { CinematicRail("$collectionKey Collection", collection, open) }
        if (related.isNotEmpty()) item { CinematicRail("More Like This", related.reversed(), open) }
    }
}

@Composable private fun LoginScreen(loading: Boolean, error: String?, clearError: () -> Unit, connect: (Profile) -> Unit) {
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    var mode by remember { mutableStateOf(SourceType.XTREAM) }
    var name by remember { mutableStateOf("My TV") }
    var server by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var epgUrl by remember { mutableStateOf("") }
    val trimmedServer = server.trim().replace('–', '-').replace('—', '-').replace('−', '-').trimEnd('/')
    val validServer = trimmedServer.startsWith("http://", true) || trimmedServer.startsWith("https://", true)
    val credentialsReady = mode == SourceType.M3U || (username.isNotBlank() && password.isNotBlank())
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ASTRAWAVE", color = Mint, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                Text("Connect your TV service", fontSize = 32.sp, fontWeight = FontWeight.Black)
            }
            Text(BuildConfig.VERSION_NAME, color = Muted, fontSize = 11.sp, modifier = Modifier.background(Panel, RoundedCornerShape(20.dp)).padding(horizontal = 10.dp, vertical = 6.dp))
        }
        Text("Add an Xtream Codes account or M3U playlist you are authorized to use. AstraWave supplies no channels or media.", color = Muted)
        Surface(color = Color(0xFF171717), shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF343434))) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, null, tint = Mint)
                Column(Modifier.padding(start = 12.dp)) {
                    Text("Your provider details stay on this device", fontWeight = FontWeight.Bold)
                    Text("Nothing is shared with AstraWave.", color = Muted, fontSize = 12.sp)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(mode == SourceType.XTREAM, { mode = SourceType.XTREAM }, { Text("Xtream Codes") })
            FilterChip(mode == SourceType.M3U, { mode = SourceType.M3U }, { Text("M3U URL") })
        }
        TvField(name, { name = it }, "Profile name")
        TvField(server, { server = it; clearError() }, if (mode == SourceType.XTREAM) "Server URL" else "M3U playlist URL")
        if (server.startsWith("http://", true)) Text("Warning: this provider uses unencrypted HTTP. Your login and streams may be visible on the network.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        if (mode == SourceType.XTREAM) {
            TvField(username, { username = it; clearError() }, "Username")
            TvField(password, { password = it; clearError() }, "Password", password = true)
        }
        if (mode == SourceType.M3U) TvField(epgUrl, { epgUrl = it }, "XMLTV guide URL (optional)")
        error?.let { message ->
            Row(Modifier.fillMaxWidth().background(Color(0xFF3A1114), RoundedCornerShape(10.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ErrorOutline, null, tint = Color(0xFFFFB4AB))
                Text(message, color = Color(0xFFFFDAD6), modifier = Modifier.padding(horizontal = 10.dp).weight(1f))
                IconButton(onClick = clearError) { Icon(Icons.Default.Close, "Dismiss error") }
            }
        }
        Button(
            onClick = {
                clearError()
                focusManager.clearFocus(force = true)
                keyboardController?.hide()
                connect(Profile("profile-${("$trimmedServer|$username").lowercase().hashCode()}", name.trim().ifBlank { "My TV" }, mode, trimmedServer, username.trim(), password, epgUrl.trim()))
            },
            enabled = validServer && credentialsReady && !loading,
            modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)
        ) {
            if (loading) { CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp); Spacer(Modifier.width(10.dp)); Text("Connecting…") }
            else { Icon(Icons.Default.Login, null); Spacer(Modifier.width(8.dp)); Text("Connect and load library") }
        }
        if (!validServer && server.isNotBlank()) Text("Enter the full address beginning with http:// or https://", color = Color(0xFFFFB4AB), fontSize = 12.sp)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable private fun TvField(value: String, onChange: (String) -> Unit, label: String, password: Boolean = false) {
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None, modifier = Modifier.fillMaxWidth())
}

@Composable private fun SectionHeader(title: String, subtitle: String, onBack: () -> Unit) {
    val compact = LocalConfiguration.current.screenWidthDp < 600
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        FilledTonalIconButton(onClick = onBack, modifier = Modifier.size(48.dp)) { Icon(Icons.Default.ArrowBack, "Back") }
        Column(Modifier.padding(start = 14.dp).weight(1f)) {
            Text(title, fontSize = if (compact) 28.sp else 34.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable private fun EmptyState(icon: ImageVector, title: String, message: String) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, null, tint = Mint, modifier = Modifier.size(42.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(message, color = Muted, modifier = Modifier.widthIn(max = 520.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable private fun HomeScreen(channels: List<Channel>, favorites: Set<String>, profileName: String, play: (Channel) -> Unit, refresh: () -> Unit, navigate: (Destination) -> Unit) {
    val context = LocalContext.current
    val playbackStore = remember(context) { PlaybackStore(context) }
    val movies = remember(channels) { channels.filter { it.kind == MediaKind.MOVIE } }
    val series = remember(channels) { channels.filter { it.kind == MediaKind.SERIES } }
    val live = remember(channels) { channels.filter { it.kind == MediaKind.LIVE } }
    val activePlaybackIds = remember(channels) { playbackStore.activeIds() }
    val continuing = remember(channels, activePlaybackIds) { channels.asSequence().filter { it.kind != MediaKind.LIVE && it.id in activePlaybackIds }.take(14).toList() }
    val recentLiveIds = remember(channels) { playbackStore.recentLiveIds() }
    val recentLive = remember(live, recentLiveIds) { recentLiveIds.mapNotNull { id -> live.firstOrNull { it.id == id } }.take(14) }
    val myList = remember(channels, favorites) { favorites.mapNotNull { id -> channels.firstOrNull { it.id == id } }.take(20) }
    val topMovies = remember(movies) { movies.sortedByDescending { it.rating.toDoubleOrNull() ?: 0.0 }.take(10) }
    val topSeries = remember(series) { series.sortedByDescending { it.rating.toDoubleOrNull() ?: 0.0 }.take(10) }
    val featured = remember(movies, series, live) { (movies + series).maxByOrNull { it.rating.toDoubleOrNull() ?: 0.0 } ?: live.firstOrNull() }
    val homeGenres = remember(movies) { movies.map { it.group }.filter { it.isNotBlank() && !it.equals("Other", true) }.distinct().take(4).associateWith { genre -> movies.filter { it.group == genre }.take(14) } }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(24.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Welcome back", color = Muted, fontSize = 13.sp); Text(profileName.ifBlank { "AstraWave" }, fontSize = 24.sp, fontWeight = FontWeight.Black); Text("Choose what you want to watch", color = Muted, fontSize = 13.sp) }; FilledTonalIconButton(onClick = refresh, modifier = Modifier.size(48.dp)) { Icon(Icons.Default.Refresh, "Refresh provider") } } }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LibraryShortcut("Live TV", live.size, Icons.Default.LiveTv, Modifier.weight(1f)) { navigate(Destination.LIVE) }
                LibraryShortcut("Movies", movies.size, Icons.Default.Movie, Modifier.weight(1f)) { navigate(Destination.MOVIES) }
                LibraryShortcut("Series", series.size, Icons.Default.Tv, Modifier.weight(1f)) { navigate(Destination.SERIES) }
            }
        }
        if (channels.isEmpty()) item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.CloudOff, null, tint = Mint, modifier = Modifier.size(44.dp))
                Text("No provider content loaded", fontSize = 21.sp, fontWeight = FontWeight.Black)
                Text("Your login was accepted, but no Live TV, movies, or series were returned. Refresh once, then check the provider details in Settings.", color = Muted, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Button(onClick = refresh, modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)) { Icon(Icons.Default.Refresh, null); Text(" Refresh provider") }
                OutlinedButton(onClick = { navigate(Destination.SETTINGS) }, modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)) { Icon(Icons.Default.Settings, null); Text(" Provider settings") }
            }
        } else item { HeroCard(featured, play) }
        if (myList.isNotEmpty()) item { CinematicRail("My List", myList, play, landscape = myList.all { it.kind == MediaKind.LIVE }) }
        if (continuing.isNotEmpty()) item { CinematicRail("Continue Watching", continuing, play, showProgress = true) }
        if (recentLive.isNotEmpty()) item { CinematicRail("Recent Channels", recentLive, play, landscape = true) }
        if (topMovies.isNotEmpty()) item { CinematicRail("Top 10 Movies", topMovies, play, ranked = true) }
        if (topSeries.isNotEmpty()) item { CinematicRail("Top 10 Series", topSeries, play, ranked = true) }
        if (live.isNotEmpty()) item { CinematicRail("Live Now", live.take(14), play, landscape = true) }
        homeGenres.forEach { (genre, titles) -> if (titles.isNotEmpty()) item(key = "home-$genre") { CinematicRail(genre, titles, play) } }
        if (movies.isNotEmpty()) item { CinematicRail("Recently Added Movies", movies.takeLast(14).reversed(), play) }
    }
}

@Composable private fun LibraryShortcut(label: String, count: Int, icon: ImageVector, modifier: Modifier = Modifier, open: () -> Unit) {
    Surface(
        color = Color(0xFF1B1B1B),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .09f)),
        modifier = modifier.height(96.dp).clickable(onClick = open)
    ) {
        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, label, tint = Mint, modifier = Modifier.size(26.dp))
            Column {
                Text(count.toString(), fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text(label, color = Muted, fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}

@Composable private fun HeroCard(channel: Channel?, play: (Channel) -> Unit) {
    val compact = LocalConfiguration.current.screenWidthDp < 600
    Box(Modifier.fillMaxWidth().height(if (compact) 280.dp else 340.dp).clip(RoundedCornerShape(12.dp)).background(Panel)) {
        (channel?.backdrop ?: channel?.logo)?.let { artwork -> AsyncImage(model = artwork, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black.copy(alpha = .96f), Color.Black.copy(alpha = .68f), Color.Transparent))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Ink.copy(alpha = .92f)))))
        Column(Modifier.align(Alignment.CenterStart).widthIn(max = 600.dp).padding(if (compact) 22.dp else 36.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("ASTRAWAVE FEATURED", color = Mint, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text(channel?.name ?: "Your entertainment. All in one place.", fontSize = if (compact) 29.sp else 38.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(channel?.plot?.takeIf { it.isNotBlank() } ?: channel?.group ?: "Live TV, movies, series and a beautiful guide built around your authorized services.", color = Color.White.copy(alpha = .82f), fontSize = if (compact) 14.sp else 17.sp, maxLines = if (compact) 2 else 3, overflow = TextOverflow.Ellipsis)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                channel?.let { Button(onClick = { play(it) }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Icon(if (it.kind == MediaKind.LIVE) Icons.Default.PlayArrow else Icons.Default.Info, null); Text(if (it.kind == MediaKind.LIVE) " Watch" else " View details", fontWeight = FontWeight.Bold) } }
            }
        }
    }
}

@Composable private fun CinematicRail(title: String, content: List<Channel>, play: (Channel) -> Unit, showProgress: Boolean = false, landscape: Boolean = false, ranked: Boolean = false, subtitle: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        subtitle?.let { Text(it, color = Muted, fontSize = 12.sp) }
        if (content.isEmpty()) Text("Nothing here yet", color = Muted)
        else LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(horizontal = 2.dp)) { items(content.size, key = { "${title}-${content[it].id}" }) { index -> PosterCard(content[index], play, showProgress, landscape, if (ranked) index + 1 else null) } }
    }
}

@Composable private fun PosterCard(channel: Channel, play: (Channel) -> Unit, showProgress: Boolean = false, landscape: Boolean = false, rank: Int? = null) {
    val context = LocalContext.current
    val playback = remember(context, channel.id, showProgress) { if (showProgress) PlaybackStore(context).progress(channel.id) else null }
    val width = if (landscape) 240.dp else 150.dp
    val height = if (landscape) 135.dp else 222.dp
    FocusCard(Modifier.width(width).height(height).clip(RoundedCornerShape(10.dp)), onClick = { play(channel) }) {
        if (channel.logo.isNullOrBlank()) Icon(if (channel.kind == MediaKind.LIVE) Icons.Default.LiveTv else Icons.Default.Movie, null, tint = Muted, modifier = Modifier.align(Alignment.Center).size(48.dp))
        else AsyncImage(model = channel.logo, contentDescription = channel.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, Color.Black.copy(alpha = .94f)))))
        Text(rank?.let { "#$it" } ?: if (channel.kind == MediaKind.LIVE) "LIVE" else if (channel.kind == MediaKind.SERIES) "SERIES" else "MOVIE", color = Color.White, fontSize = if (rank != null) 16.sp else 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.TopStart).padding(8.dp).background(if (channel.kind == MediaKind.LIVE && rank == null) Mint else Color.Black.copy(alpha = .78f), RoundedCornerShape(4.dp)).padding(horizontal = 7.dp, vertical = 4.dp))
        channel.rating.takeIf { it.isNotBlank() }?.let { Text("★ $it", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).background(Color.Black.copy(alpha = .72f), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 3.dp)) }
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(10.dp)) {
            Text(channel.name, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(channel.group, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (playback != null && playback.fraction > 0f) { Spacer(Modifier.height(6.dp)); LinearProgressIndicator(progress = { playback.fraction }, color = Mint, trackColor = Color.White.copy(alpha = .25f), modifier = Modifier.fillMaxWidth().height(3.dp)) }
        }
    }
}

@Composable private fun ChannelBrowser(channels: List<Channel>, programs: List<Program>, guideLoading: Boolean, favorites: Set<String>, toggleFavorite: (String) -> Unit, play: (Channel) -> Unit, onBack: () -> Unit) {
    val compact = LocalConfiguration.current.screenWidthDp < 700
    var input by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf<String?>(null) }
    var selectedId by remember(channels) { mutableStateOf(channels.firstOrNull()?.id) }
    LaunchedEffect(input) { if (input.isBlank()) query = "" else { delay(220); query = input.trim() } }
    val groups = remember(channels) { channels.map { it.group }.filter { it.isNotBlank() }.distinct().take(40) }
    val shown = remember(channels, group, query, favorites) { channels.filter { (group == null || group == "__favorites" || it.group == group) && (query.isBlank() || it.name.contains(query, true) || it.group.contains(query, true)) && (group != "__favorites" || it.id in favorites) } }
    val programsByChannel = remember(programs) { programs.groupBy { it.channelId } }
    val nowMillis = System.currentTimeMillis()
    val selected = shown.firstOrNull { it.id == selectedId } ?: shown.firstOrNull() ?: channels.firstOrNull()
    val selectedSchedule = selected?.let { scheduleFor(it, programsByChannel) }.orEmpty()
    val current = selectedSchedule.firstOrNull { nowMillis in it.startMillis until it.endMillis }
    val next = selectedSchedule.firstOrNull { it.startMillis >= (current?.endMillis ?: nowMillis) }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionHeader("Live TV", "${channels.size} channels from your connected provider", onBack)
        OutlinedTextField(input, { input = it }, label = { Text("Search channels and categories") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, trailingIcon = { if (input.isNotEmpty()) IconButton(onClick = { input = "" }) { Icon(Icons.Default.Close, "Clear search") } }, modifier = Modifier.fillMaxWidth())
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(group == null, { group = null }, { Text("All") }) }
            item { FilterChip(group == "__favorites", { group = "__favorites" }, { Text("Favorites") }) }
            items(groups) { item -> FilterChip(group == item, { group = item }, { Text(item) }) }
        }
        if (guideLoading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Mint)
        if (shown.isEmpty()) EmptyState(Icons.Default.LiveTv, "No channels found", "Try another category, clear the search, or check the connected provider profile.")
        else if (compact) {
            selected?.let { LivePreviewCard(it, current, next, it.id in favorites, toggleFavorite, play, Modifier.fillMaxWidth().height(190.dp)) }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                items(shown, key = { it.id }) { channel -> ChannelRow(channel, scheduleFor(channel, programsByChannel).firstOrNull { nowMillis in it.startMillis until it.endMillis }, channel.id in favorites, toggleFavorite, play) { selectedId = channel.id } }
            }
        } else {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                LazyColumn(Modifier.weight(.48f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                    items(shown, key = { it.id }) { channel -> ChannelRow(channel, scheduleFor(channel, programsByChannel).firstOrNull { nowMillis in it.startMillis until it.endMillis }, channel.id in favorites, toggleFavorite, play) { selectedId = channel.id } }
                }
                selected?.let { LivePreviewCard(it, current, next, it.id in favorites, toggleFavorite, play, Modifier.weight(.52f).fillMaxHeight()) }
            }
        }
    }
}

@Composable private fun ChannelRow(channel: Channel, current: Program?, favorite: Boolean, toggleFavorite: (String) -> Unit, play: (Channel) -> Unit, onFocused: () -> Unit = {}) {
    FocusCard(Modifier.fillMaxWidth().height(82.dp).clip(RoundedCornerShape(10.dp)), onClick = { play(channel) }, onFocused = onFocused) {
        Row(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF242424)), contentAlignment = Alignment.Center) {
                if (channel.logo.isNullOrBlank()) Icon(Icons.Default.LiveTv, null, tint = Mint)
                else AsyncImage(channel.logo, channel.name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(4.dp))
            }
            Column(Modifier.padding(start = 14.dp).weight(1f)) { Text(channel.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(current?.title ?: channel.group, color = if (current != null) Color.White.copy(alpha = .72f) else Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            Text("LIVE", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.background(Mint, RoundedCornerShape(4.dp)).padding(horizontal = 7.dp, vertical = 4.dp))
            IconButton(onClick = { toggleFavorite(channel.id) }) { Icon(if (favorite) Icons.Default.Star else Icons.Default.StarBorder, "Favorite", tint = if (favorite) Mint else Muted) }
            Icon(Icons.Default.PlayArrow, null)
        }
    }
}

@Composable private fun LivePreviewCard(channel: Channel, current: Program?, next: Program?, favorite: Boolean, toggleFavorite: (String) -> Unit, play: (Channel) -> Unit, modifier: Modifier) {
    val compact = LocalConfiguration.current.screenWidthDp < 700
    val timeFormat = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    Box(modifier.clip(RoundedCornerShape(12.dp)).background(Panel)) {
        channel.logo?.let { AsyncImage(it, channel.name, contentScale = ContentScale.Fit, modifier = Modifier.align(Alignment.Center).fillMaxSize().padding(42.dp)) }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .10f), Color.Black.copy(alpha = .92f)))))
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(if (compact) 14.dp else 20.dp), verticalArrangement = Arrangement.spacedBy(if (compact) 4.dp else 7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("LIVE", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.background(Mint, RoundedCornerShape(4.dp)).padding(horizontal = 7.dp, vertical = 4.dp)); Text(channel.group, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp)) }
            Text(channel.name, fontSize = if (compact) 20.sp else 24.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(current?.title ?: "Live programming", fontSize = if (compact) 14.sp else 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            current?.let { Text("${timeFormat.format(Date(it.startMillis))}–${timeFormat.format(Date(it.endMillis))}", color = Muted, fontSize = 12.sp) }
            if (!compact) next?.let { Text("Up next: ${it.title}", color = Color.White.copy(alpha = .72f), fontSize = 12.sp, maxLines = 1) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Button(onClick = { play(channel) }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Icon(Icons.Default.PlayArrow, null); Text(" Watch") }; OutlinedButton(onClick = { toggleFavorite(channel.id) }) { Icon(if (favorite) Icons.Default.Star else Icons.Default.StarBorder, null); Text(if (favorite) " Favorite" else " Add favorite") } }
        }
    }
}

@Composable private fun ChannelCard(channel: Channel, play: (Channel) -> Unit) {
    PosterCard(channel, play, landscape = channel.kind == MediaKind.LIVE)
}

@Composable private fun GuideScreen(channels: List<Channel>, programs: List<Program>, guideLoading: Boolean, favorites: Set<String>, toggleFavorite: (String) -> Unit, play: (Channel) -> Unit, playCatchup: (Channel, Program) -> Unit, onBack: () -> Unit) {
    val compact = LocalConfiguration.current.screenWidthDp < 700
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf<String?>(null) }
    var favoritesOnly by remember { mutableStateOf(false) }
    var catchupOnly by remember { mutableStateOf(false) }
    val nowMillis = System.currentTimeMillis()
    val timeFormat = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    val programsByChannel = remember(programs) { programs.groupBy { it.channelId } }
    val groups = remember(channels) { channels.map { it.group }.filter { it.isNotBlank() && !it.equals("Other", true) }.distinct().take(18) }
    val shown = remember(channels, programsByChannel, favorites, favoritesOnly, catchupOnly, query, group) {
        channels.filter { channel ->
            val schedule = scheduleFor(channel, programsByChannel)
            (group == null || channel.group == group) && (!favoritesOnly || channel.id in favorites) && (!catchupOnly || channel.catchupDays > 0) &&
                (query.isBlank() || channel.name.contains(query, true) || schedule.any { it.title.contains(query, true) })
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionHeader("TV Guide", "Now, next and catch-up from your provider", onBack)
        TvField(query, { query = it }, "Search channels and programs")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(group == null, { group = null }, { Text("All channels") }) }
            items(groups, key = { "guide-group-$it" }) { item -> FilterChip(group == item, { group = item }, { Text(item) }) }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { item { FilterChip(favoritesOnly, { favoritesOnly = !favoritesOnly }, { Text("★ Favorites") }) }; item { FilterChip(catchupOnly, { catchupOnly = !catchupOnly }, { Text("↶ Catch-up") }) }; item { AssistChip(onClick = { query = ""; group = null; favoritesOnly = false; catchupOnly = false; scope.launch { listState.animateScrollToItem(0) } }, label = { Text("Jump to now") }, leadingIcon = { Icon(Icons.Default.Schedule, null) }) } }
        if (guideLoading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Mint)
        if (!compact) Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) { Text("CHANNEL", color = Muted, modifier = Modifier.width(250.dp)); Text(if (catchupOnly) "LATEST REPLAY" else "NOW", color = Mint, modifier = Modifier.weight(1f)); Text(if (catchupOnly) "EARLIER" else "NEXT", color = Muted, modifier = Modifier.weight(.65f)) }
        if (!guideLoading && shown.isEmpty()) EmptyState(Icons.Default.EventBusy, "No guide results", "Try clearing the filters or confirm that your provider supplied XMLTV guide data.")
        LazyColumn(Modifier.weight(1f), state = listState, contentPadding = PaddingValues(bottom = 18.dp)) { items(shown, key = { it.id }) { channel ->
            val schedule = scheduleFor(channel, programsByChannel)
            val now = schedule.firstOrNull { nowMillis in it.startMillis until it.endMillis }
            val next = schedule.firstOrNull { it.startMillis >= (now?.endMillis ?: nowMillis) }
            val archiveCutoff = nowMillis - channel.catchupDays * 86_400_000L
            val archived = if (channel.catchupDays > 0) schedule.filter { it.endMillis < nowMillis && it.startMillis >= archiveCutoff }.sortedByDescending { it.startMillis } else emptyList()
            val primary = if (catchupOnly) archived.getOrNull(0) else now
            val secondary = if (catchupOnly) archived.getOrNull(1) else next
            if (compact) CompactGuideRow(channel, primary, secondary, now, nowMillis, catchupOnly, channel.id in favorites, timeFormat, toggleFavorite, play, playCatchup)
            else Row(Modifier.fillMaxWidth().height(88.dp)) {
                    FocusCard(Modifier.width(250.dp).fillMaxHeight().padding(4.dp), onClick = { play(channel) }) { Row(Modifier.fillMaxSize().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { toggleFavorite(channel.id) }) { Icon(if (channel.id in favorites) Icons.Default.Star else Icons.Default.StarBorder, null, tint = if (channel.id in favorites) Mint else Muted) }; Text(channel.name, maxLines = 2, fontWeight = FontWeight.Bold) } }
                    FocusCard(Modifier.weight(1f).fillMaxHeight().padding(4.dp), onClick = { if (catchupOnly && primary != null) playCatchup(channel, primary) else play(channel) }) { Column(Modifier.padding(12.dp)) { Text(primary?.title ?: if (catchupOnly) "No replay available" else "No guide information", fontWeight = FontWeight.Bold, maxLines = 1); Text(primary?.let { "${timeFormat.format(Date(it.startMillis))}–${timeFormat.format(Date(it.endMillis))}" } ?: if (catchupOnly) "Archive unavailable" else "Live", color = Muted, fontSize = 12.sp); if (!catchupOnly && now != null) LinearProgressIndicator(progress = { ((nowMillis - now.startMillis).toFloat() / (now.endMillis - now.startMillis)).coerceIn(0f, 1f) }, color = Mint, trackColor = Color.White.copy(alpha = .18f), modifier = Modifier.fillMaxWidth().padding(top = 5.dp).height(3.dp)) } }
                    FocusCard(Modifier.weight(.65f).fillMaxHeight().padding(4.dp), onClick = { if (catchupOnly && secondary != null) playCatchup(channel, secondary) }) { Column(Modifier.padding(12.dp)) { Text(secondary?.title ?: if (catchupOnly) "No earlier replay" else "No upcoming program", maxLines = 1); secondary?.let { Text(timeFormat.format(Date(it.startMillis)), color = Muted, fontSize = 12.sp) } } }
                }
        } }
    }
}

@Composable private fun CompactGuideRow(channel: Channel, primary: Program?, secondary: Program?, now: Program?, nowMillis: Long, catchupOnly: Boolean, favorite: Boolean, timeFormat: SimpleDateFormat, toggleFavorite: (String) -> Unit, play: (Channel) -> Unit, playCatchup: (Channel, Program) -> Unit) {
    FocusCard(Modifier.fillMaxWidth().height(132.dp).padding(vertical = 4.dp), onClick = { if (catchupOnly && primary != null) playCatchup(channel, primary) else play(channel) }) {
        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(34.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF242424)), contentAlignment = Alignment.Center) { if (channel.logo.isNullOrBlank()) Icon(Icons.Default.LiveTv, null, tint = Mint, modifier = Modifier.size(20.dp)) else AsyncImage(channel.logo, channel.name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(3.dp)) }
                Text(channel.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 10.dp).weight(1f))
                IconButton(onClick = { toggleFavorite(channel.id) }, modifier = Modifier.size(34.dp)) { Icon(if (favorite) Icons.Default.Star else Icons.Default.StarBorder, "Favorite", tint = if (favorite) Mint else Muted) }
            }
            Text(primary?.title ?: if (catchupOnly) "No replay available" else "No guide information", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row { Text(primary?.let { "${timeFormat.format(Date(it.startMillis))}–${timeFormat.format(Date(it.endMillis))}" } ?: "Live", color = Mint, fontSize = 11.sp); secondary?.let { Text("  •  Next: ${it.title}", color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) } }
            if (!catchupOnly && now != null) LinearProgressIndicator(progress = { ((nowMillis - now.startMillis).toFloat() / (now.endMillis - now.startMillis)).coerceIn(0f, 1f) }, color = Mint, trackColor = Color.White.copy(alpha = .18f), modifier = Modifier.fillMaxWidth().height(3.dp))
        }
    }
}

@Composable private fun EventsScreen(vm: MainViewModel, allowedChannels: List<Channel>) {
    val state by vm.state.collectAsState()
    LaunchedEffect(Unit) { vm.refreshSports() }
    var league by remember { mutableStateOf<String?>(null) }
    val leagues = remember(state.sportsEvents) { state.sportsEvents.map { it.league }.filter { it.isNotBlank() }.distinct().take(15) }
    val events = remember(state.sportsEvents, league) { state.sportsEvents.filter { league == null || it.league == league } }
    val eventMatches = remember(events, allowedChannels) { events.associateWith { vm.matches(it, allowedChannels).firstOrNull() } }
    val sportsChannels = remember(allowedChannels) {
        val markers = listOf("sports", "nfl", "nba", "mlb", "nhl", "espn", "football", "basketball", "baseball", "hockey", "soccer", "ufc", "ppv")
        allowedChannels.filter { channel -> "${channel.name} ${channel.group}".lowercase(Locale.US).let { text -> markers.any(text::contains) } }.take(40)
    }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Live Events", fontSize = 34.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f)); IconButton(onClick = { vm.refreshSports(true) }) { Icon(Icons.Default.Refresh, "Refresh scores") } }
        Text("Schedules and scores from TheSportsDB. Watch suggestions are matched only against channels in your connected playlist.", color = Muted)
        if (state.sportsLoading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Mint)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { item { FilterChip(league == null, { league = null }, { Text("All") }) }; items(leagues) { item -> FilterChip(league == item, { league = item }, { Text(item) }) } }
        if (!state.sportsLoading && events.isEmpty()) {
            Text("The schedule service returned no events. Your sports channels are still available below.", color = Muted)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                if (sportsChannels.isEmpty()) item { EmptyState(Icons.Default.SportsFootball, "No sports channels found", "Refresh your provider or check whether its sports category is enabled.") }
                items(sportsChannels, key = { "sports-channel-${it.id}" }) { channel ->
                    FocusCard(Modifier.fillMaxWidth().heightIn(min = 68.dp), onClick = { vm.play(channel) }) {
                        Row(Modifier.fillMaxSize().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.LiveTv, null, tint = Mint); Column(Modifier.padding(horizontal = 12.dp).weight(1f)) { Text(channel.name, fontWeight = FontWeight.Bold); Text(channel.group, color = Muted, fontSize = 12.sp) }; Icon(Icons.Default.PlayArrow, "Watch") }
                    }
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) { items(events, key = { it.id }) { event ->
                val match = eventMatches[event]
                FocusCard(Modifier.fillMaxWidth(), onClick = { match?.let { vm.play(it.channel) } }) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Text(event.league.ifBlank { "Live sports" }, color = Mint, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text(event.status, color = Muted) }
                        Text(event.title.ifBlank { "${event.away}  ${event.awayScore.ifBlank { "–" }}  •  ${event.homeScore.ifBlank { "–" }}  ${event.home}" }, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(match?.let { "Watch on ${it.channel.name} • ${it.score}% match${it.reasons.takeIf { r -> r.isNotEmpty() }?.joinToString(prefix = " • ").orEmpty()}" } ?: "No matching channel in your playlist", color = if (match != null) Color(0xFF46D369) else Muted)
                    }
                }
            } }
        }
    }
}

@Composable private fun PosterShelf(title: String, content: List<Channel>, play: (Channel) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val contentPreferences = remember(context) { ContentPreferences(context) }
    var includeWorld by remember { mutableStateOf(contentPreferences.includeWorld) }
    var input by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf<String?>(null) }
    var sort by remember { mutableStateOf(VodSort.FEATURED) }
    val listState = rememberLazyListState()
    val regionalContent = remember(content, includeWorld) { ContentDiscovery.usaFirst(content, includeWorld) }
    LaunchedEffect(input) { if (input.isBlank()) query = "" else { delay(250); query = input.trim() } }
    val genres = remember(regionalContent) { regionalContent.map { it.group }.filter { it.isNotBlank() && !it.equals("Other", true) }.distinct().take(20) }
    val filtered by produceState(regionalContent, regionalContent, query, genre, sort) {
        value = withContext(Dispatchers.Default) {
            val base = regionalContent.asSequence().filter { (genre == null || it.group == genre) && (query.isBlank() || searchScore(it, query) > 0) }.toList()
            when (sort) {
                VodSort.FEATURED -> base
                VodSort.NEWEST -> base.sortedWith(compareByDescending<Channel> { it.year.filter(Char::isDigit).take(4).toIntOrNull() ?: 0 }.thenBy { it.name })
                VodSort.RATING -> base.sortedByDescending { it.rating.toDoubleOrNull() ?: 0.0 }
                VodSort.AZ -> base.sortedBy { it.name.lowercase(Locale.getDefault()) }
            }
        }
    }
    val genreRows = remember(regionalContent) {
        regionalContent.asSequence().map { it.group }.filter { it.isNotBlank() && !it.equals("Other", true) }.distinct().take(10)
            .associateWith { genre -> regionalContent.asSequence().filter { it.group == genre }.take(14).toList() }
    }
    val curated = remember(regionalContent) { ContentDiscovery.shelves(regionalContent, if (title == "Movies") MediaKind.MOVIE else MediaKind.SERIES) }
    val browsing = query.isNotBlank() || genre != null || sort != VodSort.FEATURED
    LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { SectionHeader(title, "${regionalContent.size} of ${content.size} provider titles • ${if (includeWorld) "USA + world" else "USA first"}", onBack) }
        item {
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Include world content", fontWeight = FontWeight.Bold); Text("Off keeps clearly international categories out of Movies and Series", color = Muted, fontSize = 12.sp) }
                Switch(checked = includeWorld, onCheckedChange = { includeWorld = it; contentPreferences.includeWorld = it; genre = null })
            }
        }
        item {
            OutlinedTextField(input, { input = it }, label = { Text("Search $title, genres, years and descriptions") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, trailingIcon = { if (input.isNotEmpty()) IconButton(onClick = { input = "" }) { Icon(Icons.Default.Close, "Clear search") } }, modifier = Modifier.fillMaxWidth())
        }
        if (regionalContent.isNotEmpty()) item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(genre == null, { genre = null }, { Text("All genres") }) }
            items(genres, key = { "genre-filter-$it" }) { item -> FilterChip(genre == item, { genre = item }, { Text(item) }) }
        } }
        if (regionalContent.isNotEmpty()) item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(VodSort.entries) { item -> FilterChip(sort == item, { sort = item }, { Text(item.label) }) } } }
        if (regionalContent.isEmpty()) item { EmptyState(Icons.Default.VideoLibrary, "No $title available", "Your connected provider did not return any $title. Try refreshing or selecting another profile.") }
        else if (browsing && filtered.isEmpty()) item { EmptyState(Icons.Default.SearchOff, "Nothing matched", "Clear a filter or try a shorter title, different genre, or another year.") }
        else if (browsing) {
            item { Row(verticalAlignment = Alignment.CenterVertically) { Text("${filtered.size} titles", color = Muted, modifier = Modifier.weight(1f)); TextButton(onClick = { input = ""; query = ""; genre = null; sort = VodSort.FEATURED }) { Icon(Icons.Default.FilterAltOff, null); Text(" Clear filters") } } }
            items(filtered.take(150), key = { "vod-result-${it.id}" }) { item -> VodResultRow(item, play) }
            if (filtered.size > 150) item { Text("Showing the first 150 results. Refine your search to narrow the list.", color = Muted) }
        }
        else {
            curated.forEach { shelf -> item(key = "curated-${shelf.title}") { CinematicRail(shelf.title, shelf.items, play, subtitle = shelf.note) } }
            item { CinematicRail("Featured $title", regionalContent.take(14), play) }
            item { CinematicRail("Top 10 Today", regionalContent.reversed().take(10), play, ranked = true) }
            genreRows.forEach { (genre, titles) -> item(key = "genre-$genre") { CinematicRail(genre, titles, play) } }
            item { CinematicRail("Recently Added", regionalContent.takeLast(14).reversed(), play) }
        }
    }
}

@Composable private fun VodResultRow(item: Channel, open: (Channel) -> Unit) {
    FocusCard(Modifier.fillMaxWidth().height(116.dp).clip(RoundedCornerShape(10.dp)), onClick = { open(item) }) {
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(82.dp).fillMaxHeight().background(Color(0xFF242424)), contentAlignment = Alignment.Center) {
                if (item.logo.isNullOrBlank()) Icon(if (item.kind == MediaKind.SERIES) Icons.Default.Tv else Icons.Default.Movie, null, tint = Muted)
                else AsyncImage(item.logo, item.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp).weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(item.name, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(listOf(item.year, item.group, item.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty()).filter { it.isNotBlank() }.joinToString(" • "), color = Muted, fontSize = 12.sp, maxLines = 1)
                if (item.plot.isNotBlank()) Text(item.plot, color = Color.White.copy(alpha = .72f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.ChevronRight, "Open details", tint = Muted, modifier = Modifier.padding(end = 16.dp))
        }
    }
}

@Composable private fun DebridScreen(play: (Channel?) -> Unit) {
    val context = LocalContext.current
    val store = remember { SecureStore(context) }
    val resolver = remember { HttpDebridResolver() }
    val scope = rememberCoroutineScope()
    var provider by remember { mutableStateOf(DebridProvider.REAL_DEBRID) }
    var token by remember(provider) { mutableStateOf(store.debridToken(provider).orEmpty()) }
    var source by remember { mutableStateOf("") }
    var resolving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Debrid accounts", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Connect your own provider and resolve only links you are authorized to access. AstraWave does not search for or supply media.", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DebridProvider.entries.forEach { item -> FilterChip(provider == item, { provider = item; message = null }, { Text(item.name.replace('_', '-')) }) }
        }
        OutlinedTextField(token, { token = it }, label = { Text("${provider.name.replace('_', '-')} API token") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(enabled = token.isNotBlank(), onClick = { store.saveDebridToken(provider, token); message = "${provider.name.replace('_', '-')} connected securely" }) { Icon(Icons.Default.Lock, null); Text(" Save account") }
            if (store.debridToken(provider) != null) OutlinedButton(onClick = { store.clearDebrid(provider); token = ""; message = "Account disconnected" }) { Text("Disconnect") }
        }
        HorizontalDivider()
        TvField(source, { source = it }, "Authorized HTTP(S) media or hoster link")
        Button(enabled = !resolving && source.startsWith("http") && (store.debridToken(provider) != null || token.isNotBlank()), onClick = {
            if (token.isNotBlank()) store.saveDebridToken(provider, token)
            resolving = true; message = null
            scope.launch {
                runCatching { resolver.resolve(provider, source, store.debridToken(provider).orEmpty()) }
                    .onSuccess { media -> resolving = false; message = "Resolved securely"; play(Channel("debrid-${System.currentTimeMillis()}", media.filename.ifBlank { "Debrid stream" }, media.url, kind = MediaKind.MOVIE)) }
                    .onFailure { resolving = false; message = it.message }
            }
        }) { if (resolving) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.PlayArrow, null); Text(" Resolve and play") }
        message?.let { Text(it, color = if (it.contains("connected") || it.contains("Resolved")) Color(0xFF46D369) else Muted) }
    }
}

@Composable private fun ExtensionsScreen() {
    val context = LocalContext.current
    val store = remember { ExtensionStore(context) }
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(ExtensionKind.STREMIO) }
    var installed by remember { mutableStateOf(store.load()) }
    var reviewName by remember { mutableStateOf<String?>(null) }
    var reviewDetails by remember { mutableStateOf<String?>(null) }
    var reviewing by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("Extensions", fontSize = 34.sp, fontWeight = FontWeight.Black) }
        item { Text("Add a Stremio manifest or inspect a CloudStream-compatible repository you trust. AstraWave includes no extension sources.", color = Muted) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(kind == ExtensionKind.STREMIO, { kind = ExtensionKind.STREMIO; reviewName = null }, { Text("Stremio add-on") })
            FilterChip(kind == ExtensionKind.CLOUDSTREAM_REPOSITORY, { kind = ExtensionKind.CLOUDSTREAM_REPOSITORY; reviewName = null }, { Text("CloudStream repo") })
        } }
        item { TvField(url, { url = it }, if (kind == ExtensionKind.STREMIO) "HTTPS manifest URL or stremio:// URL" else "HTTPS repository JSON URL") }
        item { Button(onClick = {
            reviewing = true; error = null; reviewName = null
            scope.launch {
                runCatching {
                    if (kind == ExtensionKind.STREMIO) {
                        val manifest = StremioAddonClient().manifest(url)
                        manifest.name to "v${manifest.version} • ${manifest.types.joinToString()} • ${manifest.catalogs.size} catalogs • resources: ${manifest.resources.joinToString { it.name }}"
                    } else {
                        val plugins = CloudStreamRepositoryClient().discover(url)
                        "CloudStream repository" to "${plugins.size} plugin records found: ${plugins.take(6).joinToString { it.name }}"
                    }
                }.onSuccess { (name, details) -> reviewName = name; reviewDetails = details; reviewing = false }
                    .onFailure { error = it.message; reviewing = false }
            }
        }, enabled = url.isNotBlank() && !reviewing) { if (reviewing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.Security, null); Text(" Review source") } }
        reviewName?.let { name -> item {
            FocusCard(Modifier.fillMaxWidth().heightIn(min = 120.dp), onClick = {}) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(name, fontWeight = FontWeight.Black, fontSize = 20.sp)
                    Text(reviewDetails.orEmpty(), color = Muted)
                    Text("Host: ${runCatching { java.net.URI(url.replace("stremio://", "https://")).host }.getOrNull().orEmpty()}", color = Muted)
                    Button(onClick = {
                        val item = InstalledExtension("${kind.name}-${url.hashCode()}", name, url, kind, enabled = true, trusted = true)
                        installed = (installed.filterNot { it.id == item.id } + item); store.save(installed); reviewName = null; url = ""
                    }) { Icon(Icons.Default.Add, null); Text(" Install reviewed source") }
                }
            }
        } }
        error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
        item { HorizontalDivider(); Text("Installed sources", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
        if (installed.isEmpty()) item { Text("No extensions installed", color = Muted) }
        items(installed, key = { it.id }) { extension ->
            FocusCard(Modifier.fillMaxWidth().height(82.dp), onClick = {
                installed = installed.map { if (it.id == extension.id) it.copy(enabled = !it.enabled) else it }; store.save(installed)
            }) {
                Row(Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (extension.enabled) Icons.Default.ToggleOn else Icons.Default.ToggleOff, null, tint = if (extension.enabled) Color(0xFF46D369) else Muted)
                    Column(Modifier.padding(horizontal = 12.dp).weight(1f)) { Text(extension.name, fontWeight = FontWeight.Bold); Text("${extension.kind.name.replace('_', ' ')} • ${if (extension.enabled) "Enabled" else "Disabled"}", color = Muted, fontSize = 12.sp) }
                    TextButton(onClick = { installed = installed.filterNot { it.id == extension.id }; store.save(installed) }) { Text("Remove") }
                }
            }
        }
        item { Text("CloudStream repository metadata can be inspected and managed. Executable third-party plugin loading remains disabled until an audited sandbox runtime is available.", color = Muted, fontSize = 12.sp) }
    }
}

@Composable private fun SettingsScreen(profile: Profile, content: List<Channel>, switchProfile: (Profile) -> Unit, addProvider: () -> Unit, refresh: () -> Unit, deviceMode: DeviceMode, setDeviceMode: (DeviceMode) -> Unit, parental: ParentalControlStore, parentalUnlocked: Boolean, setParentalUnlocked: (Boolean) -> Unit, parentalChanged: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember(context) { PlaybackPreferences(context) }
    val secureStore = remember(context) { SecureStore(context) }
    var buffer by remember { mutableStateOf(prefs.bufferMode) }; var subtitles by remember { mutableStateOf(prefs.subtitlesEnabled) }; var autoplay by remember { mutableStateOf(prefs.autoplayNext) }
    var parentalEnabled by remember { mutableStateOf(parental.enabled) }; var keywords by remember { mutableStateOf(parental.blockedKeywords) }; var pin by remember { mutableStateOf("") }; var pinMessage by remember { mutableStateOf<String?>(null) }
    var savedProfiles by remember { mutableStateOf(secureStore.profiles()) }
    var deleteTarget by remember { mutableStateOf<Profile?>(null) }
    val libraryCounts = remember(content) { Triple(content.count { it.kind == MediaKind.LIVE }, content.count { it.kind == MediaKind.MOVIE }, content.count { it.kind == MediaKind.SERIES }) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Settings", fontSize = 34.sp, fontWeight = FontWeight.Black); Text("AstraWave ${BuildConfig.VERSION_NAME} • device, playback and account controls", color = Muted)
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(if (profile.type == SourceType.XTREAM) Icons.Default.Dns else Icons.Default.PlaylistPlay, null, tint = Mint, modifier = Modifier.size(34.dp)); Column(Modifier.padding(start = 14.dp).weight(1f)) { Text(profile.name, fontSize = 20.sp, fontWeight = FontWeight.Black); Text("${profile.type} • ${profile.server.substringBefore('?').take(48)}", color = Muted, fontSize = 12.sp) }; Text("ACTIVE", color = Color(0xFF46D369), fontSize = 11.sp, fontWeight = FontWeight.Black) }
            Text("${libraryCounts.first} live  •  ${libraryCounts.second} movies  •  ${libraryCounts.third} series", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Button(onClick = refresh) { Icon(Icons.Default.Refresh, null); Text(" Refresh") }; OutlinedButton(onClick = addProvider) { Icon(Icons.Default.Add, null); Text(" Add provider") } }
        }
        Text("Provider profiles", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        savedProfiles.forEach { saved -> Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(8.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if (saved.type == SourceType.XTREAM) Icons.Default.Dns else Icons.Default.PlaylistPlay, null, tint = if (saved.id == profile.id) Mint else Muted); Column(Modifier.padding(horizontal = 12.dp).weight(1f)) { Text(saved.name, fontWeight = FontWeight.Bold); Text(saved.server.substringBefore("?").take(45), color = Muted, fontSize = 12.sp) }; if (saved.id == profile.id) Text("Active", color = Color(0xFF46D369), fontSize = 12.sp) else { TextButton(onClick = { switchProfile(saved) }) { Text("Connect") }; TextButton(onClick = { deleteTarget = saved }) { Text("Remove") } } } }
        deleteTarget?.let { target -> AlertDialog(onDismissRequest = { deleteTarget = null }, title = { Text("Remove ${target.name}?") }, text = { Text("This removes the saved login from this device. It does not affect the provider account.") }, confirmButton = { TextButton(onClick = { secureStore.deleteProfile(target.id); savedProfiles = secureStore.profiles(); deleteTarget = null }) { Text("Remove") } }, dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }) }
        Text("Device layout", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { DeviceMode.entries.forEach { mode -> FilterChip(deviceMode == mode, { setDeviceMode(mode) }, { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }) } }
        Text("Playback buffer", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { BufferMode.entries.forEach { mode -> FilterChip(buffer == mode, { buffer = mode; prefs.bufferMode = mode }, { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }) } }
        Text("Fast is suited to responsive local networks; Large favors unstable connections and higher-bitrate streams.", color = Muted)
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(subtitles, { subtitles = it; prefs.subtitlesEnabled = it }); Text("  Enable subtitles by default") }
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(autoplay, { autoplay = it; prefs.autoplayNext = it }); Text("  Autoplay next VOD item") }
        HorizontalDivider(); Text("Parental controls", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(parentalEnabled, { parentalEnabled = it; parental.enabled = it; if (!it) setParentalUnlocked(false); parentalChanged() }); Text("  Hide restricted categories") }
        TvField(keywords, { keywords = it }, "Blocked words, separated by commas")
        OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(4) }, label = { Text("4-digit PIN") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(enabled = pin.length == 4, onClick = { secureStore.saveParentalPin(pin); parental.blockedKeywords = keywords; parental.enabled = true; parentalEnabled = true; setParentalUnlocked(false); parentalChanged(); pinMessage = "PIN and restrictions saved"; pin = "" }) { Icon(Icons.Default.Lock, null); Text(" Save PIN") }
            if (secureStore.hasParentalPin()) OutlinedButton(enabled = !parentalUnlocked && pin.length == 4, onClick = { val valid = secureStore.verifyParentalPin(pin); setParentalUnlocked(valid); pinMessage = if (valid) "Restricted content unlocked for this session" else "Incorrect PIN"; pin = "" }) { Icon(Icons.Default.LockOpen, null); Text(if (parentalUnlocked) "Unlocked" else "Unlock session") }
            if (parentalUnlocked) TextButton(onClick = { setParentalUnlocked(false); pinMessage = "Restricted content locked" }) { Text("Lock now") }
        }
        pinMessage?.let { Text(it, color = if (it.contains("Incorrect")) MaterialTheme.colorScheme.error else Color(0xFF46D369)) }
    }
}

@Composable private fun PlayerScreen(channel: Channel, content: List<Channel>, switchChannel: (Channel?) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember { PlaybackStore(context) }
    val preferences = remember { PlaybackPreferences(context) }
    val buffer = preferences.bufferMode
    val liveChannels = content.filter { it.kind == MediaKind.LIVE }
    val similarVod = content.filter { it.kind == channel.kind && it.streamUrl.isNotBlank() }
    val resume = remember(channel.id) { if (channel.kind == MediaKind.LIVE) 0L else store.progress(channel.id).positionMs }
    var playbackError by remember(channel.id) { mutableStateOf<String?>(null) }
    var resizeMode by remember(channel.id) { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var speedMenu by remember { mutableStateOf(false) }
    var playbackSpeed by remember(channel.id) { mutableFloatStateOf(1f) }
    val streamCandidates = remember(channel.id, channel.streamUrl) { playbackCandidates(channel.streamUrl) }
    var streamCandidateIndex by remember(channel.id) { mutableIntStateOf(0) }
    val player = remember(channel.id, buffer) {
        val httpDataSource = DefaultHttpDataSource.Factory()
            .setUserAgent("AstraWaveTV/0.1 (Android)")
            .setAllowCrossProtocolRedirects(true)
        val exoPlayer = ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(httpDataSource))
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(buffer.minMs, buffer.maxMs, buffer.playbackMs, buffer.playbackMs * 2).build())
            .build()
        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !preferences.subtitlesEnabled).build()
        exoPlayer.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (streamCandidateIndex + 1 < streamCandidates.size) {
                    streamCandidateIndex++
                    playbackError = null
                    exoPlayer.setMediaItem(MediaItem.fromUri(streamCandidates[streamCandidateIndex]))
                    exoPlayer.prepare()
                    exoPlayer.playWhenReady = true
                } else playbackError = "${error.errorCodeName}. The provider stream did not respond in TS or HLS format."
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && preferences.autoplayNext && channel.kind != MediaKind.LIVE && similarVod.size > 1) {
                    val index = similarVod.indexOfFirst { it.id == channel.id }.coerceAtLeast(0)
                    switchChannel(similarVod[(index + 1) % similarVod.size])
                }
            }
        })
        streamCandidates.firstOrNull()?.let { exoPlayer.setMediaItem(MediaItem.fromUri(it)) }
        exoPlayer.prepare()
        if (resume > 0) exoPlayer.seekTo(resume)
        exoPlayer.playWhenReady = true
        exoPlayer
    }
    LaunchedEffect(player, channel.id) { while (true) { delay(5_000); if (channel.kind != MediaKind.LIVE) store.save(channel.id, player.currentPosition, player.duration) } }
    DisposableEffect(player) { onDispose { if (channel.kind != MediaKind.LIVE) store.save(channel.id, player.currentPosition, player.duration); player.release() } }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true; layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) } }, update = { it.resizeMode = resizeMode }, modifier = Modifier.fillMaxSize())
        Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).background(Color.Black.copy(alpha = .78f), RoundedCornerShape(26.dp)).padding(end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
                Column(Modifier.weight(1f)) {
                    Text(channel.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (channel.kind == MediaKind.LIVE) "LIVE TV" else if (channel.kind == MediaKind.CATCHUP) "CATCH-UP" else "VIDEO ON DEMAND", color = if (channel.kind == MediaKind.LIVE) Mint else Muted, fontSize = 10.sp, fontWeight = FontWeight.Black)
                }
            }
            Row(Modifier.padding(start = 8.dp).background(Color.Black.copy(alpha = .78f), RoundedCornerShape(24.dp)).padding(horizontal = 4.dp)) {
                IconButton(onClick = { TrackSelectionDialogBuilder(context, "Audio track", player, C.TRACK_TYPE_AUDIO).setShowDisableOption(false).build().show() }) { Icon(Icons.Default.VolumeUp, "Audio track") }
                IconButton(onClick = { TrackSelectionDialogBuilder(context, "Subtitles", player, C.TRACK_TYPE_TEXT).setShowDisableOption(true).build().show() }) { Icon(Icons.Default.Subtitles, "Subtitles") }
                IconButton(onClick = { resizeMode = if (resizeMode == AspectRatioFrameLayout.RESIZE_MODE_FIT) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT }) { Icon(Icons.Default.AspectRatio, "Fit or zoom video") }
                if (channel.kind != MediaKind.LIVE) Box {
                    IconButton(onClick = { speedMenu = true }) { Icon(Icons.Default.Speed, "Playback speed") }
                    DropdownMenu(expanded = speedMenu, onDismissRequest = { speedMenu = false }) { listOf(.5f, 1f, 1.25f, 1.5f, 2f).forEach { speed -> DropdownMenuItem(text = { Text(if (speed == 1f) "Normal" else "${speed}×") }, trailingIcon = { if (playbackSpeed == speed) Icon(Icons.Default.Check, null) }, onClick = { playbackSpeed = speed; player.setPlaybackSpeed(speed); speedMenu = false }) } }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) IconButton(onClick = { (context as? Activity)?.enterPictureInPictureMode(PictureInPictureParams.Builder().build()) }) { Icon(Icons.Default.PictureInPictureAlt, "Picture in picture") }
            }
        }
        if (channel.kind == MediaKind.LIVE && liveChannels.size > 1) {
            val index = liveChannels.indexOfFirst { it.id == channel.id }.coerceAtLeast(0)
            Row(Modifier.align(Alignment.BottomCenter).padding(28.dp).background(Color.Black.copy(alpha = .72f), RoundedCornerShape(30.dp)).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { switchChannel(liveChannels[(index - 1 + liveChannels.size) % liveChannels.size]) }) { Icon(Icons.Default.SkipPrevious, "Previous channel") }
                Text("Channel ${index + 1} of ${liveChannels.size}", modifier = Modifier.padding(horizontal = 18.dp))
                IconButton(onClick = { switchChannel(liveChannels[(index + 1) % liveChannels.size]) }) { Icon(Icons.Default.SkipNext, "Next channel") }
            }
        }
        playbackError?.let { error -> Row(Modifier.align(Alignment.Center).background(Color.Black.copy(alpha = .88f), RoundedCornerShape(12.dp)).padding(20.dp), verticalAlignment = Alignment.CenterVertically) { Text("Playback error: $error", color = Color.White); Button(onClick = { streamCandidateIndex = 0; playbackError = null; streamCandidates.firstOrNull()?.let { player.setMediaItem(MediaItem.fromUri(it)) }; player.prepare(); player.play() }, modifier = Modifier.padding(start = 14.dp)) { Icon(Icons.Default.Refresh, null); Text(" Retry") } } }
    }
}

@Composable private fun FocusCard(modifier: Modifier, onClick: () -> Unit, onFocused: () -> Unit = {}, content: @Composable BoxScope.() -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.015f else 1f, tween(90), label = "focus-scale")
    val surface by animateColorAsState(if (focused) Color(0xFF2B2B2B) else Panel, tween(90), label = "focus-color")
    Box(modifier.graphicsLayer { scaleX = scale; scaleY = scale }.onFocusChanged { state -> focused = state.isFocused; if (state.isFocused) onFocused() }.border(if (focused) 2.dp else 0.dp, if (focused) Color.White else Color.Transparent, RoundedCornerShape(8.dp)).background(surface, RoundedCornerShape(8.dp)).clickable(onClick = onClick).focusable(), content = content)
}
