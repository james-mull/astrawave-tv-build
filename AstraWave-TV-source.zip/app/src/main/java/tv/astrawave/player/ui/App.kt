package tv.astrawave.player.ui

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import tv.astrawave.player.MainViewModel
import tv.astrawave.player.model.*

enum class Destination(val label: String) { HOME("Home"), LIVE("Live TV"), GUIDE("Guide"), EVENTS("Live Events"), MOVIES("Movies"), SERIES("Series"), EXTENSIONS("Extensions"), DEBRID("Debrid"), SETTINGS("Settings") }

@Composable fun AstraWaveApp(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    var destination by remember { mutableStateOf(Destination.HOME) }
    if (state.playing != null) {
        PlayerScreen(state.playing!!, onBack = { vm.play(null) })
        return
    }
    Row(Modifier.fillMaxSize().background(Ink)) {
        NavigationRail(containerColor = Color(0xFF09171D), modifier = Modifier.width(190.dp)) {
            Spacer(Modifier.height(24.dp))
            Text("ASTRAWAVE", color = Mint, fontWeight = FontWeight.Black, letterSpacing = 2.sp, modifier = Modifier.padding(12.dp))
            Destination.entries.forEach { item ->
                NavigationRailItem(
                    selected = destination == item,
                    onClick = { destination = item },
                    icon = { Icon(icon(item), null) },
                    label = { Text(item.label) },
                    alwaysShowLabel = true
                )
            }
        }
        Box(Modifier.fillMaxSize().padding(28.dp)) {
            when {
                state.profile == null -> LoginScreen(vm::connect)
                destination == Destination.HOME -> HomeScreen(state.channels, vm::play)
                destination == Destination.LIVE -> ChannelBrowser(state.channels, vm::play)
                destination == Destination.GUIDE -> GuideScreen(state.channels, vm::play)
                destination == Destination.EVENTS -> EventsScreen(vm)
                destination == Destination.MOVIES -> PosterShelf("Movies", state.channels.filter { it.kind == MediaKind.MOVIE }, vm::play)
                destination == Destination.SERIES -> PosterShelf("Series", state.channels.filter { it.kind == MediaKind.SERIES }, vm::play)
                destination == Destination.EXTENSIONS -> ExtensionsScreen()
                destination == Destination.DEBRID -> DebridScreen()
                else -> SettingsScreen(state.profile!!)
            }
            if (state.loading) CircularProgressIndicator(Modifier.align(Alignment.Center))
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.align(Alignment.BottomCenter)) }
        }
    }
}

private fun icon(d: Destination) = when(d) {
    Destination.HOME -> Icons.Default.Home; Destination.LIVE -> Icons.Default.LiveTv
    Destination.GUIDE -> Icons.Default.ViewTimeline; Destination.EVENTS -> Icons.Default.SportsFootball
    Destination.MOVIES -> Icons.Default.Movie; Destination.SERIES -> Icons.Default.Tv
    Destination.EXTENSIONS -> Icons.Default.Extension; Destination.DEBRID -> Icons.Default.Link; Destination.SETTINGS -> Icons.Default.Settings
}

@Composable private fun LoginScreen(connect: (Profile) -> Unit) {
    var mode by remember { mutableStateOf(SourceType.XTREAM) }
    var name by remember { mutableStateOf("My TV") }
    var server by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(Modifier.widthIn(max = 720.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Bring your own TV", fontSize = 36.sp, fontWeight = FontWeight.Bold)
        Text("AstraWave provides no channels. Connect a service or playlist you are authorized to use.", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(mode == SourceType.XTREAM, { mode = SourceType.XTREAM }, { Text("Xtream Codes") })
            FilterChip(mode == SourceType.M3U, { mode = SourceType.M3U }, { Text("M3U URL") })
        }
        TvField(name, { name = it }, "Profile name")
        TvField(server, { server = it }, if (mode == SourceType.XTREAM) "Server URL" else "M3U playlist URL")
        if (mode == SourceType.XTREAM) {
            TvField(username, { username = it }, "Username")
            TvField(password, { password = it }, "Password")
        }
        Button(onClick = { connect(Profile("primary", name, mode, server, username, password)) }, enabled = server.startsWith("http")) {
            Text("Connect securely")
        }
    }
}

@Composable private fun TvField(value: String, onChange: (String) -> Unit, label: String) {
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
}

@Composable private fun HomeScreen(channels: List<Channel>, play: (Channel) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Text("Good evening", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        HeroCard(channels.firstOrNull(), play)
        Text("Recently added", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(channels.take(12)) { ChannelCard(it, play) } }
    }
}

@Composable private fun HeroCard(channel: Channel?, play: (Channel) -> Unit) {
    Box(Modifier.fillMaxWidth().height(210.dp).background(Panel, RoundedCornerShape(18.dp)).padding(28.dp)) {
        Column(Modifier.align(Alignment.CenterStart), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("YOUR CONTENT. ONE BEAUTIFUL GUIDE.", color = Mint, fontWeight = FontWeight.Bold)
            Text(channel?.name ?: "Connect your playlist", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            channel?.let { Button(onClick = { play(it) }) { Icon(Icons.Default.PlayArrow, null); Text(" Watch now") } }
        }
    }
}

@Composable private fun ChannelBrowser(channels: List<Channel>, play: (Channel) -> Unit) {
    var query by remember { mutableStateOf("") }
    val shown = channels.filter { query.isBlank() || it.name.contains(query, true) || it.group.contains(query, true) }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Live TV", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        TvField(query, { query = it }, "Search channels")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(shown, key = { it.id }) { ChannelRow(it, play) } }
    }
}

@Composable private fun ChannelRow(channel: Channel, play: (Channel) -> Unit) {
    FocusCard(Modifier.fillMaxWidth().height(68.dp), onClick = { play(channel) }) {
        Row(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.LiveTv, null, tint = Mint)
            Column(Modifier.padding(start = 14.dp).weight(1f)) { Text(channel.name, fontWeight = FontWeight.SemiBold); Text(channel.group, color = Muted, fontSize = 12.sp) }
            Icon(Icons.Default.PlayArrow, null)
        }
    }
}

@Composable private fun ChannelCard(channel: Channel, play: (Channel) -> Unit) {
    FocusCard(Modifier.width(220.dp).height(125.dp), onClick = { play(channel) }) {
        Column(Modifier.padding(16.dp)) { Icon(Icons.Default.LiveTv, null, tint = Mint); Spacer(Modifier.weight(1f)); Text(channel.name, maxLines = 2, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun GuideScreen(channels: List<Channel>, play: (Channel) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("TV Guide", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Now", color = Mint)
        LazyColumn { items(channels) { channel ->
            Row(Modifier.fillMaxWidth().height(76.dp)) {
                Box(Modifier.width(250.dp).fillMaxHeight().padding(4.dp).background(Panel, RoundedCornerShape(8.dp)).clickable { play(channel) }.padding(12.dp), contentAlignment = Alignment.CenterStart) { Text(channel.name, maxLines = 2) }
                Box(Modifier.weight(1f).fillMaxHeight().padding(4.dp).background(Color(0xFF17313B), RoundedCornerShape(8.dp)).padding(12.dp)) { Text("Program data loads from XMLTV / provider EPG", color = Muted) }
            }
        } }
    }
}

@Composable private fun EventsScreen(vm: MainViewModel) {
    val events = remember { sampleEvents() }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Live Events", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Scores and schedules come from your configured sports-data provider. Channel suggestions come only from your playlist.", color = Muted)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(events) { event ->
            val matches = vm.matches(event)
            FocusCard(Modifier.fillMaxWidth(), onClick = { matches.firstOrNull()?.let { vm.play(it.channel) } }) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Text(event.league, color = Mint, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text(event.status, color = Muted) }
                    Text("${event.away}  ${event.awayScore}  •  ${event.homeScore}  ${event.home}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(matches.firstOrNull()?.let { "Best channel match: ${it.channel.name}" } ?: "No channel match found", color = Muted)
                }
            }
        } }
    }
}

private fun sampleEvents() = listOf(
    SportsEvent("demo-1", "NFL", "Denver Broncos", "Kansas City Chiefs", System.currentTimeMillis(), "Data adapter required"),
    SportsEvent("demo-2", "MLB", "Colorado Rockies", "Arizona Diamondbacks", System.currentTimeMillis(), "Data adapter required")
)

@Composable private fun PosterShelf(title: String, content: List<Channel>, play: (Channel) -> Unit) {
    Column { Text(title, fontSize = 34.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(18.dp)); if (content.isEmpty()) Text("Your provider has not returned any $title yet.", color = Muted) else LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(content) { ChannelCard(it, play) } } }
}

@Composable private fun DebridScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Debrid accounts", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Link accounts with provider device authorization. AstraWave does not search for or supply content.", color = Muted)
        DebridProvider.entries.forEach { provider ->
            FocusCard(Modifier.fillMaxWidth().height(76.dp), onClick = {}) {
                Row(Modifier.fillMaxSize().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Link, null, tint = Violet); Text(provider.name.replace('_', '-'), Modifier.padding(start = 14.dp).weight(1f), fontWeight = FontWeight.Bold); Text("Set up", color = Mint)
                }
            }
        }
    }
}

@Composable private fun ExtensionsScreen() {
    var url by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(tv.astrawave.player.extensions.ExtensionKind.STREMIO) }
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Extensions", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Add a Stremio manifest or CloudStream-compatible repository you trust. AstraWave does not include extension sources.", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(kind == tv.astrawave.player.extensions.ExtensionKind.STREMIO, { kind = tv.astrawave.player.extensions.ExtensionKind.STREMIO }, { Text("Stremio add-on") })
            FilterChip(kind == tv.astrawave.player.extensions.ExtensionKind.CLOUDSTREAM_REPOSITORY, { kind = tv.astrawave.player.extensions.ExtensionKind.CLOUDSTREAM_REPOSITORY }, { Text("CloudStream repo") })
        }
        TvField(url, { url = it }, if (kind == tv.astrawave.player.extensions.ExtensionKind.STREMIO) "HTTPS manifest URL or stremio:// URL" else "HTTPS repository JSON URL")
        Button(onClick = { /* ViewModel persistence and review dialog are wired in milestone 2. */ }, enabled = url.isNotBlank()) { Text("Review source") }
        HorizontalDivider()
        Text("Before installation", fontWeight = FontWeight.Bold)
        Text("Review the host, permissions, supported resources, signature, and content policy. CloudStream plugin metadata can be discovered now; executable plugin loading remains disabled until the sandboxed compatibility runtime is added.", color = Muted)
    }
}

@Composable private fun SettingsScreen(profile: Profile) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) { Text("Settings", fontSize = 34.sp, fontWeight = FontWeight.Bold); Text("Profile: ${profile.name}"); Text("Source: ${profile.type}", color = Muted); Text("Parental controls, decoder choice, EPG refresh, buffer size and appearance are planned for the next milestone.", color = Muted) }
}

@Composable private fun PlayerScreen(channel: Channel, onBack: () -> Unit) {
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(channel.streamUrl)); prepare(); playWhenReady = true } }
    DisposableEffect(Unit) { onDispose { player.release() } }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true; layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) } }, modifier = Modifier.fillMaxSize())
        Text(channel.name, Modifier.align(Alignment.TopStart).padding(22.dp).background(Color.Black.copy(alpha = .6f), RoundedCornerShape(8.dp)).padding(12.dp), fontWeight = FontWeight.Bold)
        IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopEnd).padding(18.dp)) { Icon(Icons.Default.Close, "Close player") }
    }
}

@Composable private fun FocusCard(modifier: Modifier, onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(modifier.onFocusChanged { focused = it.isFocused }.border(if (focused) 2.dp else 0.dp, if (focused) Mint else Color.Transparent, RoundedCornerShape(12.dp)).background(if (focused) Color(0xFF183A43) else Panel, RoundedCornerShape(12.dp)).clickable(onClick = onClick).focusable(), content = content)
}
