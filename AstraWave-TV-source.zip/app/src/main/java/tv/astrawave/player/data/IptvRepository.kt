package tv.astrawave.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.contentOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import tv.astrawave.player.model.Channel
import tv.astrawave.player.model.Episode
import tv.astrawave.player.model.Profile
import tv.astrawave.player.model.Program
import tv.astrawave.player.model.SourceType
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class IptvRepository(private val client: OkHttpClient = OkHttpClient()) {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun load(profile: Profile): List<Channel> = withContext(Dispatchers.IO) {
        when (profile.type) {
            SourceType.M3U -> M3uParser.parse(get(profile.server))
            SourceType.XTREAM -> loadXtream(profile)
        }
    }

    suspend fun loadPrograms(profile: Profile): List<Program> = withContext(Dispatchers.IO) {
        val url = when {
            profile.epgUrl.isNotBlank() -> profile.epgUrl
            profile.type == SourceType.XTREAM -> "${profile.server.trimEnd('/')}/xmltv.php?username=${enc(profile.username)}&password=${enc(profile.password)}"
            else -> return@withContext emptyList()
        }
        val request = Request.Builder().url(url).header("User-Agent", "AstraWaveTV/0.1").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Guide provider returned HTTP ${response.code}")
            val body = response.body ?: error("Guide provider returned no data")
            body.charStream().use { reader -> XmltvParser.parse(reader) }
        }
    }

    suspend fun loadEpisodes(profile: Profile, seriesId: String): List<Episode> = withContext(Dispatchers.IO) {
        require(profile.type == SourceType.XTREAM) { "Episodes require an Xtream profile" }
        val root = profile.server.trimEnd('/'); val user = enc(profile.username); val pass = enc(profile.password)
        val response = json.parseToJsonElement(get("$root/player_api.php?username=$user&password=$pass&action=get_series_info&series_id=${enc(seriesId)}")).jsonObject
        response["episodes"]?.jsonObject.orEmpty().flatMap { (seasonKey, value) ->
            value.jsonArray.mapNotNull { node ->
                val o = node.jsonObject; val id = o["id"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
                val info = runCatching { o["info"]?.jsonObject }.getOrNull()
                val extension = o["container_extension"]?.jsonPrimitive?.contentOrNull?.ifBlank { "mp4" } ?: "mp4"
                val directSource = o["direct_source"]?.jsonPrimitive?.contentOrNull?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
                Episode(id, seriesId, o["season"]?.jsonPrimitive?.contentOrNull?.toIntOrNull() ?: seasonKey.toIntOrNull() ?: 0, o["episode_num"]?.jsonPrimitive?.contentOrNull?.toIntOrNull() ?: 0, o["title"]?.jsonPrimitive?.contentOrNull ?: "Episode", directSource ?: "$root/series/$user/$pass/$id.$extension", info?.get("plot")?.jsonPrimitive?.contentOrNull.orEmpty(), info?.get("movie_image")?.jsonPrimitive?.contentOrNull, info?.get("duration")?.jsonPrimitive?.contentOrNull.orEmpty(), info?.get("rating")?.jsonPrimitive?.contentOrNull.orEmpty())
            }
        }.sortedWith(compareBy<Episode> { it.season }.thenBy { it.number })
    }

    fun catchup(profile: Profile, channel: Channel, program: Program): Channel {
        require(profile.type == SourceType.XTREAM && channel.catchupDays > 0) { "Catch-up is unavailable for this channel" }
        require(program.endMillis < System.currentTimeMillis()) { "Only completed programs can be replayed" }
        val durationMinutes = ((program.endMillis - program.startMillis) / 60_000L).coerceAtLeast(1L)
        val start = SimpleDateFormat("yyyy-MM-dd:HH-mm", Locale.US).apply { timeZone = TimeZone.getTimeZone(channel.catchupTimezone) }.format(Date(program.startMillis))
        val root = profile.server.trimEnd('/')
        val url = "$root/timeshift.php?username=${enc(profile.username)}&password=${enc(profile.password)}&stream=${enc(channel.providerId ?: channel.id)}&start=${enc(start)}&duration=$durationMinutes"
        return channel.copy(id = "catchup-${channel.id}-${program.startMillis}", name = "${channel.name} • ${program.title}", streamUrl = url, kind = tv.astrawave.player.model.MediaKind.CATCHUP)
    }

    private fun loadXtream(profile: Profile): List<Channel> {
        val root = profile.server.trimEnd('/')
        val user = enc(profile.username)
        val pass = enc(profile.password)
        val login = json.parseToJsonElement(get("$root/player_api.php?username=$user&password=$pass")).jsonObject
        val userInfo = login["user_info"]?.jsonObject
        val authenticated = userInfo?.get("auth")?.jsonPrimitive?.contentOrNull
        val accountStatus = userInfo?.get("status")?.jsonPrimitive?.contentOrNull
        if (authenticated == "0" || accountStatus.equals("Disabled", true) || accountStatus.equals("Banned", true)) {
            error("The provider rejected this account (${accountStatus ?: "invalid credentials"})")
        }
        val allowedOutputs = runCatching { userInfo?.get("allowed_output_formats")?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull }.orEmpty() }.getOrDefault(emptyList())
        val liveExtension = if ("m3u8" in allowedOutputs && "ts" !in allowedOutputs) "m3u8" else "ts"
        val serverTimezone = login["server_info"]?.jsonObject?.get("timezone")?.jsonPrimitive?.contentOrNull.orEmpty().ifBlank { "UTC" }
        fun categories(action: String) = runCatching { json.parseToJsonElement(get("$root/player_api.php?username=$user&password=$pass&action=$action")).jsonArray.associate { node -> val item = node.jsonObject; item["category_id"]!!.jsonPrimitive.content to item["category_name"]!!.jsonPrimitive.content } }.getOrDefault(emptyMap())
        val liveCategories = categories("get_live_categories")
        val movieCategories = categories("get_vod_categories")
        val seriesCategories = categories("get_series_categories")
        val live = json.parseToJsonElement(get("$root/player_api.php?username=$user&password=$pass&action=get_live_streams")).jsonArray.mapNotNull { node ->
            val o = node.jsonObject
            val id = o["stream_id"]?.jsonPrimitive?.content ?: return@mapNotNull null
            val directSource = o["direct_source"]?.jsonPrimitive?.contentOrNull?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
            Channel(
                id = id,
                name = o["name"]?.jsonPrimitive?.content ?: "Untitled",
                streamUrl = directSource ?: "$root/live/$user/$pass/$id.$liveExtension",
                logo = o["stream_icon"]?.jsonPrimitive?.content,
                group = o["category_id"]?.jsonPrimitive?.content?.let { liveCategories[it] ?: it } ?: "Other",
                epgId = o["epg_channel_id"]?.jsonPrimitive?.content,
                providerId = id,
                catchupDays = if (o["tv_archive"]?.jsonPrimitive?.contentOrNull == "1") o["tv_archive_duration"]?.jsonPrimitive?.contentOrNull?.toIntOrNull()?.coerceAtLeast(1) ?: 1 else 0,
                catchupTimezone = serverTimezone
            )
        }
        val movies = runCatching { json.parseToJsonElement(get("$root/player_api.php?username=$user&password=$pass&action=get_vod_streams")).jsonArray.mapNotNull { node ->
            val o = node.jsonObject; val id = o["stream_id"]?.jsonPrimitive?.content ?: return@mapNotNull null
            val ext = o["container_extension"]?.jsonPrimitive?.contentOrNull?.ifBlank { "mp4" } ?: "mp4"
            val directSource = o["direct_source"]?.jsonPrimitive?.contentOrNull?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
            Channel(id = "movie-$id", name = o["name"]?.jsonPrimitive?.content ?: "Untitled", streamUrl = directSource ?: "$root/movie/$user/$pass/$id.$ext", logo = o["stream_icon"]?.jsonPrimitive?.contentOrNull, group = o["category_id"]?.jsonPrimitive?.contentOrNull?.let { movieCategories[it] ?: it } ?: "Movies", kind = tv.astrawave.player.model.MediaKind.MOVIE, providerId = id, plot = o["plot"]?.jsonPrimitive?.contentOrNull.orEmpty(), year = o["year"]?.jsonPrimitive?.contentOrNull.orEmpty(), rating = o["rating"]?.jsonPrimitive?.contentOrNull.orEmpty())
        } }.getOrDefault(emptyList())
        val series = runCatching { json.parseToJsonElement(get("$root/player_api.php?username=$user&password=$pass&action=get_series")).jsonArray.mapNotNull { node ->
            val o = node.jsonObject; val id = o["series_id"]?.jsonPrimitive?.content ?: return@mapNotNull null
            val backdrop = runCatching { o["backdrop_path"]?.jsonArray?.firstOrNull()?.jsonPrimitive?.contentOrNull }.getOrNull()
            Channel(id = "series-$id", name = o["name"]?.jsonPrimitive?.content ?: "Untitled", streamUrl = "", logo = o["cover"]?.jsonPrimitive?.contentOrNull, group = o["category_id"]?.jsonPrimitive?.contentOrNull?.let { seriesCategories[it] ?: it } ?: "Series", kind = tv.astrawave.player.model.MediaKind.SERIES, providerId = id, plot = o["plot"]?.jsonPrimitive?.contentOrNull.orEmpty(), year = o["releaseDate"]?.jsonPrimitive?.contentOrNull.orEmpty().take(4), rating = o["rating"]?.jsonPrimitive?.contentOrNull.orEmpty(), backdrop = backdrop)
        } }.getOrDefault(emptyList())
        return live + movies + series
    }

    private fun get(url: String): String {
        val request = Request.Builder().url(url).header("User-Agent", "AstraWaveTV/0.1").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Provider returned HTTP ${response.code}")
            return response.body?.string() ?: error("Provider returned no data")
        }
    }

    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")
}
