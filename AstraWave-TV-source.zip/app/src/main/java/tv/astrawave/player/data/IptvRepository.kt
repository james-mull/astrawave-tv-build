package tv.astrawave.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import tv.astrawave.player.model.Channel
import tv.astrawave.player.model.Profile
import tv.astrawave.player.model.SourceType
import java.net.URLEncoder

class IptvRepository(private val client: OkHttpClient = OkHttpClient()) {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun load(profile: Profile): List<Channel> = withContext(Dispatchers.IO) {
        when (profile.type) {
            SourceType.M3U -> M3uParser.parse(get(profile.server))
            SourceType.XTREAM -> loadXtream(profile)
        }
    }

    private fun loadXtream(profile: Profile): List<Channel> {
        val root = profile.server.trimEnd('/')
        val user = enc(profile.username)
        val pass = enc(profile.password)
        val url = "$root/player_api.php?username=$user&password=$pass&action=get_live_streams"
        return json.parseToJsonElement(get(url)).jsonArray.mapNotNull { node ->
            val o = node.jsonObject
            val id = o["stream_id"]?.jsonPrimitive?.content ?: return@mapNotNull null
            Channel(
                id = id,
                name = o["name"]?.jsonPrimitive?.content ?: "Untitled",
                streamUrl = "$root/live/$user/$pass/$id.ts",
                logo = o["stream_icon"]?.jsonPrimitive?.content,
                group = o["category_id"]?.jsonPrimitive?.content ?: "Other",
                epgId = o["epg_channel_id"]?.jsonPrimitive?.content
            )
        }
    }

    private fun get(url: String): String {
        val request = Request.Builder().url(url).header("User-Agent", "AstraWaveTV/0.1").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Provider returned HTTP ${response.code}")
            return response.body?.string() ?: error("Provider returned no data")
        }
    }

    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")
}
