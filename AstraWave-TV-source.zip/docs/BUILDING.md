# Building AstraWave TV

## Android Studio

1. Install the current stable Android Studio and Android SDK 35.
2. Open the project root.
3. Use JDK 17 when prompted.
4. Let Android Studio sync Gradle dependencies.
5. Run on an Android TV emulator, physical Android TV, or Fire TV with ADB enabled.
6. Select **Build > Build APK(s)** for a debug APK.

## AndroidIDE on a phone

1. Extract the ZIP and open the folder containing `settings.gradle.kts`.
2. Complete AndroidIDE's toolchain setup and select JDK 17.
3. Open the terminal in the project root.
4. Run `chmod +x gradlew` once if required.
5. Run `./gradlew assembleDebug` while connected to Wi-Fi.
6. Open `app/build/outputs/apk/debug/app-debug.apk` when the build completes.

The first run downloads Gradle 8.9 and project dependencies, so it can take several minutes and use substantial storage.

## Release signing

Create a release keystore outside the repository. Configure signing through environment variables or a private `keystore.properties` file that is excluded by `.gitignore`. Never commit keystores or passwords.

## Fire TV testing

Enable ADB debugging on the Fire TV, connect with `adb connect DEVICE_IP`, then install with `adb install -r app-debug.apk`. Verify D-pad focus, Back behavior, 1080p/4K playback, sleep/wake recovery, and low-memory behavior.
