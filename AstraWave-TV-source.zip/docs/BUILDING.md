# Building AstraWave TV

## GitHub Actions from a phone

The project includes `.github/workflows/build-apk.yml`. It supports either an
unpacked Android project or a repository containing `AstraWave-TV-source.zip`.

1. Upload `AstraWave-TV-source.zip` to the repository root.
2. Open **Actions > Build AstraWave APK > Run workflow**.
3. Wait for the green check, open that run, and download the
   **AstraWave-debug-apk** artifact.
4. Extract the downloaded artifact ZIP, then install `app-debug.apk`.

Optional repository secrets:

- `TRAKT_CLIENT_ID` enables Trakt device authorization.
- `SPORTSDB_API_KEY` replaces the development sports-data key.

The GitHub build is a debug/private-test APK. A public release needs a private
signing key and a separate signed release workflow.

## Android Studio

1. Install the current stable Android Studio and Android SDK 35.
2. Open the project root.
3. Use JDK 17 when prompted.
4. Let Android Studio sync Gradle dependencies.
5. Run on an Android TV emulator, physical Android TV, or Fire TV with ADB enabled.
6. Select **Build > Build APK(s)** for a debug APK.

## AndroidIDE on a phone

1. Extract the ZIP and open the folder containing `settings.gradle.kts`.
2. Complete AndroidIDE's toolchain setup and select JDK 17.
3. Open the terminal in the project root.
4. Run `chmod +x gradlew` once if required.
5. Run `./gradlew assembleDebug` while connected to Wi-Fi.
6. Open `app/build/outputs/apk/debug/app-debug.apk` when the build completes.

The first run downloads Gradle 8.9 and project dependencies, so it can take several minutes and use substantial storage.

## Release signing

Create a release keystore outside the repository. Configure signing through environment variables or a private `keystore.properties` file that is excluded by `.gitignore`. Never commit keystores or passwords.

If Android reports **App not installed**, uninstall an older AstraWave build
signed with a different debug key, then install the new APK. This removes that
older installation's local settings.

## Fire TV testing

Enable ADB debugging on the Fire TV, connect with `adb connect DEVICE_IP`, then install with `adb install -r app-debug.apk`. Verify D-pad focus, Back behavior, 1080p/4K playback, sleep/wake recovery, and low-memory behavior.
