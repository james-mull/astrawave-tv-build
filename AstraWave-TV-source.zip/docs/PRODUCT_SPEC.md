# AstraWave TV — Product specification

## Product promise

A fast, polished Android TV and Fire TV player for media sources the customer already has permission to use. AstraWave is a player, not a content provider.

## Navigation

1. **Home** — continue watching, favorites, recently added, and featured rows from the user's sources.
2. **Live TV** — category rail, channel list, instant player, recent channels, and favorites.
3. **Guide** — horizontal time grid with current-time marker, program details, reminders, and catch-up indicators.
4. **Live Events** — licensed score/schedule data with ranked channel matches from the user's playlist.
5. **Movies** — poster rows, genres, search, details, resume, trailers supplied by metadata services, and source selection.
6. **Series** — shows, seasons, episodes, next episode, and progress.
7. **Debrid** — device-code account linking and authorized-link resolution for Real-Debrid, AllDebrid, and Premiumize.
8. **Extensions** — Stremio add-on manifests and reviewed CloudStream-compatible repository metadata.
9. **Settings** — playlists, EPG, player, appearance, parental controls, backups, and diagnostics.

## Live-event channel matching

The sports adapter returns an event with league, teams, start time, state, and score. The matcher normalizes those labels, removes noise words, compares them against channel names/groups, and returns ranked suggestions with reasons. It never constructs or discovers a stream URL; only channels already present in the user's playlist are eligible.

## Security

- Provider passwords and debrid tokens use Android Keystore-backed encrypted preferences.
- Logs must redact URL credentials and query strings.
- TLS is required by default; an explicit advanced compatibility switch may allow a known HTTP provider.
- Private OAuth client secrets must live on a backend, never inside the APK.
- Extension endpoints must use HTTPS, be reviewed before enabling, and never receive IPTV or debrid credentials automatically.
- CloudStream-compatible executable modules require signature verification, an allowlisted capability model, and explicit user consent.
- Screenshots should be disabled on credential and parental-control screens in production.

## 0.5 release-candidate boundary

The private beta implements functional Xtream/M3U catalogs, XMLTV guide and catch-up, sports schedule matching, VOD seasons and episodes, favorites and resume, audio/subtitle selection, buffering controls, picture-in-picture, parental filtering, responsive phone/tablet/TV navigation, and provider profile management.

Public-release gates remain: signed release automation, automated and real-device regression testing, privacy/store disclosures, crash reporting with credential redaction, licensed production sports data, and any provider-specific app registration. Multi-view, DVR, cloud backup, full Trakt synchronization, and executable CloudStream compatibility are future work rather than claims of this release candidate.
