# AstraWave TV — Product specification

## Product promise

A fast, polished Android TV and Fire TV player for media sources the customer already has permission to use. AstraWave is a player, not a content provider.

## Navigation

1. **Home** — continue watching, favorites, recently added, and featured rows from the user's sources.
2. **Live TV** — category rail, channel list, instant player, recent channels, and favorites.
3. **Guide** — horizontal time grid with current-time marker, program details, reminders, and catch-up indicators.
4. **Live Events** — licensed score/schedule data with ranked channel matches from the user's playlist.
5. **Movies** — poster rows, genres, search, details, resume, trailers supplied by metadata services, and source selection.
6. **Series** — shows, seasons, episodes, next episode, and progress.
7. **Debrid** — device-code account linking and authorized-link resolution for Real-Debrid, AllDebrid, and Premiumize.
8. **Extensions** — Stremio add-on manifests and reviewed CloudStream-compatible repository metadata.
9. **Settings** — playlists, EPG, player, appearance, parental controls, backups, and diagnostics.

## Live-event channel matching

The sports adapter returns an event with league, teams, start time, state, and score. The matcher normalizes those labels, removes noise words, compares them against channel names/groups, and returns ranked suggestions with reasons. It never constructs or discovers a stream URL; only channels already present in the user's playlist are eligible.

## Security

- Provider passwords and debrid tokens use Android Keystore-backed encrypted preferences.
- Logs must redact URL credentials and query strings.
- TLS is required by default; an explicit advanced compatibility switch may allow a known HTTP provider.
- Private OAuth client secrets must live on a backend, never inside the APK.
- Extension endpoints must use HTTPS, be reviewed before enabling, and never receive IPTV or debrid credentials automatically.
- CloudStream-compatible executable modules require signature verification, an allowlisted capability model, and explicit user consent.
- Screenshots should be disabled on credential and parental-control screens in production.

## Suggested next milestones

### Milestone 2 — Functional catalog

- Xtream categories, movies, series, seasons, and episodes
- XMLTV parser and Room persistence
- guide time grid and program details
- favorites, history, and resume positions
- registered debrid device flows

### Milestone 3 — Pro TV features

- multi-view
- catch-up and replay
- subtitle/audio track UI
- decoder and buffer controls
- picture-in-picture where supported
- parental profiles and PIN
- playlist backup and restore

### Milestone 4 — Release

- real sports-data adapter and alias administration
- QA on Fire TV Stick 4K/Max and representative Android TV devices
- crash reporting with credential redaction
- privacy policy, store disclosures, signing, and release automation
