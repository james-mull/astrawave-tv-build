@echo off
setlocal
set GRADLE_VERSION=8.9
set PROJECT_DIR=%~dp0
set BOOTSTRAP_DIR=%PROJECT_DIR%.gradle\bootstrap
set GRADLE_BIN=%BOOTSTRAP_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat
set ARCHIVE=%BOOTSTRAP_DIR%\gradle-%GRADLE_VERSION%-bin.zip

if not exist "%GRADLE_BIN%" (
  if not exist "%BOOTSTRAP_DIR%" mkdir "%BOOTSTRAP_DIR%"
  if not exist "%ARCHIVE%" powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ARCHIVE%'"
  powershell -NoProfile -Command "Expand-Archive -Force '%ARCHIVE%' '%BOOTSTRAP_DIR%'"
)

call "%GRADLE_BIN%" --project-dir "%PROJECT_DIR%" %*
