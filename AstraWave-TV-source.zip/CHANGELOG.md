# Changelog

## 0.5.0-rc1

- Responsive phone, tablet, Android TV, and Fire TV navigation.
- Xtream Codes and M3U profiles with live channels, categories, XMLTV guide,
  catch-up, movies, series, seasons, and episodes.
- Cinematic VOD home, detail pages, provider genres, collections, ranked rows,
  My List, search/filter/sort, resume progress, and episode playback.
- Live preview, recent channels, favorites, audio/subtitle selection, buffering
  presets, aspect ratio, playback speed, autoplay, retry, and picture-in-picture.
- Sports schedules with ranked matches to channels already in the connected
  playlist.
- Trakt device authorization, explicit authorized-link debrid resolution,
  reviewed extension metadata, parental controls, and emulator launching.
- Canonical GitHub Actions workflow supporting both an unpacked project and the
  single source ZIP used by phone-based repository workflows.

This release candidate supplies no content and does not scrape or discover
unauthorized streams.
