# Changelog

## 0.6.0-rc14

- Added keyless English movie discovery and search through Stremio's official Cinemeta metadata service.
- Added keyless English TV discovery and search through TVmaze's US broadcast and streaming schedules.
- Made TMDB optional enrichment instead of blocking VOD when no key is configured.
- Search and catalog rails now show online titles beyond the IPTV provider library.
- Added explicit matching IPTV VOD entries to the source chooser alongside every connected debrid cloud.
- Reworked the phone guide into a cleaner Now/Next list and collapsed channel groups into a single picker.
- Reduced live-event network work from separate per-sport requests to three parallel daily requests.
- Improved live-event filtering and provider-guide matching for major US leagues and networks.

## 0.6.0-rc13

- Made TMDB the primary movie and TV discovery catalog instead of hiding titles absent from the IPTV VOD list.
- Added unified encrypted support for Real-Debrid, AllDebrid and Premiumize cloud libraries.
- Added title matching and quality sorting across the user's debrid files.
- Added a source chooser that combines matching IPTV VOD, debrid-cloud files and trusted installed add-ons.
- Added direct playback for Real-Debrid/Premiumize cloud files and AllDebrid link unlocking.
- Kept provider matches when available while enriching them with TMDB artwork, descriptions, years and ratings.

## 0.6.0-rc12

- Rebuilt the TV guide into a denser TiviMate-inspired half-hour timeline for phone and TV layouts.
- Added an aligned time header, channel identity column, live progress, category filters, favorites and catch-up cells.
- Added a Syncler-inspired VOD discovery hero and many more provider-playable TMDB and local catalog rails.
- Added genre, mood, decade, documentary, family, horror, comedy, action, crime and award-oriented shelves.
- Added sports-event broadcaster metadata and network/callsign aliases for local-channel matching.
- Events now show up to four matching playable IPTV stations instead of silently choosing one fuzzy result.

## 0.6.0-rc11

- Added a real TMDB client for trending, popular, top-rated, now-playing,
  on-air, sci-fi, thriller, crime, and mystery catalog rows. Online catalog
  titles are matched to playable items already returned by the user's provider.
- Added encrypted on-device TMDB API key/Read Access Token setup in Settings,
  with explicit loading, retry, missing-key, error, and no-match states.
- Rebuilt free live-event retrieval around per-sport queries for today and
  tomorrow instead of relying on the three-result unfiltered response.
- Always exposes the provider's sports channels beneath event schedules so an
  event screen remains useful when no exact automatic channel match exists.
- Moved home ranking, content discovery, VOD preparation, guide filtering,
  channel filtering, related-title discovery, and event matching off the UI
  thread to reduce navigation stalls on large provider libraries.
- Uses authenticated Xtream stream addresses first, retains provider direct
  URLs as fallbacks, tries TS and HLS explicitly, uses a compatibility player
  user agent, and offers an external-player fallback with clearer diagnostics.

## 0.5.9-rc10.1

- Opted the phone More bottom sheet into the Material 3 experimental API so
  Kotlin compilation succeeds with the Compose version used by GitHub Actions.

## 0.5.9-rc10

- Replaced the phone More dialog with a measured bottom sheet to prevent the
  reported force-close and make secondary destinations easier to reach.
- Added automatic TS/HLS fallback when a provider's preferred live-stream
  extension does not play, plus clearer final playback errors and retry.
- Fixed valid empty TheSportsDB responses crashing the event refresh, supports
  individual-sport event titles, and shows provider sports channels whenever
  the external schedule is empty.
- Added a persistent USA-first VOD preference with an Include world content
  toggle shared by Movies and Series.
- Added provider-matched discovery shelves for mind-bending movies and series,
  Rotten Tomatoes editorial essentials, prestige TV, highly rated titles, and
  true-story content. These shelves only organize media returned by the user's
  connected provider.
- Improved TV Guide navigation with provider-category filters alongside search,
  Favorites, Catch-up, and Jump to now controls.

## 0.5.8-rc9

- Restores the most recently connected encrypted provider profile at launch so
  returning users stay signed in after closing or restarting the app.
- Adds an active-profile marker while remaining compatible with accounts saved
  by earlier release candidates.
- Shows a clear reconnecting screen during startup and safely returns to login
  with a useful error if the saved provider is temporarily unavailable.

## 0.5.7-rc8

- Added one-tap Home shortcuts with visible Live TV, movie, and series counts.
- Replaced the custom More control with a standard navigation item and a large,
  touch-friendly destination dialog.
- Added clear recovery actions when a provider authenticates but returns no
  playable content.
- Improved phone labels, spacing, tap targets, and authenticated status cues.

## 0.5.6-rc7

- Fixed the actual blank authenticated-screen defect: the custom More item
  requested the full available height inside `NavigationBar`, expanding the
  navigation bar across the screen and leaving the route content at zero
  height. The item now has the navigation bar's fixed 80dp height.

## 0.5.5-rc6

- Replaced the entire authenticated phone scaffold with a direct, explicit
  full-screen hierarchy: identity header, active route, status overlays, and
  navigation bar.
- Added the distinct launcher label `AstraWave TV RC6` so an older installed
  build cannot be mistaken for this diagnostic release.

## 0.5.4-rc5

- Forces Android's activity window to ignore stale keyboard resize bounds,
  fixing the Samsung post-login half-height viewport.
- Hides the system IME again when authenticated state begins.
- Adds an always-visible authenticated header showing the build version and
  number of provider items loaded for easier install and data verification.
- Calls the authenticated route directly inside the full-screen phone shell.

## 0.5.3-rc4

- Replaced the authenticated phone shell with a full-screen Material scaffold
  so content and bottom navigation remain correctly anchored after login.
- Explicitly dismisses the software keyboard and clears field focus before
  connecting, preventing a stale half-height app window after authentication.
- Normalizes copied smart dashes in provider hostnames to standard DNS hyphens.
- Bumped the Android build to version code 53 for clean upgrade detection.

## 0.5.2-rc3

- Removed encrypted-storage initialization from the startup UI so credential
  storage can never blank the login screen.
- Made secure profile persistence lazy and non-blocking after a provider has
  authenticated successfully.
- Added an unmistakable full-screen provider setup page with the build version,
  privacy notice, validation, progress, and inline errors.
- Fresh installs now choose the recommended layout automatically so provider
  login is the first interactive screen; layout remains adjustable in Settings.

## 0.5.1-rc2

- Fixed a phone startup-routing defect that could display an empty navigation
  shell instead of the provider login screen.
- Login is now a full-screen, scrollable route and the app navigation remains
  hidden until a provider successfully connects.
- Added URL and credential validation, password masking, visible connection
  progress, and recoverable inline provider errors.
- Provider profiles are saved only after authentication succeeds.
- Added secure recovery for credential preferences that become unreadable after
  installing a debug APK signed with a different development key.

## 0.5.0-rc1

- Responsive phone, tablet, Android TV, and Fire TV navigation.
- Xtream Codes and M3U profiles with live channels, categories, XMLTV guide,
  catch-up, movies, series, seasons, and episodes.
- Cinematic VOD home, detail pages, provider genres, collections, ranked rows,
  My List, search/filter/sort, resume progress, and episode playback.
- Live preview, recent channels, favorites, audio/subtitle selection, buffering
  presets, aspect ratio, playback speed, autoplay, retry, and picture-in-picture.
- Sports schedules with ranked matches to channels already in the connected
  playlist.
- Trakt device authorization, explicit authorized-link debrid resolution,
  reviewed extension metadata, parental controls, and emulator launching.
- Canonical GitHub Actions workflow supporting both an unpacked project and the
  single source ZIP used by phone-based repository workflows.

This release candidate supplies no content and does not scrape or discover
unauthorized streams.
