# Changelog

## 0.5.4-rc5

- Forces Android's activity window to ignore stale keyboard resize bounds,
  fixing the Samsung post-login half-height viewport.
- Hides the system IME again when authenticated state begins.
- Adds an always-visible authenticated header showing the build version and
  number of provider items loaded for easier install and data verification.
- Calls the authenticated route directly inside the full-screen phone shell.

## 0.5.3-rc4

- Replaced the authenticated phone shell with a full-screen Material scaffold
  so content and bottom navigation remain correctly anchored after login.
- Explicitly dismisses the software keyboard and clears field focus before
  connecting, preventing a stale half-height app window after authentication.
- Normalizes copied smart dashes in provider hostnames to standard DNS hyphens.
- Bumped the Android build to version code 53 for clean upgrade detection.

## 0.5.2-rc3

- Removed encrypted-storage initialization from the startup UI so credential
  storage can never blank the login screen.
- Made secure profile persistence lazy and non-blocking after a provider has
  authenticated successfully.
- Added an unmistakable full-screen provider setup page with the build version,
  privacy notice, validation, progress, and inline errors.
- Fresh installs now choose the recommended layout automatically so provider
  login is the first interactive screen; layout remains adjustable in Settings.

## 0.5.1-rc2

- Fixed a phone startup-routing defect that could display an empty navigation
  shell instead of the provider login screen.
- Login is now a full-screen, scrollable route and the app navigation remains
  hidden until a provider successfully connects.
- Added URL and credential validation, password masking, visible connection
  progress, and recoverable inline provider errors.
- Provider profiles are saved only after authentication succeeds.
- Added secure recovery for credential preferences that become unreadable after
  installing a debug APK signed with a different development key.

## 0.5.0-rc1

- Responsive phone, tablet, Android TV, and Fire TV navigation.
- Xtream Codes and M3U profiles with live channels, categories, XMLTV guide,
  catch-up, movies, series, seasons, and episodes.
- Cinematic VOD home, detail pages, provider genres, collections, ranked rows,
  My List, search/filter/sort, resume progress, and episode playback.
- Live preview, recent channels, favorites, audio/subtitle selection, buffering
  presets, aspect ratio, playback speed, autoplay, retry, and picture-in-picture.
- Sports schedules with ranked matches to channels already in the connected
  playlist.
- Trakt device authorization, explicit authorized-link debrid resolution,
  reviewed extension metadata, parental controls, and emulator launching.
- Canonical GitHub Actions workflow supporting both an unpacked project and the
  single source ZIP used by phone-based repository workflows.

This release candidate supplies no content and does not scrape or discover
unauthorized streams.
